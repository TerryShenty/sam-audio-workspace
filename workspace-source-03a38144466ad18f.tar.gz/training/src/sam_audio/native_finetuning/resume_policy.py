"""Explicit terminal one-step continuation for the measured constant schedule.

No checkpoint mutation, horizon inference, or relaxation of data/model checks.
"""
import hashlib
import json


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def check_request(config, resume, previous_limit):
    if previous_limit is None:
        return
    if (type(previous_limit) is not int or previous_limit < 1 or not resume
            or type(config.get("max_steps")) is not int
            or config["max_steps"] != previous_limit + 1):
        raise ValueError("Explicit resume horizon extension requires exactly one new step")
    if config.get("scheduler") != "constant" or config.get("warmup_steps") != 50:
        raise ValueError("Horizon extension supports only constant scheduler with warmup 50")


def check_checkpoint(config, checkpoint, capacity, *, current_verified_base=None):
    previous_limit = config.get("resume_max_steps_from")
    if previous_limit is None:
        return None
    check_request(config, config.get("resume_from"), previous_limit)
    old = checkpoint["config"]
    if (type(old.get("max_steps")) is not int or old["max_steps"] != previous_limit
            or type(checkpoint.get("global_step")) is not int
            or checkpoint["global_step"] != previous_limit):
        raise ValueError("Horizon extension requires the declared terminal checkpoint")
    if type(capacity) is not int or config["max_steps"] > capacity:
        raise ValueError("Horizon extension exceeds unchanged epoch capacity")
    # Moving verified model bytes to another machine is an execution location
    # change. Require the caller's actual strict-loader identity before accepting
    # it; a saved path or a claim in the config is never sufficient.
    relocation = None
    if old.get("model_local_path") != config.get("model_local_path"):
        base = checkpoint.get("verified_base")
        if (not isinstance(base, dict) or base.get("version") != 2
                or current_verified_base != base or not base.get("text_encoder_identity")
                or not all(isinstance(base.get(k), str) and len(base[k]) == 64
                           for k in ("checkpoint_sha256", "config_sha256"))):
            raise ValueError("Model location change requires the same actual verified base")
        relocation = dict(original_path=old.get("model_local_path"),
                          current_path=config.get("model_local_path"),
                          verified_base_sha256=canonical_sha(base))
    # Only verified execution locations and the explicit new budget may differ.
    ignored = {"output_dir", "resume_from", "max_steps", "resume_max_steps_from",
               "resume_horizon_extension_applied", "model_local_path"}
    missing = object()
    for key in sorted((set(old) | set(config)) - ignored):
        if old.get(key, missing) != config.get(key, missing):
            raise ValueError(f"Horizon extension changed another setting: {key}")
    if old.get("scheduler") != "constant" or old.get("warmup_steps") != 50:
        raise ValueError("Saved scheduler is not compatible with horizon extension")
    result = {
        "policy": "explicit-terminal-constant-warmup50-one-step-v1",
        "previous_max_steps": previous_limit,
        "requested_max_steps": config["max_steps"],
        "checkpoint_global_step": checkpoint["global_step"],
        "epoch_capacity": capacity,
        "checkpoint_path": config["resume_from"],
        "original_config_sha256": canonical_sha(old),
        "data_identity_sha256": canonical_sha(checkpoint["data_identity"]),
        "reason": "constant schedule and unchanged warmup are independent of max_steps",
        "original_checkpoint_modified": False,
    }
    if relocation is not None:
        result["model_relocation"] = relocation
    return result
