import ast
import copy
import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('relocation_policy',ROOT/'src/sam_audio/native_finetuning/resume_policy.py')
policy=importlib.util.module_from_spec(spec);spec.loader.exec_module(policy)
class RelocationTests(unittest.TestCase):
 def setUp(self):
  self.base=dict(version=2,checkpoint_sha256='a'*64,config_sha256='b'*64,text_encoder_identity=dict(weights_sha256='c'*64,tokenizer_sha256='d'*64))
  self.old=dict(max_steps=9,scheduler='constant',warmup_steps=50,num_epochs=2,seed=7,world_size=2,model_local_path='/old/model',output_dir='/old/run',resume_from=None)
  self.state=dict(config=self.old,global_step=9,verified_base=self.base,data_identity=dict(plan_id='same'))
  self.new=dict(self.old,max_steps=10,resume_max_steps_from=9,model_local_path='/new/model',output_dir='/new/run',resume_from='/downloaded/final.pt')
 def test_same_verified_bytes_may_move_without_mutation(self):
  original=copy.deepcopy((self.new,self.state));r=policy.check_checkpoint(self.new,self.state,14,current_verified_base=self.base)
  self.assertEqual((self.new,self.state),original);self.assertEqual(r['model_relocation']['original_path'],'/old/model');self.assertEqual(r['model_relocation']['current_path'],'/new/model');self.assertEqual(r['original_config_sha256'],policy.canonical_sha(self.old))
 def test_location_alone_never_proves_base(self):
  for supplied in [None,{},dict(self.base,version=1),dict(self.base,checkpoint_sha256='e'*64),dict(self.base,config_sha256='e'*64),dict(self.base,text_encoder_identity={})]:
   with self.subTest(supplied=supplied),self.assertRaisesRegex(ValueError,'verified base'):policy.check_checkpoint(self.new,self.state,14,current_verified_base=supplied)
 def test_other_config_changes_still_refused(self):
  for field,value in [('world_size',1),('seed',8),('num_epochs',3),('scheduler','cosine'),('warmup_steps',49),('new_unknown_option',True)]:
   with self.subTest(field=field),self.assertRaises(ValueError):policy.check_checkpoint(dict(self.new,**{field:value}),self.state,14,current_verified_base=self.base)
 def test_budget_and_saved_position_still_strict(self):
  for state,capacity in [(dict(self.state,global_step=8),14),(self.state,9),(dict(self.state,config=dict(self.old,max_steps=8)),14)]:
   with self.assertRaises(ValueError):policy.check_checkpoint(self.new,state,capacity,current_verified_base=self.base)
 def test_default_does_not_implicitly_extend(self):
  cfg=dict(self.new);cfg.pop('resume_max_steps_from');self.assertIsNone(policy.check_checkpoint(cfg,self.state,14,current_verified_base=self.base))
 def test_same_path_keeps_previous_policy_behavior(self):
  r=policy.check_checkpoint(dict(self.new,model_local_path=self.old['model_local_path']),self.state,14);self.assertNotIn('model_relocation',r)
 def test_trainer_passes_actual_strict_identity_after_matching(self):
  tree=ast.parse((ROOT/'src/sam_audio/native_finetuning/delivery_impl.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_training');calls=[n for n in ast.walk(f) if isinstance(n,ast.Call)]
  match=next(n for n in calls if isinstance(n.func,ast.Name) and n.func.id=='require_matching_base');extension=next(n for n in calls if isinstance(n.func,ast.Name) and n.func.id=='check_resume_checkpoint');self.assertLess(match.lineno,extension.lineno)
  actual=next(k.value for k in extension.keywords if k.arg=='current_verified_base');self.assertEqual(ast.unparse(actual),'verified_base(wrapper.sam_audio)')
if __name__=='__main__':unittest.main()
