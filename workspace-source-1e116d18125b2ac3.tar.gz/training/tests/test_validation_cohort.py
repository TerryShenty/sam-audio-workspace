import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import delivery_cohort as cohort


def rows():
    return [dict(index=i, dataset='msdwild' if i < 78 else 'easycom',
                 clip_id='clip'+str(i), target_source_id='speaker',
                 prompt='the speaker on the left', noise_seed=123+i,
                 latent_frames=500 if i < 78 else 250) for i in range(285)]


class CohortTests(unittest.TestCase):
    def test_exact_identity_and_order_independence(self):
        data=rows()
        with patch.object(cohort,'COHORT_SHA256',cohort.fingerprint(data)):
            self.assertEqual(cohort.check(list(reversed(data)))['scope'],'FORMAL_285')
            data[0]['noise_seed']+=1
            with self.assertRaisesRegex(ValueError,'changed'):cohort.check(data)

    def test_missing_rows_and_unrelated_validation_fail(self):
        data=rows()
        with self.assertRaisesRegex(ValueError,'Full validation'):cohort.check(data[:-1])
        data[0]['dataset']='solos'
        with self.assertRaisesRegex(ValueError,'MSDWild and EasyCom'):cohort.check(data)

    def test_duplicate_and_prompt_substitution_fail(self):
        data=rows()
        with patch.object(cohort,'COHORT_SHA256',cohort.fingerprint(data)):
            changed=copy.deepcopy(data);changed[0]['prompt']='different query'
            with self.assertRaisesRegex(ValueError,'changed'):cohort.check(changed)
        data[-1]=data[0]
        with self.assertRaisesRegex(ValueError,'duplicate'):cohort.check(data)

    def test_engineering_is_explicit_and_never_formal(self):
        data=rows()[:1]
        with self.assertRaises(ValueError):cohort.check(data)
        self.assertEqual(cohort.check(data,engineering_subset=True)['scope'],'ENGINEERING_SUBSET')
