import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from delivery_lifecycle import tracked_session


class LifecycleTests(unittest.TestCase):
    def test_success_and_budget_checkpoint(self):
        for status in ('COMPLETE', 'CHECKPOINTED'):
            with tempfile.TemporaryDirectory() as directory:
                tracker = Mock()
                with tracked_session(tracker, directory, 0) as state:
                    state['status'] = status
                self.assertEqual(json.loads((Path(directory)/'RESULT.json').read_text())['status'], status)
                tracker.finish.assert_called_once_with(exit_code=0)

    def test_failure_is_not_success_and_original_exception_survives(self):
        with tempfile.TemporaryDirectory() as directory:
            tracker = Mock()
            tracker.finish.side_effect = RuntimeError('tracking failure')
            with self.assertWarns(UserWarning):
                with self.assertRaisesRegex(ValueError, 'model failure'):
                    with tracked_session(tracker, directory, 0):
                        raise ValueError('model failure')
            result = json.loads((Path(directory)/'RESULT.json').read_text())
            self.assertEqual(result, {'status':'FAILED', 'error_type':'ValueError'})
            tracker.finish.assert_called_once_with(exit_code=1)

    def test_other_rank_does_not_overwrite_rank_zero_result(self):
        with tempfile.TemporaryDirectory() as directory:
            with tracked_session(Mock(), directory, 1):
                pass
            self.assertFalse((Path(directory)/'RESULT.json').exists())
