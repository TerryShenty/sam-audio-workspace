"""Supervisor tests; these do not claim real CUDA/NCCL acceptance."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import launch_distributed as launcher


class LauncherTests(unittest.TestCase):
    def test_default_success_preserves_transport(self):
        calls = []
        def probe(gpus, env, directory, timeout):
            calls.append(dict(env))
            return {"passed": True}
        env, report = launcher.select_transport(2, {"EXAMPLE": "unchanged"}, Path("/unused"), probe=probe)
        self.assertEqual(len(calls), 1)
        self.assertNotIn("NCCL_P2P_DISABLE", env)
        self.assertEqual(report["selected"], "default")

    def test_fallback_only_after_failure_and_does_not_mutate_input(self):
        original, calls = {"EXAMPLE": "unchanged"}, []
        def probe(gpus, env, directory, timeout):
            calls.append(dict(env))
            return {"passed": len(calls) == 2}
        env, report = launcher.select_transport(4, original, Path("/unused"), probe=probe)
        self.assertEqual(env["NCCL_P2P_DISABLE"], "1")
        self.assertNotIn("NCCL_P2P_DISABLE", original)
        self.assertEqual(len(report["attempts"]), 2)

    def test_operator_zero_is_not_overridden_on_failure(self):
        calls = []
        def probe(gpus, env, directory, timeout):
            calls.append(dict(env))
            return {"passed": False}
        env, report = launcher.select_transport(2, {"NCCL_P2P_DISABLE": "0"}, Path("/unused"), probe=probe)
        self.assertIsNone(env)
        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(calls, [{"NCCL_P2P_DISABLE": "0"}])

    def test_both_failed_never_produce_training_environment(self):
        env, report = launcher.select_transport(
            2, {}, Path("/unused"), probe=lambda *args: {"passed": False})
        self.assertIsNone(env)
        self.assertEqual(len(report["attempts"]), 2)

    def test_incomplete_rank_receipts_reject_zero_exit(self):
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp) / "probe"
            def run(*args):
                (directory / "PASS-rank-0.json").write_text(json.dumps(
                    dict(status="PASS", rank=0, world=2, steps=2)))
                return dict(exit_code=0, timed_out=False, seconds=0)
            with patch.object(launcher, "bounded_run", run):
                self.assertFalse(launcher.attempt(2, {}, directory, 60)["passed"])

    def test_single_gpu_does_not_start_probe(self):
        env, report = launcher.select_transport(
            1, {}, Path("/unused"), probe=lambda *args: self.fail("unexpected GPU probe"))
        self.assertEqual(env, {})
        self.assertEqual(report["status"], "SINGLE_GPU_NO_COLLECTIVE_PROBE")

    def test_cleanup_failure_prevents_fallback(self):
        calls = []
        def probe(*args):
            calls.append(1)
            raise RuntimeError("Diagnostic process group still exists")
        with self.assertRaisesRegex(RuntimeError, "process group"):
            launcher.select_transport(2, {}, Path("/unused"), probe=probe)
        self.assertEqual(calls, [1])

    @unittest.skipUnless(os.name == "posix", "POSIX process groups")
    def test_real_timeout_stops_process_before_return(self):
        with tempfile.TemporaryDirectory() as temp:
            marker = Path(temp) / "started"
            code = ("import os,time,pathlib;"
                    f"pathlib.Path({str(marker)!r}).write_text(str(os.getpid()));"
                    "time.sleep(30)")
            result = launcher.bounded_run(
                [sys.executable, "-c", code], dict(os.environ), Path(temp) / "log", 0.5)
            self.assertTrue(result["timed_out"])
            self.assertEqual(result["exit_code"], 124)
            self.assertFalse(launcher.group_exists(int(marker.read_text())))


if __name__ == "__main__":
    unittest.main()
