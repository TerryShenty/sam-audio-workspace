import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'tools'),
             str(Path(__file__).resolve().parents[1]/'src')]
import download_validation_data as loader
import delivery_cohort as cohort


class ValidationDownloadTests(unittest.TestCase):
    def fixture(self, member='media/example.wav', corrupt=False):
        body=b'bounded fixture bytes'
        rows=[dict(index=i,dataset='msdwild' if i<78 else 'easycom',
                   clip_id='clip'+str(i),target_source_id='s',prompt='left',
                   noise_seed=i,latent_frames=250,video=member,
                   gt_audio=member,mixture_audio=member) for i in range(285)]
        manifest={'counts':cohort.EXPECTED,'rows':rows,'files':[
            {'path':member,'size':len(body),'sha256':hashlib.sha256(body).hexdigest()}]}
        raw=json.dumps(manifest).encode()
        buf=io.BytesIO()
        with tarfile.open(fileobj=buf,mode='w') as archive:
            spec=tarfile.TarInfo(member);spec.size=len(body)
            archive.addfile(spec,io.BytesIO(b'X'*len(body) if corrupt else body))
        cfg={'repository':'sam-audio-research/test-fixture','revision':'a'*40,
             'counts':cohort.EXPECTED,'manifest_sha256':hashlib.sha256(raw).hexdigest(),
             'cohort_sha256':cohort.fingerprint(rows),
             'archive':{'path':'validation-media.tar','size':len(buf.getvalue()),
                        'sha256':hashlib.sha256(buf.getvalue()).hexdigest()}}
        return raw,buf.getvalue(),cfg

    def run_fixture(self, root, raw, archive, config):
        def copy_archive(path,manifest,base):
            (Path(path)/'validation-media.tar').write_bytes(archive)
        with patch.object(loader.urllib.request,'urlopen',return_value=io.BytesIO(raw)),\
             patch.object(loader,'download',side_effect=copy_archive),\
             patch.object(cohort,'COHORT_SHA256',config['cohort_sha256']):
            return loader.prepare(config,root)

    def test_complete_roundtrip_and_repeat(self):
        raw,arc,cfg=self.fixture()
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(self.run_fixture(d,raw,arc,cfg)['scope'],'FORMAL_285')
            self.assertEqual(self.run_fixture(d,raw,arc,cfg)['files'],1)
            self.assertTrue((Path(d)/'DOWNLOAD_RECEIPT.json').is_file())

    def test_corrupt_member_has_no_success_receipt(self):
        raw,arc,cfg=self.fixture(corrupt=True)
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'checksum'):
                self.run_fixture(d,raw,arc,cfg)
            self.assertFalse((Path(d)/'DOWNLOAD_RECEIPT.json').exists())

    def test_unsafe_path_rejected_before_extraction(self):
        raw,arc,cfg=self.fixture('../outside.wav')
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'Unsafe'):
                self.run_fixture(d,raw,arc,cfg)

    def test_unpublished_or_changed_manifest_rejected(self):
        raw,arc,cfg=self.fixture()
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'not published'):
                loader.prepare(dict(cfg,revision=None),d)
            with self.assertRaisesRegex(ValueError,'manifest checksum'):
                self.run_fixture(d,raw+b' ',arc,cfg)
