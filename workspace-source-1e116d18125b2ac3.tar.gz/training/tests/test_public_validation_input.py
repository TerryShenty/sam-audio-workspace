import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE / "tools"))
import prepare_public_validation_input as module


class PublicValidationInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (SOURCE / "tests/fixtures/public-validation.json").read_bytes()
        cls.pin = json.loads((SOURCE / "configs/validation_release.json").read_text())

    def test_real_pinned_manifest_and_balanced_representative(self):
        manifest, cohort = module.validate_manifest(self.raw, self.pin)
        self.assertEqual(cohort["counts"], {"msdwild": 78, "easycom": 207})
        subset = module.select_rows(manifest, module.REPRESENTATIVE)
        specs = {s["path"]: s for s in manifest["files"]}
        all_rows = []
        for rank in range(2):
            assigned = module.partition(subset, rank)
            self.assertEqual(sorted(r["latent_frames"] for r in assigned), [250, 250, 500, 500])
            self.assertIn((1920, 1080), [(specs[r["video"]]["width"], specs[r["video"]]["height"]) for r in assigned])
            self.assertIn((980, 480), [(specs[r["video"]]["width"], specs[r["video"]]["height"]) for r in assigned])
            all_rows.extend(r["index"] for r in assigned)
        self.assertEqual(set(all_rows), set(module.REPRESENTATIVE))

    def test_revision_and_digest_reject(self):
        for field, value in (("revision", None), ("revision", "main"), ("manifest_sha256", "0"*64)):
            pin = dict(self.pin, **{field: value})
            with self.assertRaises(ValueError):
                module.validate_manifest(self.raw, pin)

    def altered(self, mutate):
        manifest = json.loads(self.raw)
        mutate(manifest)
        raw = json.dumps(manifest).encode()
        pin = dict(self.pin, manifest_sha256=hashlib.sha256(raw).hexdigest())
        return module.validate_manifest(raw, pin)

    def test_original_prompt_noise_length_are_required(self):
        for field, value in (("prompt", "changed"), ("noise_seed", 999), ("latent_frames", 250)):
            with self.assertRaises(ValueError):
                self.altered(lambda m: m["rows"][0].update({field: value}))

    def test_media_escape_duplicate_and_missing_link_reject(self):
        edits = [
            lambda m: m["files"][0].update(path="../escape.mp4"),
            lambda m: m["files"].append(copy.deepcopy(m["files"][0])),
            lambda m: m["rows"][0].update(video="media/missing.mp4"),
            lambda m: m["rows"][0].update(training_support={"intervals": [[0, 10]]}),
        ]
        for edit in edits:
            with self.assertRaises(ValueError):
                self.altered(edit)

    def test_world_and_selection_reject(self):
        manifest, _ = module.validate_manifest(self.raw, self.pin)
        for indexes in ([], [0, 0], [999]):
            with self.assertRaises(ValueError):
                module.select_rows(manifest, indexes)
        with self.assertRaises(ValueError):
            module.partition(manifest["rows"], 0, 9)
        with self.assertRaises(ValueError):
            module.partition(module.select_rows(manifest, [0, 1]), 0, 2)

    def test_real_media_corruption_and_symlink_reject(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            p = root / "media/a.wav"
            p.parent.mkdir()
            p.write_bytes(b"trusted")
            spec = {"media/a.wav": {"size": 7, "sha256": module.sha(p)}}
            self.assertEqual(len(module.media_snapshot(root, spec)), 1)
            p.write_bytes(b"changed")
            with self.assertRaises(ValueError):
                module.media_snapshot(root, spec)
            p.unlink()
            other = root / "original.wav"
            other.write_bytes(b"trusted")
            p.symlink_to(other)
            with self.assertRaises(ValueError):
                module.media_snapshot(root, spec)

    def test_gpu_allocation_refused_before_any_output(self):
        with patch.dict(os.environ, {"SLURM_JOB_GPUS": "0,1"}):
            with self.assertRaises(ValueError):
                module.prepare(Path("/no/config/read/allowed"))

    def test_offline_handoff_uses_local_receipt_without_network(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); out = root / "output"
            media = out / "media-release"; media.mkdir(parents=True)
            pinpath = root / "pin.json"; module.write(pinpath, self.pin)
            model = root / "model.json"
            module.write(model, dict(status="CPU_INPUT_READY", explicit_hf_cache="cache", model_files={}))
            (media / "validation.json").write_bytes(self.raw)
            module.write(media / "DOWNLOAD_RECEIPT.json", dict(status="VERIFIED_MEDIA",
                         repo=self.pin["repository"], revision=self.pin["revision"]))
            cfg = dict(output=str(out), release_config=str(pinpath), release_config_sha256=module.sha(pinpath),
                       accepted_model_receipt=str(model), accepted_model_receipt_sha256=module.sha(model),
                       hf_hub_cache="cache", model="model", base_signature={}, offline_prepared_media=True)
            path = root / "config.json"; module.write(path, cfg)
            with patch("download_validation_data.prepare", side_effect=AssertionError("Network stage repeated")), \
                 patch.object(module, "media_snapshot", return_value={}), \
                 patch.dict(os.environ, SLURM_JOB_GPUS="", SLURM_STEP_GPUS=""):
                result = module.prepare(path)
            self.assertEqual(result["status"], "CPU_PUBLIC_VALIDATION_INPUT_READY")
            self.assertEqual(result["counts"], {"msdwild": 78, "easycom": 207})

    def test_stale_ready_preserved_then_invalidated_on_changed_config(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            cfg = root / "config.json"
            cfg.write_text(json.dumps({"output": str(root / "output")}))
            out = root / "output"
            out.mkdir()
            (out / "CPU_READY.json").write_text('{"status":"old"}')
            (out / "PREPARE_INTENT.json").write_text('{"config_identity":"different"}')
            with patch.dict(os.environ, {"SLURM_JOB_GPUS": "", "SLURM_STEP_GPUS": ""}):
                with self.assertRaises(ValueError):
                    module.prepare(cfg)
            self.assertFalse((out / "CPU_READY.json").exists())
            preserved = list((out / "history").glob("CPU_READY-*.json"))
            self.assertEqual(len(preserved), 1)
            self.assertEqual(json.loads(preserved[0].read_text())["status"], "old")

    def test_previously_accepted_media_corruption_fails_before_downloader(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            media = root / "media/a.wav"
            media.parent.mkdir()
            media.write_bytes(b"trusted")
            snapshots = module.media_snapshot(root, {
                "media/a.wav": {"size": 7, "sha256": module.sha(media)}})
            out = root / "output"
            out.mkdir()
            cfg = {"output": str(out)}
            cfg_path = root / "config.json"
            cfg_path.write_text(json.dumps(cfg))
            module.write(out / "PREPARE_INTENT.json", {"config_identity": module.key(cfg)})
            module.write(out / "CPU_READY.json", {
                "config_identity": module.key(cfg), "media_files": snapshots})
            media.write_bytes(b"changed")
            # No release_config/downloader exists in this fixture: failure must
            # happen at accepted-media verification, before any download/repair.
            with patch.dict(os.environ, {"SLURM_JOB_GPUS": "", "SLURM_STEP_GPUS": ""}):
                with self.assertRaisesRegex(ValueError, "Prepared input changed|media bytes changed"):
                    module.prepare(cfg_path)
            self.assertFalse((out / "CPU_READY.json").exists())
            self.assertEqual(media.read_bytes(), b"changed")


if __name__ == "__main__":
    unittest.main()
