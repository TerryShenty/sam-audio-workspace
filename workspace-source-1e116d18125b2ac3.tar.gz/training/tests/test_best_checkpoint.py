import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from select_best_checkpoint import select
class BestTests(unittest.TestCase):
 def fixture(self,root,name,a,b,n=207):
  p=root/'validation'/name;p.mkdir(parents=True);(p/'summary.json').write_text(json.dumps({'msdwild':{'n':78,'aligned_si_sdr_db':a},'easycom':{'n':n,'aligned_si_sdr_db':b}}));(root/(name+'.pt')).write_bytes(name.encode())
 def test_equal_dataset_not_weighted(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);self.fixture(r,'epoch-1',10,0);self.fixture(r,'epoch-2',0,8)
   self.assertEqual(select(r,{'msdwild':78,'easycom':207})['selected']['checkpoint'],'epoch-1.pt')
 def test_partial_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);self.fixture(r,'final',1,2,n=1)
   with self.assertRaises(ValueError):select(r,{'msdwild':78,'easycom':207})
 def test_missing_checkpoint_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);self.fixture(r,'final',1,2);(r/'final.pt').unlink()
   with self.assertRaises(ValueError):select(r,{'msdwild':78,'easycom':207})
