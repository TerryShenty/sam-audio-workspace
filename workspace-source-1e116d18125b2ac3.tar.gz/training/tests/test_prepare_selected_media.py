import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import prepare_selected_media as prep


class PreparationTests(unittest.TestCase):
    def fixture(self, base):
        root = Path(base) / "media"
        root.mkdir()
        videos, prompts, files = [], [], []
        for number in range(2):
            cid = "v" + str(number)
            video = dict(composite_id=cid, mode="spatial", samples=480000, sample_rate=48000,
                         recipe_sha256="a" * 64,
                         targets=[dict(slot=0, source_id="s" + str(number),
                                       window_id="w" + str(number), prompt_count=2)])
            videos.append(video)
            folder = root / "data" / cid
            folder.mkdir(parents=True)
            recipe = dict(composite_id=cid, mode="spatial", inputs=video["targets"])
            (folder / "recipe.json").write_text(json.dumps(recipe))
            for name in ("video.mp4", "mixture.wav", "target_0.wv", "residual_0.wv"):
                (folder / name).write_bytes((cid + name).encode())
            for path in folder.iterdir():
                files.append(dict(path=path.relative_to(root).as_posix(),
                                  bytes=path.stat().st_size, sha256=prep.digest(path)))
            for i, category in enumerate(("Spatial", "Appearance")):
                prompts.append(dict(composite_id=cid, slot=0, prompt_id=f"{cid}-{i}",
                                    prompt=f"unchanged prompt {number} {i}", category=category,
                                    subtype="test", source_id=video["targets"][0]["source_id"],
                                    window_id=video["targets"][0]["window_id"], recipe_sha256="a" * 64))
        (root / "videos.jsonl").write_text("".join(json.dumps(x) + "\n" for x in videos))
        (root / "prompts.jsonl").write_text("".join(json.dumps(x) + "\n" for x in prompts))
        (root / "RELEASE.json").write_text(json.dumps(dict(repo="TerryShenty/avspeech-93942",
            revision="b" * 40, videos=2, status=dict(expected_videos=10, expected_targets=20, prompts_available=40))))
        (root / "receipts").mkdir()
        (root / "receipts" / "files.json").write_text(json.dumps(dict(
            identity=dict(repo="example", commit="c" * 40, ids=["v0", "v1"]), files=files)))
        return root, prompts

    def decode(self, root, stage, video):
        for name in ("target_0.wav", "residual_0.wav"):
            (stage / name).write_bytes((video["composite_id"] + name).encode())
        return [dict(slot=0, reconstruction_max_abs=0)]

    def run_prepare(self, root, output, decoder=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return prep.prepare(root, output, decoder or self.decode)

    def test_all_prompts_ratios_preserved_and_repeat_skips_decode(self):
        with tempfile.TemporaryDirectory() as d:
            root, original = self.fixture(d)
            output = Path(d) / "prepared"
            first = self.run_prepare(root, output)
            self.assertEqual(first["scope"], "ENGINEERING_SUBSET")
            self.assertEqual(first["category_subtype_counts"], {"Appearance/test": 2, "Spatial/test": 2})
            rows = json.loads((output / "train_rows.json").read_text())
            for before, after in zip(original, rows):
                self.assertEqual(before, {k: after[k] for k in before})
            second = self.run_prepare(root, output, lambda *a: self.fail("Must not decode twice"))
            self.assertEqual(second["reused_composites"], 2)
            self.assertEqual(second["rows_sha256"], first["rows_sha256"])
            self.assertEqual(second["training_gt_anchors"], "NOT_PREPARED")

    def test_interrupted_composite_restarts_without_redoing_completed_one(self):
        with tempfile.TemporaryDirectory() as d:
            root, _ = self.fixture(d)
            output = Path(d) / "prepared"
            def interrupted(root, stage, video):
                if video["composite_id"] == "v1":
                    (stage / "diagnostic.txt").write_text("preserved")
                    raise RuntimeError("decode interrupted")
                return self.decode(root, stage, video)
            with self.assertRaises(RuntimeError):
                self.run_prepare(root, output, interrupted)
            self.assertFalse((output / "CPU_READY.json").exists())
            calls = []
            def resumed(root, stage, video):
                calls.append(video["composite_id"])
                return self.decode(root, stage, video)
            result = self.run_prepare(root, output, resumed)
            self.assertEqual(calls, ["v1"])
            self.assertEqual((result["new_composites"], result["reused_composites"]), (1, 1))
            self.assertEqual(len(list(output.glob(".staging-*/diagnostic.txt"))), 1)

    def test_source_corruption_invalidates_ready_before_reuse(self):
        with tempfile.TemporaryDirectory() as d:
            root, _ = self.fixture(d)
            output = Path(d) / "prepared"
            self.run_prepare(root, output)
            (root / "data/v0/target_0.wv").write_bytes(b"bad")
            with self.assertRaisesRegex(ValueError, "no longer matches"):
                self.run_prepare(root, output)
            self.assertFalse((output / "CPU_READY.json").exists())
            self.assertTrue(list((output / "history").glob("CPU_READY-*.json")))

    def test_prepared_audio_corruption_preserved_and_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root, _ = self.fixture(d)
            output = Path(d) / "prepared"
            self.run_prepare(root, output)
            bad = output / "v0/target_0.wav"
            bad.write_bytes(b"bad")
            with self.assertRaisesRegex(ValueError, "Prepared audio changed"):
                self.run_prepare(root, output)
            self.assertEqual(bad.read_bytes(), b"bad")
            self.assertFalse((output / "CPU_READY.json").exists())

    def test_missing_prompt_or_unknown_target_cannot_be_dropped(self):
        with tempfile.TemporaryDirectory() as d:
            root, prompts = self.fixture(d)
            (root / "prompts.jsonl").write_text("".join(json.dumps(x) + "\n" for x in prompts[:-1]))
            with self.assertRaisesRegex(ValueError, "retain all"):
                prep.selected_metadata(root)
            prompts[-1]["slot"] = 99
            (root / "prompts.jsonl").write_text("".join(json.dumps(x) + "\n" for x in prompts))
            with self.assertRaises(ValueError):
                prep.selected_metadata(root)

    def test_missing_media_receipt_rejected_before_decode(self):
        with tempfile.TemporaryDirectory() as d:
            root, _ = self.fixture(d)
            path = root / "receipts/files.json"
            receipt = json.loads(path.read_text())
            receipt["files"] = receipt["files"][1:]
            path.write_text(json.dumps(receipt))
            with self.assertRaisesRegex(ValueError, "incomplete verification"):
                self.run_prepare(root, Path(d) / "prepared", lambda *a: self.fail("Must not decode"))

    def test_gpu_allocation_rejected_before_output(self):
        with tempfile.TemporaryDirectory() as d:
            root, _ = self.fixture(d)
            output = Path(d) / "prepared"
            with patch.dict(os.environ, SLURM_JOB_GPUS="0"):
                with self.assertRaisesRegex(ValueError, "on CPU"):
                    self.run_prepare(root, output)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
