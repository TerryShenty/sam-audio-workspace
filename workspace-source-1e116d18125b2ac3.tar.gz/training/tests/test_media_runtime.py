import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import prepare_media_runtime as runtime


class RuntimeTests(unittest.TestCase):
    def lock(self):
        return {"schema_version": 1, "platform": "linux-64",
                "micromamba": {"name": "tool", "url": "https://example.org/tool",
                              "size": 3, "sha256": hashlib.sha256(b"abc").hexdigest()},
                "packages": [{"name": "ffmpeg", "version": "7.1.1", "build": "one",
                              "url": "https://example.org/ffmpeg.conda", "size": 3,
                              "sha256": hashlib.sha256(b"abc").hexdigest(), "md5": "a" * 32}]}

    def test_corrupt_cached_binary_is_never_reused(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "tool"
            path.write_bytes(b"bad")
            with self.assertRaisesRegex(ValueError, "integrity"):
                runtime.verify_cached(path, self.lock()["micromamba"])
            self.assertEqual(path.read_bytes(), b"bad")

    def test_same_filename_from_different_urls_rejected(self):
        lock = self.lock()
        lock["packages"][0]["url"] = "https://different.example/tool"
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "lock.json"
            path.write_text(json.dumps(lock))
            with self.assertRaisesRegex(ValueError, "colliding"):
                runtime.load_lock(path)

    def test_installed_package_identity_must_match_exactly(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "conda-meta").mkdir()
            path = root / "conda-meta/ffmpeg.json"
            path.write_text(json.dumps(dict(name="ffmpeg", version="7.1.1", build="one")))
            self.assertTrue(runtime.installed_matches(root, self.lock()))
            path.write_text(json.dumps(dict(name="ffmpeg", version="7.1.1", build="other")))
            self.assertFalse(runtime.installed_matches(root, self.lock()))

    def test_real_lock_has_sha_for_every_package(self):
        root = Path(__file__).resolve().parents[1]
        lock = runtime.load_lock(root / "configs/ffmpeg-linux-64-lock.json")
        self.assertEqual(len(lock["packages"]), 127)
        self.assertEqual(lock["ffmpeg_version"], "7.1.1")


if __name__ == "__main__":
    unittest.main()
