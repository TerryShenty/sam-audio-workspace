import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import standalone_workflow as w


class WorkflowTest(unittest.TestCase):
    def request(self):
        return dict(profile="engineering-hf13-public285", world=2,
                    revision=w.REVISION, ids=w.IDS, wandb_entity="test-owner",
                    wandb_project="test-project", reuse_model=None,
                    reuse_model_receipt=None, reuse_model_receipt_sha256=None)

    def test_import_and_help_do_not_import_torch(self):
        code = ("import sys;sys.path.insert(0," + repr(str(ROOT / "tools")) + ");"
                "import standalone_workflow;assert 'torch' not in sys.modules")
        subprocess.run([sys.executable, "-c", code], check=True)
        subprocess.run([sys.executable, str(ROOT / "tools/standalone_workflow.py"), "--help"],
                       check=True, stdout=subprocess.DEVNULL)

    def test_reuse_requires_explicit_identity(self):
        request = self.request()
        request["reuse_model"] = "/models/example"
        with self.assertRaises(ValueError):
            w.identity(request)

    def test_not_production_or_another_selection(self):
        for field, value in (("world", 9), ("ids", ["unknown"]),
                             ("profile", "production"), ("wandb_entity", "")):
            request = self.request()
            request[field] = value
            with self.assertRaises(ValueError):
                w.identity(request)

    def test_download_cannot_run_on_allocated_gpu(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, SLURM_JOB_GPUS="0,1"):
            with self.assertRaises(ValueError):
                w.execute(self.request(), Path(temp), "download",
                          runner=lambda *args: self.fail("GPU allocation started a CPU stage"))

    def test_missing_predecessor_rejects_before_intent(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with self.assertRaises(ValueError):
                w.execute(self.request(), root, "encode-training", "encode-training",
                          runner=lambda *args: self.fail("Skipped prerequisite"))
            self.assertFalse(list((root / "journal").glob("*INTENT*")))

    def test_accepted_stage_reused_then_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            request = self.request()
            calls = []
            def runner(req, directory, stage):
                calls.append(stage)
                w.write(directory / "avspeech/media/RELEASE.json", {"revision": w.REVISION})
                w.write(directory / "public-validation/media-release/DOWNLOAD_RECEIPT.json", {"status": "fake"})
                return {"status": "CONTROL_TEST_ONLY"}
            w.execute(request, root, "download", runner=runner)
            w.execute(request, root, "download", runner=runner)
            self.assertEqual(calls, ["download"])
            w.write(root / "avspeech/media/RELEASE.json", {"changed": True})
            with self.assertRaises(ValueError):
                w.execute(request, root, "download", runner=runner)
            self.assertEqual(calls, ["download"])

    def test_unknown_compute_intent_refuses_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); request = self.request()
            for stage in ("download", "prepare"):
                w.write(root / "journal" / (stage + ".json"),
                        dict(status="COMPLETE", request_identity=w.identity(request), outputs={}, result={}))
            w.write(root / "journal/encode-training-INTENT.json",
                    dict(status="STARTED", request_identity=w.identity(request)))
            with self.assertRaises(ValueError):
                w.execute(request, root, "encode-training", runner=lambda *args: self.fail("Blind compute retry"))

    def test_transfer_intent_can_resume_same_request(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); request = self.request()
            w.write(root / "journal/download-INTENT.json",
                    dict(status="STARTED", request_identity=w.identity(request)))
            def runner(req, directory, stage):
                w.write(directory / "avspeech/media/RELEASE.json", {})
                w.write(directory / "public-validation/media-release/DOWNLOAD_RECEIPT.json", {})
                return {"status": "CONTROL_TEST_ONLY"}
            self.assertEqual(w.execute(request, root, "download", runner=runner)["status"], "PREFIX_COMPLETE")

    def test_t5_revision_forwarded_to_weights_and_tokenizer(self):
        # Execute only the accepted constructor's loader calls with stubs. This
        # checks argument wiring; canonical tensor identity still needs real CPU.
        import ast
        source = ast.parse((ROOT / "src/sam_audio/model/text_encoder.py").read_text())
        cls = next(n for n in source.body if isinstance(n, ast.ClassDef))
        init = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "__init__")
        calls = []
        class Loader:
            @staticmethod
            def from_pretrained(name, **kwargs):
                calls.append((name, kwargs))
                return object()
        from types import SimpleNamespace
        begin = next(i for i,n in enumerate(init.body) if isinstance(n, ast.Assign)
                     and isinstance(n.targets[0], ast.Name) and n.targets[0].id == "revision")
        end = next(i for i,n in enumerate(init.body) if isinstance(n, ast.Assign)
                   and isinstance(n.targets[0], ast.Attribute) and n.targets[0].attr == "tokenizer")
        nodes = init.body[begin:end + 1]
        env = dict(os=os, transformers=SimpleNamespace(T5EncoderModel=Loader, AutoTokenizer=Loader),
                   self=SimpleNamespace(), cfg=SimpleNamespace(name="t5-base"))
        with patch.dict(os.environ, SAM_T5_REVISION="a" * 40, HF_HUB_OFFLINE="1"):
            exec(compile(ast.Module(body=nodes, type_ignores=[]), "<loader-wiring>", "exec"), env)
        self.assertEqual(calls, [("t5-base", {"revision": "a" * 40, "local_files_only": True})] * 2)

    def test_explicit_byte_import_is_independent_and_refuses_corruption(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); source = root / "original"; target = root / "imported"
            source.write_bytes(b"accepted")
            w.copy_verified(source, target, w.sha(source))
            self.assertNotEqual(source.stat().st_ino, target.stat().st_ino)
            self.assertFalse(target.is_symlink())
            target.write_bytes(b"corrupt!")
            with self.assertRaises(ValueError):
                w.copy_verified(source, target, w.sha(source))
            self.assertEqual(source.read_bytes(), b"accepted")


if __name__ == "__main__":
    unittest.main()
