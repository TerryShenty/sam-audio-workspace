"""Control/partition tests only; these do not claim real multi-GPU acceptance."""
import ast
from collections import Counter, defaultdict
import copy
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "src"))
import gpu_profile as gp
import standalone_workflow as workflow
import public_entry as entry
import public_validation_contract as vc
from public_validation_export import validation_fragment
from workflow_contract import shards, check_ranks, key, write
from delivery_cohort import check


class GPUCompatibilityTests(unittest.TestCase):
    def devices(self, n):
        return [dict(uuid=f"GPU-{i}", name="A100", capability=[8, 0],
                     memory_bytes=40*1024**3, bf16=True) for i in range(n)]

    def test_1_to_8_actual_sampler_coverage_and_accumulation(self):
        # Execute the actual pure-Python sampler implementation without Torch.
        tree = ast.parse((ROOT / "src/sam_audio/native_finetuning/optimized_utils.py").read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "LengthBucketPlan")
        env = dict(math=math, random=random, Counter=Counter, defaultdict=defaultdict)
        exec(compile(ast.Module(body=[cls], type_ignores=[]), "<actual-sampler>", "exec"), env)
        for world in range(1, 9):
            for batch in (max(2, world), world*2):
                with self.subTest(world=world, batch=batch):
                    shape = gp.profile(world, batch)
                    all_real = []
                    updates = []
                    for rank in range(world):
                        p = env["LengthBucketPlan"]([250]*9+[500]*4, world_size=world,
                            rank=rank, micro_batch=1, accumulation=shape["accumulation"],
                            exact_lengths=True)
                        self.assertEqual(p.updates_per_epoch, shape["updates_per_epoch"])
                        local = list(p)
                        all_real.extend(v[1] for row in local for v in row if v[2])
                        updates.append([row[0][5] for row in local if row[0][4]])
                    self.assertEqual(sorted(all_real), list(range(13)))
                    self.assertTrue(all(x == updates[0] for x in updates))
                    self.assertGreaterEqual(shape["epochs"]*len(updates[0]), 9)

    def test_default_on_large_host_uses_only_two(self):
        for count in (2, 4, 8, 16):
            result = gp.check_inventory(self.devices(count), gp.profile()["gpus"], {})
            self.assertEqual(result["selected_count"], 2)
            self.assertEqual(result["unused_visible_count"], count-2)
        with self.assertRaises(ValueError):
            gp.check_inventory(self.devices(1), 2, {})

    def test_hardware_negatives_before_launch(self):
        for change in (dict(memory_bytes=16*1024**3), dict(bf16=False),
                       dict(uuid="MIG-instance"), dict(name="different GPU"),
                       dict(uuid="GPU-0")):
            d = self.devices(2);d[1].update(change)
            with self.assertRaises(ValueError): gp.check_inventory(d, 2, {})
        for env in ({"WORLD_SIZE":"2"}, {"SLURM_JOB_NUM_NODES":"2"},
                    {"SLURM_JOB_GPUS":"0,1,2,3"}):
            with self.assertRaises(ValueError): gp.check_inventory(self.devices(4), 2, env)

    def test_invalid_counts_and_batch_do_not_silently_change(self):
        for n in (0, -1, 9, True, 2.5):
            with self.assertRaises(ValueError): gp.profile(n)
        for n in (0, 2, 6, True):
            with self.assertRaises(ValueError): gp.profile(4, n)
        self.assertEqual(gp.profile(1)["accumulation"], 2)
        self.assertEqual(gp.profile(4)["global_batch"], 4)

    def test_training_encoder_nonempty_and_complete(self):
        plan = dict(mixtures={str(i): {} for i in range(3)}, texts={str(i): {} for i in range(12)})
        for world in range(1, 9):
            ranks = gp.profile(world)["training_encoder_gpus"]
            reports = []
            for rank in range(ranks):
                assigned = shards(plan, rank, ranks)
                reports.append(dict(rank=rank, world=ranks, gpu_uuid=f"GPU-{rank}",
                    status="ENCODED", identity="test", assigned={k: sorted(v) for k,v in assigned.items()},
                    new_components=dict(mixture=len(assigned["mixtures"]), video=len(assigned["mixtures"]))))
            check_ranks(reports, plan, ranks, "test")
            self.assertEqual(sorted(k for r in reports for k in r["assigned"]["mixtures"]), ["0","1","2"])
            with self.assertRaises(ValueError): check_ranks(reports[:-1], plan, ranks, "test")

    def fixture(self, world, output):
        rows = json.loads((ROOT / "tests/fixtures/public-validation.json").read_text())["rows"]
        cohort = check(rows)
        plan = dict(world=world, rows=rows, cohort=cohort, media_root="/public",
                    public_revision="a"*40, expected_base={"verified":True},
                    representative_indexes=vc.REPRESENTATIVE_INDEXES, **vc.RECIPE)
        cfg = dict(plan_identity=key(plan), input_sha256="b"*64,
                   public_revision=plan["public_revision"], selection="all285",
                   expected_counts={"msdwild":78,"easycom":207})
        ready = dict(plan_identity=key(plan), status="CPU_PUBLIC_VALIDATION_INPUT_READY",
                     input_sha256=cfg["input_sha256"], public_revision=plan["public_revision"],
                     cohort=cohort, media_files={str(Path("/public")/r[f]):dict(sha256="c"*64, bytes=10)
                         for r in rows for f in ("video","mixture_audio","gt_audio")})
        sig = dict(verified_base=plan["expected_base"], dtype="bfloat16", max_seconds=None,
                   video_frame_chunk=8, allow_tf32=True)
        reports = []
        for rank in range(world):
            records = [dict(row=r, path=str(output/f"rank-{rank}"/f"row-{r['index']}.pt"),
                            finite=True, anchor_ids=[[0,3]], latent_frames=r["latent_frames"],
                            encoding_seconds=1.0, row_seconds=1.1, peak_gpu_bytes=100,
                            sha256="d"*64, bytes=50) for r in rows[rank::world]]
            reports.append(dict(rank=rank, world=world, gpu_uuid=f"GPU-{rank}", status=vc.STATUS,
                plan_identity=cfg["plan_identity"], input_sha256=cfg["input_sha256"],
                recipe=vc.RECIPE, gt_audio_read=False, model_signature=sig, rows=records))
        return plan, ready, cfg, reports

    def test_every_world_full285_merge_export_exact_original_rows(self):
        with tempfile.TemporaryDirectory() as d:
            for world in range(1, 9):
                plan, ready, cfg, reports = self.fixture(world, Path(d))
                merged = vc.merge(reports, plan, ready, cfg, d)
                self.assertEqual([r["row"]["index"] for r in merged], list(range(285)))
                audit = dict(status="PASS_ALL285_PUBLIC_ENCODING_AND_CPU_TENSORS",
                    full285_features_ready=True, public_revision=plan["public_revision"],
                    plan_identity=cfg["plan_identity"], input_sha256=cfg["input_sha256"], rows=merged)
                validation, files = validation_fragment(audit, plan, ready, d)
                self.assertEqual([r["original_public_row"] for r in validation["items"]], plan["rows"])
                self.assertEqual(len([f for f in files if f["destination"].endswith(".pt")]), 285)
                broken = copy.deepcopy(reports); broken[-1]["rows"].pop()
                with self.assertRaises(ValueError): vc.merge(broken, plan, ready, cfg, d)
                with self.assertRaises(ValueError): vc.merge(reports+reports[:1], plan, ready, cfg, d)

    def test_training_rank_completeness_steps_and_nan(self):
        for world in (1,2,4,8):
            r = [dict(rank=n, gpu_uuid=f"GPU-{n}", world_size=world, status="PASS",
                      forwards=[dict(finite=True, positives=250)],
                      updates=[dict(before=0, after=1, delta=0.001)]) for n in range(world)]
            gp.receipts(r, world)
            bad=copy.deepcopy(r);bad[-1]["updates"][0]["delta"]=float("nan")
            with self.assertRaises(ValueError):gp.receipts(bad, world)
            with self.assertRaises(ValueError):gp.receipts(r[:-1], world)
            if world>1:
                bad=copy.deepcopy(r);bad[-1]["updates"][0].update(before=1,after=2)
                with self.assertRaises(ValueError):gp.receipts(bad, world)

    def test_command_gpus_batch_epochs_agree_for_every_world(self):
        for world in range(1,9):
            req=dict(gpus=world, training_config="/config", data_root="/data", model="/model",
                     directory="/run", python="/python", hf_hub_cache="/cache",
                     wandb_entity="owner", wandb_project="project")
            p=gp.profile(world);cmd=entry.command(req)
            self.assertEqual(cmd[cmd.index("--global-batch")+1],str(p["global_batch"]))
            self.assertEqual(cmd[cmd.index("--epochs")+1],str(p["epochs"]))
            self.assertEqual(entry.environment(req, {})["GPUS"],str(world))

    def test_four_rank_training_encoder_launches_three_and_checks_three(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            write(root/"journal/prepare.json",dict(result=dict(inputs={})))
            write(root/"training-encode.json",dict(base_signature={}))
            write(root/"encoder-input/cache_plan.json",dict(mixtures={},texts={}))
            for rank in range(3):write(root/f"encoded/rank{rank}.json",dict(rank=rank))
            with patch.object(workflow.subprocess,"run") as run, patch.object(workflow,"check_ranks") as check:
                workflow.gpu_stage(dict(world=4, python="/python"),root,"encode-training")
            self.assertIn("--nproc_per_node=3",run.call_args.args[0])
            self.assertEqual(check.call_args.args[2],3)
            self.assertEqual(len(check.call_args.args[0]),3)

    def test_plan_cli_no_install_gpu_or_network(self):
        for world in (1,2,4,8):
            result=subprocess.run(["bash",str(ROOT/"start.sh"),"--gpu-plan","--gpus",str(world)],
                                  capture_output=True,text=True,env={**os.environ,"SAM_PYTHON":sys.executable})
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(json.loads(result.stdout)["gpus"],world)

    def test_workspace_world_change_fails_before_stage(self):
        with tempfile.TemporaryDirectory() as d:
            write(Path(d)/"WORKFLOW_REQUEST.json",dict(world=2,global_batch=2))
            result=subprocess.run([sys.executable,str(ROOT/"tools/standalone_workflow.py"),
                                   "--directory",d,"--gpus","4"],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertIn("GPU count changed",result.stderr)
            self.assertFalse((Path(d)/"journal").exists())

    def test_insufficient_devices_does_not_leave_compute_intent(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            req=dict(profile="engineering-hf13-public285",world=4,global_batch=4,
                     revision=workflow.REVISION,ids=workflow.IDS,
                     wandb_entity="owner",wandb_project="project")
            for stage in ("download","prepare"):
                write(root/"journal"/(stage+".json"),
                      dict(status="COMPLETE",request_identity=workflow.identity(req),outputs={},result={}))
            with patch.object(workflow,"probe",side_effect=ValueError("insufficient devices")):
                with self.assertRaises(ValueError):
                    workflow.execute(req,root,"encode-training",
                                     runner=lambda *a:self.fail("worker launched"))
            self.assertFalse((root/"journal/encode-training-INTENT.json").exists())

    def test_real_resume_world_guard_still_rejects_resharding(self):
        tree=ast.parse((ROOT/"src/sam_audio/native_finetuning/delivery_impl.py").read_text())
        node=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
                  and ast.unparse(n.test)=="checkpoint['world_size'] != world")
        code=compile(ast.Module(body=[node],type_ignores=[]),"<actual-resume-guard>","exec")
        for world in (1,2,4,8):
            exec(code,dict(checkpoint={"world_size":world},world=world))
            with self.assertRaisesRegex(ValueError,"same world size"):
                exec(code,dict(checkpoint={"world_size":2},world=1 if world==2 else world))


if __name__ == "__main__":
    unittest.main()
