import csv,hashlib,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import repair_decord_metadata as m

class MetadataTests(unittest.TestCase):
 def fixture(self, root):
  info=root/'decord-0.6.0.dist-info';info.mkdir();(root/'decord').mkdir()
  (root/'decord/libdecord.so').write_bytes(b'native-fixture')
  (info/'WHEEL').write_text(m.ORIGINAL)
  (info/'RECORD').write_text(info.name+'/WHEEL,old,1\n')
  return info
 def test_repair_retains_binary_and_is_idempotent(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);i=self.fixture(r)
   with patch.object(m,'LIB_SHA',hashlib.sha256(b'native-fixture').hexdigest()):
    result=m.repair(i,r/'receipt.json',lambda:{'status':'PASS'})
    self.assertFalse(result['binary_modified']);self.assertEqual((i/'WHEEL').read_text(),m.CORRECTED)
    self.assertEqual((r/'receipt.original/WHEEL').read_text(),m.ORIGINAL)
    self.assertEqual(m.repair(i,r/'receipt.json',lambda:{'status':'PASS'})['status'],'ALREADY_CORRECTED')
 def test_unknown_binary_not_patched(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);i=self.fixture(r)
   with self.assertRaisesRegex(ValueError,'Unknown decord native'):m.repair(i,r/'receipt.json',lambda:{'status':'PASS'})
   self.assertEqual((i/'WHEEL').read_text(),m.ORIGINAL)
 def test_post_decode_failure_rolls_back_both_metadata_files(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);i=self.fixture(r);old=(i/'RECORD').read_bytes();calls=iter([{'status':'PASS'},{'status':'FAIL'}])
   with patch.object(m,'LIB_SHA',hashlib.sha256(b'native-fixture').hexdigest()):
    with self.assertRaisesRegex(ValueError,'Post-repair'):m.repair(i,r/'receipt.json',lambda:next(calls))
   self.assertEqual((i/'WHEEL').read_text(),m.ORIGINAL);self.assertEqual((i/'RECORD').read_bytes(),old)
   self.assertFalse((r/'receipt.json').exists())
