import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src/sam_audio/native_finetuning/delivery_save_schedule.py'
s=importlib.util.spec_from_file_location('schedule',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class HalfEpochTests(unittest.TestCase):
 def test_even(self):self.assertEqual([i for i in range(9) if m.half_epoch_due(i,8,True)],[4])
 def test_odd(self):self.assertEqual([i for i in range(8) if m.half_epoch_due(i,7,True)],[4])
 def test_one_or_disabled(self):
  self.assertFalse(m.half_epoch_due(0,1,True));self.assertFalse(m.half_epoch_due(4,8,False))
 def test_resume_after_midpoint(self):self.assertFalse(any(m.half_epoch_due(i,8,True) for i in range(5,9)))
