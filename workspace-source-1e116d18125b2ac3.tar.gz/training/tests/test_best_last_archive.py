"""Local state-machine tests; no live W&B or model-resume claim."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from archive_best_last import archive, plan


class BestLastTests(unittest.TestCase):
    def fixture(self, root, status="COMPLETE"):
        (root / "RESULT.json").write_text(json.dumps({"status": status}))
        (root / "effective-config.json").write_text('{"engineering_validation_subset":true}')
        (root / "latest-checkpoint.json").write_text('{"path":"final.pt","global_step":9}')
        for name, scores in [("half-1", (4, 2)), ("final", (1, 1))]:
            (root / (name + ".pt")).write_bytes(name.encode())
            directory = root / "validation" / name
            directory.mkdir(parents=True)
            (directory / "summary.json").write_text(json.dumps({
                "msdwild": {"n": 1, "aligned_si_sdr_db": scores[0]},
                "easycom": {"n": 1, "aligned_si_sdr_db": scores[1]},
            }))
        return plan(root, {"msdwild": 1, "easycom": 1}, True)

    def receipt(self, planned, checkpoint):
        record = next(row for row in planned["roles"].values() if row["checkpoint"] == checkpoint)
        return {"artifact": "team/project/" + checkpoint.replace(".", "-") + ":v0",
                "checkpoint": checkpoint, "files": record["manifest"]["files"],
                "verified_download_files": len(record["manifest"]["files"]),
                "content_roundtrip": "PASS", "model_resume": "NOT_TESTED"}

    def test_failed_run_and_unmarked_subset_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with self.assertRaisesRegex(ValueError, "completed"):
                self.fixture(root, "FAILED")
            (root / "RESULT.json").write_text('{"status":"COMPLETE"}')
            with self.assertRaisesRegex(ValueError, "Formal"):
                plan(root, {"msdwild": 1, "easycom": 1})

    @patch.dict(os.environ, {"SLURM_JOB_GPUS": "", "SLURM_STEP_GPUS": ""})
    def test_best_and_last_remain_distinct_and_repeat_does_not_upload(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); planned = self.fixture(root); calls = []
            def upload(root, checkpoint, env):
                calls.append(checkpoint)
                return self.receipt(planned, checkpoint)
            result = archive(root, planned, "team", "project", upload)
            self.assertEqual(calls, ["half-1.pt", "final.pt"])
            self.assertEqual(result["roles"]["best"]["checkpoint"], "half-1.pt")
            self.assertFalse(result["server_cleanup"])
            archive(root, planned, "team", "project", upload)
            self.assertEqual(len(calls), 2)
            (root / "half-1.pt").write_bytes(b"modified")
            with self.assertRaisesRegex(ValueError, "mismatch"):
                archive(root, planned, "team", "project", upload)

    @patch.dict(os.environ, {"SLURM_JOB_GPUS": "", "SLURM_STEP_GPUS": ""})
    def test_unknown_outcome_blocks_repeat_but_verified_receipt_reconciles(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); planned = self.fixture(root); calls = []
            def interrupted(root, checkpoint, env):
                calls.append(checkpoint)
                raise TimeoutError("unknown")
            with self.assertRaises(TimeoutError):
                archive(root, planned, "team", "project", interrupted)
            with self.assertRaisesRegex(ValueError, "Unknown prior"):
                archive(root, planned, "team", "project", interrupted)
            self.assertEqual(len(calls), 1)
            (root / "upload_receipts").mkdir()
            (root / "upload_receipts" / "verified.json").write_text(
                json.dumps(self.receipt(planned, "half-1.pt")))
            def upload(root, checkpoint, env):
                calls.append(checkpoint)
                return self.receipt(planned, checkpoint)
            result = archive(root, planned, "team", "project", upload)
            self.assertEqual(calls, ["half-1.pt", "final.pt"])
            self.assertIn("PASS", result["status"])

    @patch.dict(os.environ, {"SLURM_JOB_GPUS": "0,1"})
    def test_slurm_gpu_allocation_cannot_start_archive(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); planned = self.fixture(root)
            with self.assertRaisesRegex(ValueError, "Slurm GPU"):
                archive(root, planned, "team", "project")


if __name__ == "__main__":
    unittest.main()
