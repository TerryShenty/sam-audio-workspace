"""Fake SDK tests; do not imply live collaborator permissions."""
import os, sys, tempfile, types, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from delivery_tracking import Tracker

class DestinationTests(unittest.TestCase):
    def test_shared_default_and_explicit_override(self):
        for override, expected in [(None, 'terryshen066-fudan-university'), ('authorized-team', 'authorized-team')]:
            calls=[]
            sdk=types.SimpleNamespace(util=types.SimpleNamespace(generate_id=lambda:'fixed-test'), init=lambda **kw:calls.append(kw))
            env={'WANDB_MODE':'online'}
            if override: env['WANDB_ENTITY']=override
            with tempfile.TemporaryDirectory() as out, patch.dict(os.environ,env,clear=True), patch.dict(sys.modules,{'wandb':sdk}):
                Tracker(out,{},0)
            self.assertEqual(calls[0]['entity'],expected)
            self.assertEqual(calls[0]['project'],'sam-audio')

    def test_nonzero_rank_does_not_initialize(self):
        with tempfile.TemporaryDirectory() as out, patch.dict(os.environ,{'WANDB_MODE':'online'},clear=True):
            tracker=Tracker(out,{},1)
            self.assertIsNone(tracker.run)
            self.assertFalse((Path(out)/'wandb-run-id.txt').exists())
