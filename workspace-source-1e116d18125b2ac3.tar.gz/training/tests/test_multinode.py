import ast
import copy
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tools")]
from delivery_topology import from_environment, validate_peers
from launch_multinode import command_and_environment


def env(rank, world=2, local_world=1):
    return dict(RANK=str(rank), WORLD_SIZE=str(world), LOCAL_RANK=str(rank % local_world),
                LOCAL_WORLD_SIZE=str(local_world), GROUP_RANK=str(rank // local_world))


class MultinodeTests(unittest.TestCase):
    def test_two_servers_each_uses_local_zero(self):
        ranks = [from_environment(env(r), allow_multinode=True) for r in range(2)]
        self.assertEqual([r.rank for r in ranks], [0, 1])
        self.assertEqual([r.local_rank for r in ranks], [0, 0])
        self.assertEqual([r.node_rank for r in ranks], [0, 1])

    def test_two_servers_four_gpus_each(self):
        for rank in range(8):
            t = from_environment(env(rank, 8, 4), allow_multinode=True)
            self.assertEqual((t.node_rank, t.local_rank), divmod(rank, 4))

    def test_single_node_mapping_is_unchanged(self):
        for rank in range(4):
            t = from_environment(env(rank, 4, 4))
            self.assertEqual((t.nodes, t.rank, t.local_rank), (1, rank, rank))

    def test_missing_rank_never_defaults_to_local(self):
        e = env(1)
        del e["RANK"]
        with self.assertRaisesRegex(ValueError, "complete"):
            from_environment(e, allow_multinode=True)

    def test_explicit_multinode_required(self):
        with self.assertRaisesRegex(ValueError, "explicit"):
            from_environment(env(1))

    def test_bad_mapping_nonuniform_and_restarts_rejected(self):
        for changes in [dict(LOCAL_RANK="1"), dict(GROUP_RANK="0"),
                        dict(WORLD_SIZE="3", LOCAL_WORLD_SIZE="2"),
                        dict(TORCHELASTIC_RESTART_COUNT="1"), dict(RANK="2")]:
            e = dict(env(1), **changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                from_environment(e, allow_multinode=True)

    def peers(self):
        topologies = [from_environment(env(r), allow_multinode=True) for r in range(2)]
        peers = [t.peer({"config": "same", "bundle": "same"}, f"machine-{t.node_rank}") for t in topologies]
        return topologies[0], peers

    def test_provider_placement_and_inputs_match(self):
        t, peers = self.peers()
        self.assertEqual(validate_peers(peers[::-1], t, expected_machine_ids=["machine-0", "machine-1"]), peers)

    def test_missing_duplicate_stale_identity_and_fake_placement(self):
        t, original = self.peers()
        cases = [original[:1], [original[0], original[0]]]
        for key, value in [("input_identity", {"bundle": "other"}), ("machine_id", "machine-0"),
                           ("local_rank", 1), ("world", 4)]:
            peers = copy.deepcopy(original)
            peers[1][key] = value
            cases.append(peers)
        for peers in cases:
            with self.subTest(peers=peers), self.assertRaises(ValueError):
                validate_peers(peers, t, expected_machine_ids=["machine-0", "machine-1"])
        with self.assertRaises(ValueError):
            validate_peers(original, t, expected_machine_ids=["same-machine"] * 2)

    def arguments(self):
        return SimpleNamespace(nodes=2, gpus_per_node=1, node_rank=1,
            machine_ids=["machine-0", "machine-1"], machine_id="machine-1",
            master_address="node0.runpod.internal", master_port=29500,
            cpu_input_identity="a" * 64, timeout=120, phase="probe",
            training_args=[], output=Path("/workspace/proof"))

    def test_launch_uses_static_two_nodes_and_never_restarts(self):
        command, child = command_and_environment(self.arguments(), {})
        self.assertIn("--nnodes=2", command)
        self.assertIn("--node_rank=1", command)
        self.assertIn("--nproc_per_node=1", command)
        self.assertIn("--max-restarts=0", command)
        self.assertNotIn("--standalone", command)
        self.assertEqual(child["HF_HUB_OFFLINE"], "1")
        self.assertEqual(child["SAM_MULTINODE_PROBE"], "1")

    def test_unsafe_launch_rejected_before_any_process(self):
        for changes in [dict(machine_id="wrong"), dict(machine_ids=["same"] * 2),
                        dict(timeout=0), dict(timeout=1801), dict(master_address="localhost"),
                        dict(cpu_input_identity="missing"), dict(node_rank=2)]:
            args = self.arguments()
            for k, v in changes.items():
                setattr(args, k, v)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                command_and_environment(args, {})
        with self.assertRaises(ValueError):
            command_and_environment(self.arguments(), {"LOCAL_RANK": "0"})

    def test_training_is_not_implicitly_rewritten(self):
        a = self.arguments()
        a.phase = "train"
        a.training_args = ["--", "/workspace/source/src/train_delivery.py", "--multi-node",
                           "--resume", "/workspace/run/step-2.pt"]
        command, child = command_and_environment(a, {"NCCL_P2P_DISABLE": "0"})
        self.assertEqual(command[-len(a.training_args[1:]):], a.training_args[1:])
        self.assertEqual(child["NCCL_P2P_DISABLE"], "0")
        a.training_args.remove("--multi-node")
        with self.assertRaises(ValueError):
            command_and_environment(a, {})

    def test_gpu_device_selection_does_not_use_global_rank(self):
        for relative in ("src/delivery_validation.py", "src/delivery_runtime_audit.py"):
            tree = ast.parse((ROOT / relative).read_text())
            for call in [n for n in ast.walk(tree) if isinstance(n, ast.Call)]:
                if isinstance(call.func, ast.Attribute) and call.func.attr in (
                        "get_device_properties", "max_memory_allocated"):
                    self.assertNotIn(ast.unparse(call.args[0]), ("rank", "self.rank"))
        source = (ROOT / "src/train_delivery.py").read_text()
        self.assertIn("torch.cuda.set_device(local_rank)", source)
        self.assertIn("rank=topology.rank", source)


if __name__ == "__main__":
    unittest.main()
