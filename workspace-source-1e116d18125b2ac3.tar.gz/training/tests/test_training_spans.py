import copy
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from prepare_training_spans import support, prepare
import prepare_selected_media as media_prep


class TrainingSupportTests(unittest.TestCase):
    def fixture(self, mode="temporal", arity=3):
        targets = [dict(slot=i, source_id=f"s{i}", window_id=f"w{i}") for i in range(arity)]
        video = dict(composite_id="c", mode=mode, arity=arity,
                     samples=480000 * (arity if mode == "temporal" else 1),
                     sample_rate=48000, targets=targets)
        recipe = dict(composite_id="c", mode=mode, arity=arity, final_recipe_frozen=True,
                      state="READY", inputs=[dict(t, start=123.25, end=133.25,
                          crop_xywh=[11, 13, 224, 224], output_size=[256, 256],
                          visible=False) for t in targets])
        return video, recipe

    def test_temporal_uses_composite_offset_not_absolute_source_time(self):
        video, recipe = self.fixture()
        before = copy.deepcopy(recipe)
        self.assertEqual([support(video, recipe, t)["intervals_seconds"] for t in video["targets"]],
                         [[[0., 10.]], [[10., 20.]], [[20., 30.]]])
        self.assertEqual(recipe, before)

    def test_all_simultaneous_targets_including_offscreen_retain_full_support(self):
        for mode in ("spatial", "visibility", "onscreen_offscreen"):
            video, recipe = self.fixture(mode)
            for target in video["targets"]:
                result = support(video, recipe, target)
                self.assertEqual(result["support_samples"], [0, 480000])
                self.assertFalse(result["visible"])
                self.assertEqual(result["crop_xywh"], [11, 13, 224, 224])

    def test_unknown_layout_unfrozen_recipe_or_wrong_duration_refused(self):
        for change in ("mode", "frozen", "duration", "window"):
            video, recipe = self.fixture()
            if change == "mode":
                video["mode"] = recipe["mode"] = "new-rule"
            elif change == "frozen":
                recipe["final_recipe_frozen"] = False
            elif change == "duration":
                video["samples"] -= 1
            else:
                recipe["inputs"][0]["end"] -= .1
            with self.assertRaises(ValueError):
                support(video, recipe, video["targets"][0])

    def test_missing_or_reordered_source_identity_refused(self):
        video, recipe = self.fixture()
        recipe["inputs"][0], recipe["inputs"][1] = recipe["inputs"][1], recipe["inputs"][0]
        with self.assertRaises(ValueError):
            support(video, recipe, video["targets"][0])
        video, recipe = self.fixture()
        video["targets"].pop()
        with self.assertRaises(ValueError):
            support(video, recipe, video["targets"][0])

    def test_bad_crop_and_nonfinite_source_time_refused(self):
        for field, value in [("crop_xywh", [0, 0, 0, 10]), ("start", float("nan")),
                             ("visible", "false")]:
            video, recipe = self.fixture()
            recipe["inputs"][0][field] = value
            with self.assertRaises(ValueError):
                support(video, recipe, video["targets"][0])

    def prepared_fixture(self, directory):
        root = Path(directory)
        media, prepared = root / "media", root / "prepared"
        media.mkdir()
        video, recipe = self.fixture(arity=2)
        video["recipe_sha256"] = "a" * 64  # Original hash, before public URI rewrite.
        prompts = []
        for target in video["targets"]:
            target["prompt_count"] = 2
            for i in range(2):
                prompts.append(dict(composite_id="c", slot=target["slot"],
                    source_id=target["source_id"], window_id=target["window_id"],
                    prompt_id=f"{target['slot']}-{i}", prompt=f"Original prompt {i}",
                    category="Temporal", subtype="order", recipe_sha256="a" * 64))
        (media / "data/c").mkdir(parents=True)
        (media / "data/c/recipe.json").write_text(json.dumps(recipe))
        for name in ["video.mp4", "mixture.wav"] + [
                f"{kind}_{i}.wv" for i in range(2) for kind in ("target", "residual")]:
            (media / "data/c" / name).write_bytes(name.encode())
        (media / "videos.jsonl").write_text(json.dumps(video) + "\n")
        (media / "prompts.jsonl").write_text("".join(json.dumps(r) + "\n" for r in prompts))
        (media / "RELEASE.json").write_text(json.dumps(dict(repo="TerryShenty/avspeech-93942",
            revision="b"*40, videos=1, status=dict(expected_videos=100, expected_targets=200,
                                                  prompts_available=400))))
        (media / "receipts").mkdir()
        (media / "receipts/files.json").write_text(json.dumps(dict(
            identity=dict(commit="c"*40),
            files=[dict(path=p.relative_to(media).as_posix(), bytes=p.stat().st_size,
                        sha256=media_prep.digest(p)) for p in (media / "data/c").iterdir()])))
        def decoder(root, stage, video):
            for i in range(2):
                for kind in ("target", "residual"):
                    (stage / f"{kind}_{i}.wav").write_bytes(f"{i}-{kind}".encode())
            return []
        with contextlib.redirect_stdout(io.StringIO()):
            media_prep.prepare(media, prepared, decoder)
        return media, prepared

    def audit_stub(self, *args):
        return dict(outside_nonzero=0, inside_nonzero=1, sample_count=args[1])

    def test_multi_prompt_preservation_and_distinct_recipe_hashes(self):
        with tempfile.TemporaryDirectory() as d:
            media, prepared = self.prepared_fixture(d)
            output = Path(d) / "support"
            result = prepare(media, prepared, output, self.audit_stub)
            self.assertEqual((result["targets"], result["prompts"]), (2, 4))
            original = json.loads((prepared / "train_rows.json").read_text())
            rows = json.loads((output / "train_rows.json").read_text())
            for old, new in zip(original, rows):
                self.assertEqual(old, {k: new[k] for k in old})
                self.assertEqual(new["training_gt_spans"], [[old["slot"]*10., old["slot"]*10.+10]])
            targets = json.loads((output / "targets.json").read_text())
            self.assertNotEqual(targets[0]["recipe_sha256"], targets[0]["archived_recipe_sha256"])
            repeated = prepare(media, prepared, output, self.audit_stub)
            self.assertEqual(result["files"], repeated["files"])
            self.assertFalse(repeated["training_ready"])

    def test_changed_recipe_or_waveform_invalidates_ready(self):
        for name in ("recipe", "wave"):
            with tempfile.TemporaryDirectory() as d:
                media, prepared = self.prepared_fixture(d)
                output = Path(d) / "support"
                prepare(media, prepared, output, self.audit_stub)
                damaged = media / "data/c/recipe.json" if name == "recipe" else prepared / "c/target_0.wav"
                damaged.write_bytes(b"corrupt")
                with self.assertRaises(ValueError):
                    prepare(media, prepared, output, self.audit_stub)
                self.assertFalse((output / "GT_SUPPORT_READY.json").exists())
                self.assertTrue(list((output / "attempts").glob("*/PREVIOUS_READY.json")))
                self.assertEqual(damaged.read_bytes(), b"corrupt")

    def test_changed_prompt_or_redirected_gt_path_refused(self):
        for field, value in (("prompt", "changed"), ("gt_audio_path", "/different/target.wav")):
            with tempfile.TemporaryDirectory() as d:
                media, prepared = self.prepared_fixture(d)
                rows = json.loads((prepared / "train_rows.json").read_text())
                rows[0][field] = value
                (prepared / "train_rows.json").write_text(json.dumps(rows))
                ready = json.loads((prepared / "CPU_READY.json").read_text())
                ready["rows_sha256"] = media_prep.digest(prepared / "train_rows.json")
                (prepared / "CPU_READY.json").write_text(json.dumps(ready))
                with self.assertRaises(ValueError):
                    prepare(media, prepared, Path(d) / "support", self.audit_stub)


if __name__ == "__main__":
    unittest.main()
