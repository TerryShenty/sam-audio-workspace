import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from delivery_score_summary import summarize
class SummaryTests(unittest.TestCase):
 def row(self,i,ds,v):return {'index':i,'dataset':ds,'aligned_si_sdr_db':v,'si_sdr_db':v-1,'si_sdri_db':v+2}
 def test_complete_metrics_and_coordinates(self):
  summary,logged=summarize([self.row(1,'easycom',2),self.row(2,'easycom',4),self.row(3,'msdwild',8)],{'global_step':123,'checkpoint':'half-1.pt'})
  self.assertEqual(summary['easycom'],{'n':2,'aligned_si_sdr_db':3,'si_sdr_db':2,'si_sdri_db':5})
  self.assertEqual(logged['validation/msdwild/n'],1);self.assertEqual(logged['validation/global_step'],123)
 def test_nonfinite_rejected(self):
  with self.assertRaises(ValueError):summarize([self.row(1,'easycom',float('nan'))])
 def test_duplicate_rejected(self):
  with self.assertRaises(ValueError):summarize([self.row(1,'easycom',2)]*2)
