import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from validation_export_plan import build


class ValidationPlanTests(unittest.TestCase):
    def fixture(self, root):
        (root/'feature.pt').write_bytes(b'original-feature')
        (root/'audio.wav').write_bytes(b'fixture-audio')
        return {'row': {'row_index': 46, 'dataset':'msdwild', 'clip_id':'clip',
                        'target_source_id':'2', 'prompt':'the first speaker',
                        'gt_audio_path':str(root/'audio.wav'), 'mixture_audio_path':str(root/'audio.wav')},
                'source_row_index':9, 'noise_seed':20260726,
                'features':{'path':str(root/'feature.pt'), 'latent_frames':500,
                            'sha256':hashlib.sha256(b'original-feature').hexdigest()}}
    def test_identity_seed_duration_and_shared_media(self):
        with tempfile.TemporaryDirectory() as d:
            row=self.fixture(Path(d));result=build([row]);item=result['validation']['items'][0]
            self.assertEqual((item['index'],item['source_row_index'],item['noise_seed'],item['latent_frames']), (46,9,20260726,500))
            self.assertEqual(item['gt_audio'],item['mixture_audio'])
            self.assertEqual(len(result['files']),2)
            self.assertFalse(Path(item['features_file']).is_absolute())
    def test_missing_or_changed_features_fail_without_silent_replacement(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);row=self.fixture(r);(r/'feature.pt').write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError,'unavailable or changed'):build([row])
            self.assertEqual(build([row],verify_files=False)['audit']['status'],'PLAN_ONLY')
    def test_cohort_and_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            row=self.fixture(Path(d))
            with self.assertRaisesRegex(ValueError,'count mismatch'):build([row],expected={'msdwild':78})
            with self.assertRaisesRegex(ValueError,'duplicate'):build([row,row])
