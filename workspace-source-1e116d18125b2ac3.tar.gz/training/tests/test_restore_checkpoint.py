import hashlib,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from restore_checkpoint import restore
class RestoreTests(unittest.TestCase):
 def run_case(self,corrupt=False,alias=False):
  data=b'checkpoint';receipt={'artifact':'team/project/model:'+('latest' if alias else 'v0'),'content_roundtrip':'PASS','checkpoint':'final.pt','files':{'final.pt':{'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}}}
  class Artifact:
   def download(self,root):
    p=Path(root);(p/'final.pt').write_bytes(b'corruption' if corrupt else data);(p/'CHECKPOINT_MANIFEST.json').write_text(json.dumps({'version':1,'files':receipt['files']}));return root
  class API:
   def artifact(self,name,type):return Artifact()
  with tempfile.TemporaryDirectory() as t:
   out=Path(t)/'restore'
   if corrupt or alias:
    with self.assertRaises(ValueError):restore(receipt,out,API())
    self.assertFalse((out/'RESTORE_RECEIPT.json').exists())
   else:
    self.assertEqual(restore(receipt,out,API())['content_verification'],'PASS')
    with self.assertRaises(ValueError):restore(receipt,out,API())
 def test_verified_and_no_overwrite(self):self.run_case()
 def test_corruption(self):self.run_case(corrupt=True)
 def test_mutable_alias_rejected(self):self.run_case(alias=True)
