import copy,fcntl,gzip,hashlib,io,json,runpy,sys,tarfile,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import one_command as ctl
from workflow_contract import check_ranks,key,read,selection,sha,shards,write
from finalize_run import finalize

class ControlTests(unittest.TestCase):
 def cfg(self,root):
  return dict(private_validation=True,uses_public_validation_download=False,training_scope='ENGINEERING_HF13_GT',world=2,revision='2c3321bba55a1a728bbb60a8bce220738ea90613',ids=['a','b','c'],workspace=str(root/'work'),source=str(ROOT),python=sys.executable,ffmpeg_prefix='/ffmpeg',hf_hub_cache='/hf',xdg_cache='/xdg',datamover='example.invalid',source_manifest_sha256='fixed',train_config='/config',queue_guard_prefixes=['sam-one-','sam-gt-'])
 def test_private_scope(self):
  cfg=self.cfg(Path('/tmp'))
  for k,v in [('private_validation',False),('uses_public_validation_download',True),('training_scope','FULL'),('world',1),('revision','main')]:
   with self.assertRaises(ValueError):selection(dict(cfg,**{k:v}))
 def test_rank_coverage_identity_work_and_uuid(self):
  plan=dict(mixtures={'a':{},'b':{},'c':{}},texts={'t':{},'u':{}})
  reports=[dict(rank=r,world=2,status='ENCODED',identity='i',gpu_uuid=str(r),assigned={k:sorted(v) for k,v in shards(plan,r,2).items()},new_components=dict(mixture=1,video=1)) for r in range(2)]
  check_ranks(reports,plan,2,'i')
  for kind in ('missing','duplicate','uuid','stale','coverage','no_compute'):
   bad=copy.deepcopy(reports)
   if kind=='missing':bad.pop()
   elif kind=='duplicate':bad[1]['rank']=0
   elif kind=='uuid':bad[1]['gpu_uuid']='0'
   elif kind=='stale':bad[1]['identity']='other'
   elif kind=='coverage':bad[1]['assigned']['mixtures']=[]
   else:bad[1]['new_components']['mixture']=0
   with self.assertRaises(ValueError):check_ranks(bad,plan,2,'i')
 def test_checkpointed_never_archives_online(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);write(r/'RESULT.json',dict(status='CHECKPOINTED'))
   def forbidden(*a):self.fail('partial run must not hash or upload')
   for env in ({'WANDB_MODE':'online'},{'SLURM_JOB_GPUS':'0,1'}):self.assertEqual(finalize(r,env,forbidden,forbidden)['status'],'TRAINING_CHECKPOINTED')
 def test_stages_separate_cpu_transfer_and_gpu(self):
  cfg=self.cfg(Path('/tmp'))
  for stage in ctl.STAGES:
   script=ctl.script(cfg,Path('/config.json'),stage)
   self.assertIn('HF_HUB_CACHE=/hf',script);self.assertNotIn('dump_traceback_later',script)
   if ctl.resource(stage)['kind']=='gpu':
    self.assertIn('--gres=gpu:nvidia_a100-pcie-40gb:2',script);self.assertNotIn('sha256sum',script);self.assertIn('HF_HUB_OFFLINE=1',script);self.assertIn('gpu.csv',script)
   else:self.assertNotIn('--gres=',script)
  self.assertIn('--nproc_per_node=2',ctl.script(cfg,Path('/c'),'encode'))
 def test_accounting_allsteps(self):
  self.assertIsNone(ctl.accounting('42',lambda _: '42|COMPLETED|0:0|1|0|cpu=2'))
  self.assertIsNone(ctl.accounting('42',lambda _: '42|COMPLETED|0:0|1|0|cpu=2\n42.batch|RUNNING|0:0|1|0|cpu=2\n42.extern|COMPLETED|0:0|1|0|cpu=2'))
  self.assertFalse(ctl.accounting('42',lambda _: '42|FAILED|1:0|1|0|cpu=2\n42.batch|FAILED|1:0|1|0|cpu=2\n42.extern|COMPLETED|0:0|1|0|cpu=2')['success'])
 def test_held_resources_and_dependencies(self):
  cfg=self.cfg(Path('/tmp'));path=Path('/script')
  raw=f'JobState=PENDING Reason=JobHeldUser Requeue=0 Dependency=(null) NumNodes=1 NumTasks=1 NumCPUs=4 Command={path} WorkDir={ROOT} TimeLimit=00:05:00 MinMemoryNode=64G TresPerNode=gres/gpu:nvidia_a100-pcie-40gb:2'
  ctl.verify_held(raw,cfg,'encode',path)
  for bad in (raw.replace(':2',':4'),raw.replace('Dependency=(null)','Dependency=afterok:12'),raw.replace('Requeue=0','Requeue=1')):
   with self.assertRaises(ValueError):ctl.verify_held(bad,cfg,'encode',path)
 def test_unknown_intent_not_retried(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);cfg=self.cfg(r);c=r/'config.json';write(c,cfg)
   for status in ('TRANSFER_INTENT','SUBMISSION_INTENT'):
    write(Path(cfg['workspace'])/'JOURNAL.json',dict(config_identity=key(cfg),stages={'download':dict(status=status)}))
    with patch.object(ctl,'verify_source'),self.assertRaisesRegex(ValueError,'Unknown prior'):
     ctl.run(c,'download',runner=lambda a:self.fail('duplicate'),sleeper=lambda _:None)
 def test_second_controller_lock(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);cfg=self.cfg(r);c=r/'config.json';write(c,cfg);work=Path(cfg['workspace']);work.mkdir()
   with (work/'CONTROLLER.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with self.assertRaises(BlockingIOError):ctl.run(c,'download')
 def test_receipt_changed(self):
  with tempfile.TemporaryDirectory() as d:
   cfg=self.cfg(Path(d));p=Path(cfg['workspace'])/'stages/download/RESULT.json';write(p,dict(status='DOWNLOAD_READY',config_identity=key(cfg)))
   receipt=ctl.verify_stage(cfg,'download',{});write(p,dict(status='DOWNLOAD_READY',config_identity=key(cfg),extra='changed'))
   with self.assertRaisesRegex(ValueError,'evidence changed'):ctl.verify_stage(cfg,'download',dict(receipts=receipt))
 def test_completed_stage_rejected_before_action(self):
  import workflow_stages as stages
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);cfg=self.cfg(r);c=r/'config.json';write(c,cfg);write(Path(cfg['workspace'])/'stages/download/RESULT.json',dict(status='old'))
   with patch.object(sys,'argv',['stage','--config',str(c),'--stage','download']),patch.object(stages,'download',side_effect=AssertionError('rerun')):
    with self.assertRaisesRegex(ValueError,'Completed stage'):stages.main()

class DownloadTests(unittest.TestCase):
 def test_real_tar_interruption_resume_and_corruption(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);meta=root/'metadata';meta.mkdir();out=root/'media';objects={};archives=[];calls=[]
   for i,kind in enumerate(('video_mixture','target_residual')):
    payload=('content-'+kind).encode();name=f'clip/file{i}.bin';buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w') as tar:
     info=tarfile.TarInfo(name);info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
    blob=buf.getvalue();digest=hashlib.sha256(blob).hexdigest();url=f'arc{i}.tar';objects[url]=blob
    objects[url+'.manifest.json']=dict(archive_sha256=digest,files=[dict(relative=name,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())])
    archives.append(dict(kind=kind,batch=i,repo='fixture',repo_path=url,commit='a'*40,tar_sha256=digest,tar_bytes=len(blob),composite_ids=['clip']))
   metadata={'videos.jsonl.gz':[dict(composite_id='clip')],'archives.jsonl.gz':archives,'prompts.jsonl.gz':[dict(composite_id='clip',prompt='original prompt')]};hashes={}
   for name,rows in metadata.items():
    with gzip.open(meta/name,'wt') as f:
     for row in rows:f.write(json.dumps(row)+'\n')
    hashes[name]=sha(meta/name)
   write(meta/'STATUS.json',dict(metadata_sha256=hashes))
   class Response:
    def __init__(self,value):self.value=value;self.raw=io.BytesIO(value) if isinstance(value,bytes) else None
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def raise_for_status(self):pass
    def json(self):return self.value
   def get(url,**kw):calls.append(url);return Response(objects[url])
   hf=SimpleNamespace(HfApi=lambda:SimpleNamespace(repo_info=lambda *a,**kw:SimpleNamespace(sha='a'*40)),hf_hub_download=lambda repo,name,**kw:str(meta/name),hf_hub_url=lambda repo,name,**kw:name)
   def invoke(stop=False):
    argv=['download','--repo','fixture','--revision','a'*40,'--ids','clip','--output',str(out)]
    if stop:argv+=['--stop-after-receipts','1']
    with patch.dict(sys.modules,{'huggingface_hub':hf,'requests':SimpleNamespace(get=get)}),patch.object(sys,'argv',argv):runpy.run_path(str(ROOT/'tools/download_selected_avspeech.py'),run_name='__main__')
   with self.assertRaises(SystemExit) as stopped:invoke(True)
   self.assertEqual(stopped.exception.code,75);receipts=list((out/'receipts').glob('*.json'));self.assertEqual(len(receipts),1)
   before=sha(receipts[0]);calls.clear();invoke();self.assertNotIn('arc0.tar',calls);self.assertEqual(sha(receipts[0]),before)
   (out/'data/clip/file0.bin').write_bytes(b'broken');calls.clear();invoke();self.assertIn('arc0.tar',calls)
   self.assertEqual((out/'data/clip/file0.bin').read_bytes(),b'content-video_mixture')

if __name__=='__main__':unittest.main()
