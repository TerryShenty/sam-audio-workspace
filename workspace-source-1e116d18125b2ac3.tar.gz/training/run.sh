#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source tools/media_env.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 TORCHINDUCTOR_COMPILE_THREADS=2
if [[ "${WANDB_MODE:-online}" == online ]]; then : "${WANDB_ENTITY:?Set your own W&B entity}"; fi
export WANDB_PROJECT="${WANDB_PROJECT:-sam-audio}"
export WANDB_MODE="${WANDB_MODE:-online}"
: "${GPUS:=1}"
PY="${SAM_PYTHON:-$PWD/.venv/bin/python}"
if [[ ! -x "$PY" ]]; then echo "Run setup.sh first" >&2; exit 1; fi
exec "$PY" tools/run_and_archive.py --gpus "$GPUS" -- --config configs/train.json "$@"
