"""Explicit fixed-world topology; global ranks never select local CUDA devices."""
from dataclasses import asdict, dataclass
import os
import socket


@dataclass(frozen=True)
class Topology:
    rank: int
    world: int
    local_rank: int
    local_world: int
    node_rank: int
    nodes: int

    def peer(self, identity, machine_id=None):
        return dict(asdict(self), hostname=socket.gethostname(),
                    machine_id=machine_id, input_identity=identity)


def from_environment(environment=None, *, allow_multinode=False):
    env = os.environ if environment is None else environment
    try:
        rank, world = int(env["RANK"]), int(env["WORLD_SIZE"])
        local, local_world = int(env["LOCAL_RANK"]), int(env["LOCAL_WORLD_SIZE"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("A complete torchrun rank environment is required") from exc
    if world < 1 or local_world < 1 or world % local_world:
        raise ValueError("Only uniform fixed-world workers are supported")
    if not 0 <= rank < world or not 0 <= local < local_world:
        raise ValueError("Rank is outside the declared world")
    if local != rank % local_world:
        raise ValueError("Global/local rank mapping differs from fixed torchrun topology")
    nodes = world // local_world
    node_rank = rank // local_world
    if "GROUP_RANK" in env and int(env["GROUP_RANK"]) != node_rank:
        raise ValueError("Node rank disagrees with global rank")
    if int(env.get("TORCHELASTIC_RESTART_COUNT", "0")) != 0:
        raise ValueError("Automatic worker restart is not accepted")
    if nodes > 1 and not allow_multinode:
        raise ValueError("Multiple nodes require explicit --multi-node")
    return Topology(rank, world, local, local_world, node_rank, nodes)


def validate_peers(peers, topology, *, expected_machine_ids=None):
    if len(peers) != topology.world:
        raise ValueError("Missing worker identities")
    if sorted(p["rank"] for p in peers) != list(range(topology.world)):
        raise ValueError("Duplicate or missing global rank")
    ordered = sorted(peers, key=lambda p: p["rank"])
    identity = ordered[0]["input_identity"]
    for peer in ordered:
        if (peer["world"], peer["local_world"], peer["nodes"]) != (
                topology.world, topology.local_world, topology.nodes):
            raise ValueError("Workers disagree on topology")
        if (peer["node_rank"], peer["local_rank"]) != divmod(peer["rank"], topology.local_world):
            raise ValueError("Worker node/local rank mismatch")
        if peer["input_identity"] != identity:
            raise ValueError("Workers disagree on source, config, model or data identity")
    if expected_machine_ids is not None:
        if (len(expected_machine_ids) != topology.nodes
                or len(set(expected_machine_ids)) != topology.nodes
                or not all(isinstance(v, str) and v for v in expected_machine_ids)):
            raise ValueError("Distinct provider machine IDs required for physical-node proof")
        for peer in ordered:
            if peer["machine_id"] != expected_machine_ids[peer["node_rank"]]:
                raise ValueError("Observed provider placement differs from the controller")
    return ordered
