"""Persist terminal status and close tracking without concealing training errors."""
from contextlib import contextmanager
import json
from pathlib import Path
import warnings


@contextmanager
def tracked_session(tracker, output, rank):
    state = {'status': 'COMPLETE'}
    failed = False
    try:
        yield state
    except BaseException as exc:
        failed = True
        # Record the type, not exception text that may contain private paths/tokens.
        state.update(status='FAILED', error_type=type(exc).__name__)
        raise
    finally:
        try:
            if rank == 0:
                path = Path(output) / 'RESULT.json'
                temporary = path.with_suffix('.json.tmp')
                temporary.write_text(json.dumps(state, indent=2) + '\n')
                temporary.replace(path)
        except Exception as exc:
            warnings.warn('Could not persist terminal status: ' + type(exc).__name__)
        try:
            tracker.finish(exit_code=1 if failed else 0)
        except Exception as exc:
            warnings.warn('Could not finish W&B tracking: ' + type(exc).__name__)
