"""Identity checks for the fixed real validation cohort; no GPU imports."""
from collections import Counter
import hashlib
import json

EXPECTED = {'msdwild': 78, 'easycom': 207}
COHORT_SHA256 = 'ae0122c72bad536cb50b61af965a2c7e342d768cd9c63cc62061198c7765b905'
FIELDS = ('index', 'dataset', 'clip_id', 'target_source_id', 'prompt',
          'noise_seed', 'latent_frames')


def fingerprint(rows):
    normalized = [{k: r[k] for k in FIELDS}
                  for r in sorted(rows, key=lambda r: r['index'])]
    return hashlib.sha256(json.dumps(normalized, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':')).encode()).hexdigest()


def check(rows, *, engineering_subset=False):
    if not rows or len({r['index'] for r in rows}) != len(rows):
        raise ValueError('Empty or duplicate validation rows')
    counts = dict(Counter(r['dataset'] for r in rows))
    if set(counts) - set(EXPECTED):
        raise ValueError('Validation must use real MSDWild and EasyCom only')
    for r in rows:
        for key in ('clip_id', 'target_source_id', 'prompt'):
            if not isinstance(r.get(key), str) or not r[key].strip():
                raise ValueError('Missing validation identity: ' + key)
        if type(r.get('index')) is not int or r['index'] < 0:
            raise ValueError('Invalid validation index')
        if type(r.get('noise_seed')) is not int or not 0 <= r['noise_seed'] < 2**63:
            raise ValueError('Original validation noise seed required')
        if type(r.get('latent_frames')) is not int or r['latent_frames'] not in (250, 500, 750):
            raise ValueError('Original validation duration required')
    digest = fingerprint(rows)
    if engineering_subset:
        if any(n > EXPECTED[k] for k, n in counts.items()):
            raise ValueError('Engineering cohort exceeds the formal cohort')
    else:
        if counts != EXPECTED:
            raise ValueError('Full validation requires MSDWild78 + EasyCom207')
        if digest != COHORT_SHA256:
            raise ValueError('Validation identity/prompt/seed/duration changed')
    return {'counts': counts, 'cohort_sha256': digest,
            'scope': 'ENGINEERING_SUBSET' if engineering_subset else 'FORMAL_285'}
