"""Optional engineering observations on the actual CLI training path."""
import json
from pathlib import Path
import time
import torch


class RuntimeAudit:
    def __init__(self, impl, output, rank, config):
        self.output = Path(output)
        self.rank = rank
        self.config = config
        self.started = time.monotonic()
        self.records = dict(rank=rank, world_size=config["world_size"], forwards=[], updates=[],
                            supervision=config["training_supervision"])
        self.output.mkdir(parents=True, exist_ok=True)
        if (self.output / f"rank{rank}.json").exists():
            raise ValueError("Use a fresh runtime-audit stage")
        original_forward = impl.CachedFlowModel.forward
        original_step = torch.optim.AdamW.step
        original_load = torch.load
        restore_samples = {}

        def load(*args, **kwargs):
            state = original_load(*args, **kwargs)
            if isinstance(state, dict) and state.get("format") == "sam_audio_native_referring_v1":
                if (state["world_size"] != config["world_size"] or len(state["rng_by_rank"]) != config["world_size"]
                        or state["data_identity"]["training_supervision"] != config["training_supervision"]
                        or state["scheduler"]["last_epoch"] != state["global_step"]
                        or state["ema"]["updates"] != state["global_step"] or not state["optimizer"]["state"]):
                    raise ValueError("Actual loaded complete checkpoint identity/state differs")
                self.records["loaded_checkpoint"] = dict(step=state["global_step"], world=config["world_size"],
                    data_identity=state["data_identity"], verified_base=state["verified_base"],
                    rng_ranks=config["world_size"], optimizer=True, scheduler=True, ema=True)
                for name, value in list(state["trainable_model"].items())[:2]:
                    restore_samples[name] = value.clone()
            return state
        torch.load = load

        def forward(wrapper, features, **kwargs):
            f = features["forward_args"]
            labels = f["anchor_ids"].gather(1, f["anchor_alignment"])
            if config.get("resume_from") and not self.records.get("sampled_restore_equal"):
                params = dict(wrapper.sam_audio.named_parameters())
                if not restore_samples or not all(torch.equal(params[n].detach(), v.to(params[n]))
                                                   for n, v in restore_samples.items()):
                    raise ValueError("Loaded parameter samples differ before continuation")
                self.records["sampled_restore_equal"] = True
                restore_samples.clear()
            observed = []

            def hook(model, positional, named):
                actual = named["anchor_ids"].gather(1, named["anchor_alignment"])
                observed.append(torch.equal(actual, labels))
            handle = wrapper.sam_audio.register_forward_pre_hook(hook, with_kwargs=True)
            try:
                loss = original_forward(wrapper, features, **kwargs)
            finally:
                handle.remove()
            if observed != [True] or not torch.isfinite(loss).all():
                raise ValueError("Actual model GT input or loss invalid")
            positives = int((labels == 1).sum().item())
            if positives != 250 or not f["audio_pad_mask"].all():
                raise ValueError("Expected complete engineering GT support")
            self.records["forwards"].append(dict(frames=features["clean"].shape[1],
                                                  positives=positives, finite=True))
            return loss

        def step(optimizer, *args, **kwargs):
            selected = next((p for g in optimizer.param_groups for p in g["params"]
                             if p.grad is not None and torch.count_nonzero(p.grad).item()), None)
            if selected is None:
                raise ValueError("No nonzero optimizer gradient")
            before = selected.detach().clone()
            prior = int(optimizer.state.get(selected, {}).get("step", 0))
            value = original_step(optimizer, *args, **kwargs)
            after = int(optimizer.state[selected]["step"].item())
            delta = float((selected.detach()-before).abs().max().item())
            if after != prior + 1 or not delta > 0 or not torch.isfinite(selected).all():
                raise ValueError("No finite nonzero optimizer update")
            self.records["updates"].append(dict(before=prior, after=after, delta=delta))
            self.persist("RUNNING")
            return value

        impl.CachedFlowModel.forward = forward
        torch.optim.AdamW.step = step

    def persist(self, status):
        value = dict(self.records, status=status, seconds=time.monotonic()-self.started)
        path = self.output / f"{'rank' if status == 'PASS' else 'progress-rank'}{self.rank}.json"
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(value, indent=2) + "\n")
        temporary.replace(path)

    def finish(self, success):
        if not success:
            self.persist("FAILED")
            return
        if not self.records["updates"]:
            self.persist("NO_UPDATE")
            return
        local_device = torch.cuda.current_device()
        properties = torch.cuda.get_device_properties(local_device)
        self.records.update(gpu_uuid=str(properties.uuid),
                            local_device=local_device,
                            peak_bytes=torch.cuda.max_memory_allocated(local_device))
        self.persist("PASS")
