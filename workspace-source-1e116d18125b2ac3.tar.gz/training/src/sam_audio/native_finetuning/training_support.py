"""Bind audited source-placement support to target-specific cached training.

Frozen encoder tensors remain shared. Only newly allocated anchor tensors are
attached at assembly; a target must never mutate another target's mixture.
"""
import math
import hashlib
import json

RULE = "source-placement-480000-samples-v1"


def from_row(row):
    spec = dict(rule=row["training_gt_rule"], intervals=row["training_gt_spans"],
                samples=row["samples"], sample_rate=row["sample_rate"],
                prompt_id=row["prompt_id"], source_id=row["source_id"],
                window_id=row["window_id"], recipe_sha256=row["recipe_sha256"])
    validate(spec)
    return spec


def validate(spec):
    if spec["rule"] != RULE or spec["sample_rate"] != 48000:
        raise ValueError("Unsupported training support rule or sample rate")
    if type(spec["samples"]) is not int or spec["samples"] not in (480000, 960000, 1440000, 1920000, 2400000):
        raise ValueError("Training support requires full frozen source duration")
    if any(not isinstance(spec[k], str) or not spec[k]
           for k in ("prompt_id", "source_id", "window_id", "recipe_sha256")):
        raise ValueError("Missing target supervision provenance")
    spans = spec["intervals"]
    if not isinstance(spans, list) or len(spans) != 1 or len(spans[0]) != 2:
        raise ValueError("Expected one source-placement interval")
    start, end = spans[0]
    if (not all(type(x) in (int, float) and math.isfinite(x) for x in (start, end))
            or start < 0 or end > spec["samples"] / 48000
            or abs(end - start - 10) > 1e-6
            or abs(start / 10 - round(start / 10)) > 1e-6):
        raise ValueError("Invalid ten-second source-placement support")


def check_split(split):
    entries = split["entries"]
    rule = split.get("training_support_rule")
    if rule not in (None, RULE):
        raise ValueError("Unsupported cached training supervision")
    for entry in entries:
        supports = []
        for refs in entry["variants"]:
            spec = refs.get("training_support")
            if (spec is not None) != (rule is not None):
                raise ValueError("Mixed or missing cached training supervision")
            if spec is not None:
                validate(spec)
                if spec["samples"] // 1920 != entry["latent_frames"]:
                    raise ValueError("Support duration differs from cached features")
                supports.append({k: v for k, v in spec.items() if k != "prompt_id"})
        if supports and any(x != supports[0] for x in supports):
            raise ValueError("Prompt variants change target supervision")


def check_entry(catalog, validation, config):
    """Validate supervision metadata before CUDA and bind checkpoint identity.

    This is not a tensor, file-integrity or full-bundle audit. Those separate
    preparation checks must succeed before declaring a bundle ready.
    """
    expected = config.get("training_support_rule")
    if expected not in (RULE, "none"):
        raise ValueError("Explicit training_support_rule required")
    engineering = config.get("engineering_validation_subset", False)
    if type(engineering) is not bool:
        raise ValueError("engineering_validation_subset must be a boolean")
    if expected == "none" and not engineering:
        raise ValueError("Formal AVSpeech training requires source-placement GT")
    splits = catalog["splits"]
    train = splits["train"]
    if not train["entries"]:
        raise ValueError("Empty training targets")
    if train.get("training_support_rule") != (None if expected == "none" else expected):
        raise ValueError("Configured training support does not match cached data")
    targets = []
    seen = set()
    for name, split in splits.items():
        check_split(split)
        if name != "train" and split.get("training_support_rule") is not None:
            raise ValueError("Validation cache must not contain target GT support")
    for entry in train["entries"]:
        key = entry.get("sample_id")
        if not isinstance(key, str) or not key or key in seen or not entry["variants"]:
            raise ValueError("Missing, duplicate or empty training target")
        seen.add(key)
        targets.append({
            "sample_id": key,
            "latent_frames": entry["latent_frames"],
            "supports": [refs.get("training_support") for refs in entry["variants"]],
        })
    # Ground-truth audio is required for scoring; only target-conditioning
    # fields are forbidden in the heldout forward inputs.
    forbidden = {"training_support", "training_support_rule",
                 "training_gt_rule", "training_gt_spans"}
    for item in validation["items"]:
        if forbidden.intersection(item) or forbidden.intersection(item.get("refs", {})):
            raise ValueError("Heldout forward inputs must not contain training GT support")
    payload = {"rule": expected, "targets": targets}
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                      separators=(",", ":")).encode()).hexdigest()
    return {"rule": expected, "targets": len(targets),
            "prompt_variants": sum(len(x["supports"]) for x in targets),
            "metadata_sha256": digest,
            "scope": "ENGINEERING_SUBSET" if engineering else "FORMAL_285",
            "audit": "SUPERVISION_METADATA_ONLY"}


def apply(args, spec):
    if spec is None:
        return args
    validate(spec)
    import torch
    from sam_audio.processor import Batch
    frames = spec["samples"] // 1920
    if (args["audio_features"].shape[:2] != (1, frames)
            or args["audio_pad_mask"].shape != (1, frames)
            or args["audio_features"].device.type != "cpu"
            or not args["audio_pad_mask"].all()):
        raise ValueError("Support requires complete CPU cached features")
    if (args["anchor_ids"].tolist() != [[0, 3]]
            or args["anchor_alignment"].shape != (1, frames)
            or args["anchor_alignment"].count_nonzero()):
        raise ValueError("Refuse to overwrite preexisting cached anchors")
    batch = Batch.__new__(Batch)
    batch.audios = torch.empty(1, 1, 0)
    batch.audio_pad_mask = args["audio_pad_mask"]
    batch.hop_length, batch.audio_sampling_rate = 1920, 48000
    Batch.process_anchors(batch, [[["+", float(a), float(z)] for a, z in spec["intervals"]]])
    labels = batch.anchor_ids.gather(1, batch.anchor_alignment)
    if (labels == 1).sum().item() != 250:
        raise ValueError("Official anchor quantization did not preserve ten-second support")
    result = dict(args)
    result.update(anchor_ids=batch.anchor_ids, anchor_alignment=batch.anchor_alignment)
    return result
