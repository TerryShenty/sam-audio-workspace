"""Checkpoint boundaries computed from completed optimizer updates, not samples."""
def half_epoch_due(next_update, updates_per_epoch, enabled):
    if type(updates_per_epoch) is not int or updates_per_epoch<1:
        raise ValueError('Positive epoch update count required')
    # One-update epochs have no distinct midpoint. Odd epochs use ceil(N/2).
    return bool(enabled) and updates_per_epoch>1 and next_update==(updates_per_epoch+1)//2
