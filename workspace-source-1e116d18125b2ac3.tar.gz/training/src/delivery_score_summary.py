"""Dataset-separated validation summaries with explicit checkpoint coordinates."""
import math

def summarize(rows, context=None):
    if not rows:raise ValueError('Empty validation scores')
    if len({r['index'] for r in rows})!=len(rows):raise ValueError('Duplicate score identity')
    summary={};logged={}
    for ds in sorted({r['dataset'] for r in rows}):
        subset=[r for r in rows if r['dataset']==ds];s={'n':len(subset)}
        for metric in ('aligned_si_sdr_db','si_sdr_db','si_sdri_db'):
            values=[r[metric] for r in subset]
            if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in values):raise ValueError('Invalid validation score')
            s[metric]=math.fsum(values)/len(values)
        summary[ds]=s
        for k,v in s.items():logged[f'validation/{ds}/{k}']=v
    if context:
        step=context.get('global_step');name=context.get('checkpoint')
        if type(step) is not int or step<0 or not isinstance(name,str) or not name:raise ValueError('Invalid validation coordinates')
        logged.update({'validation/global_step':step,'validation/checkpoint':name})
    return summary,logged
