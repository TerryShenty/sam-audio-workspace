"""Narrow, audited workaround for the official 0.6.0 Linux wheel's wrong tag.

Changes metadata only, after a real CPU decode; unknown binaries/tags fail closed.
"""
import base64
import csv
import hashlib
import importlib.metadata
import io
import json
import platform
import sys
from pathlib import Path

LIB_SHA = '98b260c5812106648ba299279916fbe98439893e346d4efdcf5cde66ba8973da'
ORIGINAL = 'Wheel-Version: 1.0\nGenerator: bdist_wheel (0.36.2)\nRoot-Is-Purelib: false\nTag: cp36-cp36m-manylinux2010_x86_64\n\n'
CORRECTED = ORIGINAL.replace('cp36-cp36m', 'py3-none')


def repair(info, receipt, probe):
    info, receipt = Path(info), Path(receipt)
    wheel, record = info/'WHEEL', info/'RECORD'
    original, original_record = wheel.read_bytes(), record.read_bytes()
    lib = info.parent/'decord/libdecord.so'
    digest = hashlib.sha256(lib.read_bytes()).hexdigest()
    if digest != LIB_SHA:
        raise ValueError('Unknown decord native library; metadata not changed')
    if original.decode() not in (ORIGINAL, CORRECTED):
        raise ValueError('Unknown decord WHEEL metadata; not changed')
    before = probe()
    if before.get('status') != 'PASS':
        raise ValueError('Native decoder probe did not pass')
    if original.decode() == CORRECTED:
        return {'status':'ALREADY_CORRECTED', 'decode':before}
    rows = list(csv.reader(io.StringIO(original_record.decode())))
    matching = [row for row in rows if row[0] == info.name+'/WHEEL']
    if len(matching) != 1:
        raise ValueError('Ambiguous wheel RECORD; not changed')
    backup = receipt.with_suffix('.original')
    backup.mkdir(parents=True, exist_ok=False)
    (backup/'WHEEL').write_bytes(original)
    (backup/'RECORD').write_bytes(original_record)
    corrected = CORRECTED.encode()
    matching[0][1:] = ['sha256='+base64.urlsafe_b64encode(hashlib.sha256(corrected).digest()).rstrip(b'=').decode(), str(len(corrected))]
    try:
        wheel.write_bytes(corrected)
        with record.open('w', newline='') as handle:
            csv.writer(handle).writerows(rows)
        after = probe()
        if after.get('status') != 'PASS' or hashlib.sha256(lib.read_bytes()).hexdigest() != digest:
            raise ValueError('Post-repair decoder/hash check failed')
        result = {'status':'CORRECTED_METADATA_ONLY', 'native_library_sha256':digest,
                  'original_tag':'cp36-cp36m-manylinux2010_x86_64',
                  'corrected_tag':'py3-none-manylinux2010_x86_64',
                  'before':before, 'after':after, 'binary_modified':False}
        pending = receipt.with_suffix('.tmp')
        pending.write_text(json.dumps(result, indent=2)); pending.replace(receipt)
        return result
    except BaseException:
        wheel.write_bytes(original); record.write_bytes(original_record)
        raise


if __name__ == '__main__':
    if platform.system() != 'Linux' or platform.machine() != 'x86_64' or sys.version_info[:2] != (3,12):
        raise SystemExit('This workaround is verified only on Linux x86_64 Python 3.12')
    from decoder_probe import probe
    dist = importlib.metadata.distribution('decord')
    if dist.version != '0.6.0':
        raise SystemExit('Unexpected decord version; no metadata changed')
    info = Path(dist.locate_file('decord-0.6.0.dist-info'))
    print(json.dumps(repair(info, Path('DECORD_METADATA_REPAIR.json'), probe), indent=2))
