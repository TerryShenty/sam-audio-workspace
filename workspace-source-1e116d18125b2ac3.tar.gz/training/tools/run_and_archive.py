"""Run training once, then archive best/last after its process group has exited."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile

from archive_best_last import atomic_json
from finalize_run import finalize
from launch_distributed import clean_group


def receipt_identity(path):
    try:
        stat = path.stat()
        return stat.st_dev, stat.st_ino, stat.st_mtime_ns, stat.st_size
    except FileNotFoundError:
        return None


def launch(command, environment):
    child = subprocess.Popen(command, env=environment, start_new_session=True)
    def interrupted(signum, frame):
        raise InterruptedError("Training wrapper interrupted")
    previous = signal.signal(signal.SIGTERM, interrupted)
    try:
        return child.wait()
    finally:
        try:
            clean_group(child)
        finally:
            signal.signal(signal.SIGTERM, previous)


def run(command, root, environment=None, runner=launch, finalizer=finalize):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    with (root / "WORKFLOW.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run_locked(command, root, environment, runner, finalizer)


def run_locked(command, root, environment, runner, finalizer):
    history = root / "workflow-reports"
    history.mkdir(exist_ok=True)
    evidence = Path(tempfile.mkdtemp(prefix="invocation-", dir=history))
    environment = dict(os.environ if environment is None else environment)
    previous = receipt_identity(root / "RESULT.json")
    result = dict(status="TRAINING_RUNNING", server_cleanup=False,
                  evidence=str(evidence), full_delivery_acceptance="NOT_ESTABLISHED")
    def persist():
        atomic_json(evidence / "RESULT.json", result)
        atomic_json(root / "WORKFLOW_RESULT.json", result)
    persist()
    try:
        code = runner(command, environment)
        result.update(training_exit_code=code)
        if code != 0:
            result["status"] = "TRAINING_FAILED"
            return code if 0 < code < 256 else 1
        if receipt_identity(root / "RESULT.json") in (None, previous):
            raise ValueError("No fresh training terminal receipt; refusing stale-result archival")
        result["status"] = "FINALIZING"
        persist()
        finalization = finalizer(root, environment)
        result.update(status=finalization["status"], finalization=finalization)
        return 0
    except BaseException as error:
        result.update(status="INTERRUPTED" if isinstance(error, (KeyboardInterrupt, InterruptedError))
                      else "WORKFLOW_FAILED", error_type=type(error).__name__)
        raise
    finally:
        persist()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gpus", type=int, required=True)
    parser.add_argument("training_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    training = args.training_args
    if training and training[0] == "--":
        training = training[1:]
    # The trainer accepts these same options; parse_known_args keeps all other
    # training arguments intact, including repeated options (last value wins).
    identity = argparse.ArgumentParser(add_help=False)
    identity.add_argument("--output", required=True)
    options, _ = identity.parse_known_args(training)
    if args.gpus < 1:
        parser.error("--gpus must be positive")
    command = [sys.executable, str(Path(__file__).with_name("launch_distributed.py")),
               "--gpus", str(args.gpus), "--", "src/train_delivery.py", *training]
    code = run(command, Path(options.output))
    print("Training and archival status: " + str(Path(options.output).resolve() / "WORKFLOW_RESULT.json"),
          flush=True)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
