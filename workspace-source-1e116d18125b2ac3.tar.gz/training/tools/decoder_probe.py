"""Bounded CPU decoder test, independent of a dataset or GPU allocation."""
import subprocess
import tempfile
import math
import struct
import wave
from pathlib import Path


def probe():
    import decord
    import numpy as np
    import torch
    import torchaudio
    from torchcodec.decoders import AudioDecoder, VideoDecoder

    with tempfile.TemporaryDirectory(prefix='sam-decoder-') as directory:
        path = Path(directory) / 'fixture.mp4'
        audio_path = Path(directory) / 'fixture.wav'
        with wave.open(str(audio_path), 'wb') as handle:
            handle.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
            handle.writeframes(b''.join(
                struct.pack('<h', round(12000 * math.sin(2 * math.pi * 440 * i / 16000)))
                for i in range(16000)
            ))
        subprocess.run([
            'ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'testsrc=size=64x64:rate=5',
            '-t', '1', '-threads', '1', '-pix_fmt', 'yuv420p', str(path),
        ], check=True, capture_output=True, timeout=30)
        reader = decord.VideoReader(str(path), ctx=decord.cpu(0), num_threads=1)
        if len(reader) != 5:
            raise ValueError(f'Expected 5 decoded frames, got {len(reader)}')
        frames = reader.get_batch([0, 4]).asnumpy()
        if frames.shape != (2, 64, 64, 3) or frames.dtype != np.uint8:
            raise ValueError(f'Invalid decoded frame shape/dtype: {frames.shape}/{frames.dtype}')
        if np.array_equal(frames[0], frames[1]) or int(frames.max()) == int(frames.min()):
            raise ValueError('Decoded fixture lost its temporal or spatial variation')
        # Importing TorchCodec does not load its native FFmpeg libraries.
        # Exercise both decoding paths used by raw-media cache construction.
        audio, rate = torchaudio.load(str(audio_path))
        direct = AudioDecoder(str(audio_path)).get_all_samples()
        if rate != 16000 or direct.sample_rate != 16000:
            raise ValueError('Audio decoder changed fixture sample rate')
        for decoded in (audio, direct.data):
            if tuple(decoded.shape) != (1, 16000) or not torch.isfinite(decoded).all():
                raise ValueError('Invalid decoded audio shape or values')
            if float(decoded.abs().max()) < 0.1:
                raise ValueError('Decoded audio fixture lost its signal')
        video = VideoDecoder(str(path), dimension_order='NCHW', num_ffmpeg_threads=1)
        sampled = video.get_frames_at(indices=[0, 4]).data
        if len(video) != 5 or tuple(sampled.shape) != (2, 3, 64, 64):
            raise ValueError('Invalid TorchCodec video shape')
        if torch.equal(sampled[0], sampled[1]):
            raise ValueError('TorchCodec video lost temporal variation')
        return {'status': 'PASS', 'device': 'cpu', 'frames': len(reader),
                'batch_shape': list(frames.shape),
                'audio_samples': audio.numel(),
                'decoders': ['decord.VideoReader', 'torchaudio.load',
                             'torchcodec.AudioDecoder', 'torchcodec.VideoDecoder'],
                'scope': 'synthetic H264 video and PCM WAV fixtures only'}
