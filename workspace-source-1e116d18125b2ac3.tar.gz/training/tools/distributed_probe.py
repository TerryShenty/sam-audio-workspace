"""Small real NCCL/DDP probe. Run only inside the intended GPU allocation."""
import json
import os
import time
import sys
from datetime import timedelta
from pathlib import Path


def main():
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    from delivery_topology import from_environment, validate_peers
    topology = from_environment(allow_multinode=os.environ.get("SAM_MULTINODE_PROBE") == "1")
    rank, world, local = topology.rank, topology.world, topology.local_rank
    output = Path(os.environ["SAM_PROBE_OUTPUT"])
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.cuda.set_device(local)
    device = torch.device("cuda", local)
    output.mkdir(parents=True, exist_ok=True)

    def event(stage, **fields):
        row = dict(rank=rank, stage=stage, seconds=time.monotonic() - started, **fields)
        print(json.dumps(row), flush=True)
        with (output / f"rank-{rank}.jsonl").open("a") as handle:
            handle.write(json.dumps(row) + "\n")

    event("device", name=torch.cuda.get_device_name(local), local_rank=local,
          uuid=str(torch.cuda.get_device_properties(local).uuid))
    try:
        dist.init_process_group("nccl", timeout=timedelta(seconds=30), device_id=device)
        peers = [None] * world
        dist.all_gather_object(peers, topology.peer(
            {"cpu_input_identity": os.environ.get("SAM_CPU_INPUT_IDENTITY")},
            os.environ.get("SAM_PROVIDER_MACHINE_ID")))
        validate_peers(peers, topology, expected_machine_ids=(
            json.loads(os.environ["SAM_EXPECTED_MACHINE_IDS"]) if topology.nodes > 1 else None))
        event("initialized")
        value = torch.tensor([rank + 1.0], device=device)
        dist.all_reduce(value)
        torch.cuda.synchronize()
        assert value.item() == world * (world + 1) / 2
        event("all_reduce_pass")
        torch.manual_seed(17)
        model = torch.nn.Sequential(torch.nn.Linear(64, 64), torch.nn.GELU(),
                                    torch.nn.Linear(64, 1)).to(device)
        ddp = DistributedDataParallel(model, device_ids=[local], broadcast_buffers=False)
        optimizer = torch.optim.SGD(ddp.parameters(), lr=0.01)
        before = next(model.parameters()).detach().clone()
        for step in range(2):
            loss = ddp(torch.ones(8, 64, device=device) * (rank + 1)).square().mean()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            assert torch.isfinite(loss)
            event("optimizer_step", step=step + 1)
        torch.cuda.synchronize()
        weight = next(model.parameters()).detach().clone()
        assert not torch.equal(before, weight)
        reference = weight.clone()
        dist.broadcast(reference, src=0)
        assert torch.equal(reference, weight)
        receipt = dict(status="PASS", rank=rank, world=world, steps=2,
                       local_rank=local, peers=peers,
                       gpu_uuid=str(torch.cuda.get_device_properties(local).uuid),
                       peak_bytes=torch.cuda.max_memory_allocated(local),
                       seconds=time.monotonic() - started,
                       scope="tiny NCCL/DDP computation only; not model/data acceptance")
        (output / f"PASS-rank-{rank}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
