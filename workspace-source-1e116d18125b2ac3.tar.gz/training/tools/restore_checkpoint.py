"""Restore an immutable W&B artifact using a trusted upload receipt; never unpickle."""
import argparse,json,re
from pathlib import Path
from checkpoint_archive import verify

def restore(receipt, destination, api):
    name=receipt.get('artifact','')
    if not re.fullmatch(r'[^/]+/[^/]+/[^/:]+:v[0-9]+',name):
        raise ValueError('Explicit immutable artifact version required')
    if receipt.get('content_roundtrip')!='PASS' or not receipt.get('files'):
        raise ValueError('Verified upload receipt required')
    root=Path(destination).resolve()
    if root.exists():raise ValueError('Choose a new destination; existing data is never overwritten')
    root.mkdir(parents=True)
    artifact=api.artifact(name,type='model')
    downloaded=Path(artifact.download(root=str(root))).resolve()
    if downloaded!=root:raise ValueError('Unexpected SDK destination')
    expected={'version':1,'files':receipt['files']}
    if json.loads((root/'CHECKPOINT_MANIFEST.json').read_text())!=expected:
        raise ValueError('Artifact manifest disagrees with trusted receipt')
    count=verify(root,expected)
    checkpoint=receipt['checkpoint']
    if checkpoint not in expected['files']:raise ValueError('Checkpoint absent from manifest')
    result={'artifact':name,'checkpoint':str(root/checkpoint),'verified_files':count,
            'content_verification':'PASS','model_resume':'NOT_TESTED'}
    (root/'RESTORE_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--receipt',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    import wandb
    print(json.dumps(restore(json.loads(Path(a.receipt).read_text()),a.output,wandb.Api())))
