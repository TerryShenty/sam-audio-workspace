"""Check local GPU communication before launching training once.

Never allocates GPUs or downloads data. Run inside an existing allocation.
Only the tiny diagnostic may retry; training itself is never restarted here.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time


def group_exists(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False


def clean_group(process):
    """Do not launch another GPU process until this process group is gone."""
    def send(signum):
        try:
            os.killpg(process.pid, signum)
        except ProcessLookupError:
            pass
    send(signal.SIGTERM)
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        pass
    send(signal.SIGKILL)
    process.wait(timeout=3)
    deadline = time.monotonic() + 3
    while group_exists(process.pid) and time.monotonic() < deadline:
        time.sleep(0.05)
    if group_exists(process.pid):
        raise RuntimeError("Diagnostic process group still exists; refusing a second launch")


def bounded_run(command, environment, logfile, timeout):
    started = time.monotonic()
    with Path(logfile).open("w") as log:
        process = subprocess.Popen(command, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            try:
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                code, timed_out = 124, True
        finally:
            clean_group(process)
    return dict(exit_code=code, timed_out=timed_out, seconds=time.monotonic() - started)


def torchrun(gpus):
    return [sys.executable, "-m", "torch.distributed.run", "--standalone",
            "--max-restarts=0", f"--nproc_per_node={gpus}"]


def attempt(gpus, environment, directory, timeout):
    directory.mkdir()
    child_env = dict(environment, SAM_PROBE_OUTPUT=str(directory))
    command = torchrun(gpus) + [str(Path(__file__).with_name("distributed_probe.py"))]
    result = bounded_run(command, child_env, directory / "process.log", timeout)
    receipts = []
    for rank in range(gpus):
        path = directory / f"PASS-rank-{rank}.json"
        try:
            receipt = json.loads(path.read_text())
            if (receipt["status"], receipt["rank"], receipt["world"], receipt["steps"]) != (
                    "PASS", rank, gpus, 2):
                raise ValueError("invalid rank receipt")
            receipts.append(receipt)
        except (OSError, ValueError, KeyError, TypeError):
            break
    result.update(passed=result["exit_code"] == 0 and len(receipts) == gpus,
                  ranks=receipts, p2p_disabled=environment.get("NCCL_P2P_DISABLE"))
    return result


def select_transport(gpus, environment, directory, timeout=60, probe=attempt):
    """Explicit operator settings are preserved, including an explicit zero."""
    if gpus < 1:
        raise ValueError("GPUS must be a positive integer")
    selected = dict(environment)
    report = dict(status="CHECKING", gpus=gpus, attempts=[],
                  scope="communication only; not throughput or full training acceptance")
    if gpus == 1:
        report["status"] = "SINGLE_GPU_NO_COLLECTIVE_PROBE"
        return selected, report
    supplied = "NCCL_P2P_DISABLE" in environment
    for name in (["operator"] if supplied else ["default", "p2p_disabled"]):
        if name == "p2p_disabled":
            selected["NCCL_P2P_DISABLE"] = "1"
        result = probe(gpus, selected, directory / name, timeout)
        report["attempts"].append(dict(name=name, **result))
        if result["passed"]:
            report.update(status="PASS", selected=name,
                          selected_p2p_disable=selected.get("NCCL_P2P_DISABLE"))
            return selected, report
    report["status"] = "FAIL"
    return None, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gpus", type=int, required=True)
    parser.add_argument("--report-root", type=Path, default=Path("transport-reports"))
    parser.add_argument("--probe-only", action="store_true")
    parser.add_argument("training_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.gpus < 1:
        parser.error("--gpus must be positive")
    training = args.training_args
    if training and training[0] == "--":
        training = training[1:]
    if not args.probe_only and not training:
        parser.error("Training entry required after --")
    args.report_root.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix="launch-", dir=args.report_root)).resolve()
    def terminated(signum, frame):
        raise InterruptedError(f"Launcher received signal {signum}; stopping its diagnostic")
    previous = signal.signal(signal.SIGTERM, terminated)
    try:
        environment, report = select_transport(args.gpus, os.environ, directory)
    except (Exception, KeyboardInterrupt) as error:
        report = dict(status="FAIL", error_type=type(error).__name__, error=str(error))
        (directory / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
        raise
    finally:
        signal.signal(signal.SIGTERM, previous)
    (directory / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Communication check: {report['status']}. Evidence: {directory}", flush=True)
    if environment is None:
        raise SystemExit("GPU communication checks failed; training was not launched")
    if report.get("selected") == "p2p_disabled":
        print("Default communication failed; this launch uses the tested P2P-disabled "
              "fallback. This is a compatibility result, not a speed recommendation.", flush=True)
    if not args.probe_only:
        command = torchrun(args.gpus) + training
        os.execvpe(command[0], command, environment)


if __name__ == "__main__":
    main()
