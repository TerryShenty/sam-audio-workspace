"""Prepare the fixed real validation media independently of AVSpeech uploads.

CPU or data-transfer host only. No GPU allocation, model loading or training.
"""
import argparse
import json
import hashlib
from pathlib import Path
import re
import sys
import tarfile
import urllib.request

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from delivery_cohort import check
from data_manifest import path_in, sha
from download_data import download


def prepare(config, root):
    revision = config.get('revision')
    if not isinstance(revision, str) or not re.fullmatch('[0-9a-f]{40}', revision):
        raise ValueError('Validation release is not published and pinned yet; '
                         'do not substitute training/test data or skip validation.')
    if not re.fullmatch(r'[\w.-]+/[\w.-]+', config['repository']):
        raise ValueError('Invalid HF repository')
    base = 'https://huggingface.co/datasets/' + config['repository'] + '/resolve/' + revision
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    receipt = root / 'DOWNLOAD_RECEIPT.json'
    if receipt.exists():
        old = json.loads(receipt.read_text())
        if (old.get('repo'), old.get('revision')) != (config['repository'], revision):
            raise ValueError('Different validation release in output; use a fresh directory')
    with urllib.request.urlopen(base + '/validation.json', timeout=60) as response:
        raw = response.read()
    if hashlib.sha256(raw).hexdigest() != config['manifest_sha256']:
        raise ValueError('Validation manifest checksum mismatch')
    manifest = json.loads(raw)
    cohort = check(manifest['rows'])
    if manifest['counts'] != config['counts'] or cohort['cohort_sha256'] != config['cohort_sha256']:
        raise ValueError('Validation cohort differs from the pinned release')
    specs = {x['path']: x for x in manifest['files']}
    if len(specs) != len(manifest['files']):
        raise ValueError('Duplicate validation media path')
    for name in specs:
        path_in(root, name)
    for row in manifest['rows']:
        for key in ('video', 'mixture_audio', 'gt_audio'):
            if row[key] not in specs:
                raise ValueError('Validation row references missing media')
    download(root, {'files': [config['archive']]}, base)
    seen = set()
    with tarfile.open(path_in(root, config['archive']['path'])) as archive:
        for member in archive:
            if not member.isfile() or member.name not in specs or member.name in seen:
                raise ValueError('Unsafe, unknown or duplicate archive member')
            spec = specs[member.name]
            if member.size != spec['size']:
                raise ValueError('Archive member size mismatch')
            seen.add(member.name)
            target = path_in(root, member.name)
            if target.is_file() and target.stat().st_size == spec['size'] and sha(target) == spec['sha256']:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            partial = path_in(root, member.name + '.partial')
            with archive.extractfile(member) as src, partial.open('wb') as output:
                for block in iter(lambda: src.read(1 << 20), b''):
                    output.write(block)
            if sha(partial) != spec['sha256']:
                raise ValueError('Validation media checksum mismatch')
            partial.replace(target)
    if seen != set(specs):
        raise ValueError('Incomplete validation archive')
    (root / 'validation.json').write_bytes(raw)
    result = dict(status='VERIFIED_MEDIA', repo=config['repository'], revision=revision,
                  files=len(seen), **cohort, gpu_evaluation='NOT_RUN',
                  feature_cache='REQUIRED_BEFORE_TRAINING')
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(Path(__file__).resolve().parents[1] / 'configs/validation_release.json'))
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(json.loads(Path(args.config).read_text()), args.output), indent=2))


if __name__ == '__main__':
    main()
