"""CPU export of audited public validation features with verified training components."""
import copy
import json
from pathlib import Path, PurePosixPath


def digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def training_files(manifest, bundle):
    catalog, components = bundle["train_catalog"], bundle["train_components"]
    selected = []
    names = set()
    for row in manifest["files"]:
        name = row["path"]
        if (name in names or PurePosixPath(name).is_absolute()
                or ".." in PurePosixPath(name).parts):
            raise ValueError("Duplicate or unsafe source manifest path")
        names.add(name)
        if name == catalog or name.startswith(components + "/"):
            if not digest(row["sha256"]) or type(row["size"]) is not int or row["size"] <= 0:
                raise ValueError("Unverified training source")
            selected.append(row)
    if catalog not in {r["path"] for r in selected} or len(selected) < 2:
        raise ValueError("Missing training catalog/components")
    if any(r["path"].startswith("validation/") for r in selected):
        raise ValueError("Old validation cache must not enter the new export")
    return selected


def validation_fragment(audit, plan, ready, feature_root):
    if (audit["status"] != "PASS_ALL285_PUBLIC_ENCODING_AND_CPU_TENSORS"
            or audit.get("full285_features_ready") is not True
            or audit["plan_identity"] != ready["plan_identity"]
            or audit["input_sha256"] != ready["input_sha256"]
            or audit["public_revision"] != plan["public_revision"]):
        raise ValueError("Complete matching public feature audit required")
    expected = {r["index"]: r for r in plan["rows"]}
    records = audit["rows"]
    if len(expected) != 285 or sorted(r["row"]["index"] for r in records) != sorted(expected):
        raise ValueError("Incomplete or duplicate public feature coverage")
    files, items, media = [], [], {}
    for record in records:
        row = record["row"]
        index = row["index"]
        if (row != expected[index] or record["finite"] is not True
                or record["anchor_ids"] != [[0, 3]]
                or not digest(record["sha256"]) or record["bytes"] <= 0):
            raise ValueError("Feature identity, hash or null conditioning mismatch")
        source = Path(record["path"])
        if source != Path(feature_root) / f"rank-{index % plan.get('world', 2)}" / f"row-{index}.pt":
            raise ValueError("Feature must belong to the completed full-cohort run")
        name = f"validation/features/{index}.pt"
        files.append(dict(source=str(source), destination=name,
                          sha256=record["sha256"], size=record["bytes"]))
        item = copy.deepcopy(row)
        item.update(features_file=name, features_sha256=record["sha256"],
                    original_public_row=copy.deepcopy(row))
        item["video"] = (
            "hf://datasets/sam-audio-research/sam-audio-validation-285@"
            + plan["public_revision"] + "/" + row["video"])
        for field in ("gt_audio", "mixture_audio"):
            source = str(Path(plan["media_root"]) / row[field])
            receipt = ready["media_files"].get(source)
            if not receipt or not digest(receipt["sha256"]):
                raise ValueError("Missing original public media receipt")
            name = "validation/" + row[field]
            if source not in media:
                media[source] = name
                files.append(dict(source=source, destination=name,
                                  sha256=receipt["sha256"], size=receipt["bytes"]))
            item[field] = name
        items.append(item)
    names = [r["destination"] for r in files]
    if len(set(names)) != len(names):
        raise ValueError("Destination collision")
    return dict(stores={}, items=items, provenance=dict(
        public_revision=plan["public_revision"], plan_identity=audit["plan_identity"],
        input_sha256=audit["input_sha256"], fresh_features=True,
        conditioning="nullGT", original_public_rows_preserved=True)), files

