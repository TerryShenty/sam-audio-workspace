"""Install a pinned shared FFmpeg runtime under a user-owned directory.

No sudo, shell profile changes, GPU calls, or modification of existing runtimes.
For clusters: --download-only on a transfer node, then --install-offline on CPU.
The default performs both phases on an ordinary Linux workstation.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time
import urllib.parse
import urllib.request


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_lock(path):
    lock = json.loads(Path(path).read_text())
    if lock.get("schema_version") != 1 or lock.get("platform") != "linux-64":
        raise ValueError("Unsupported native runtime manifest")
    records = [lock["micromamba"], *lock["packages"]]
    names = set()
    for record in records:
        url = urllib.parse.urlsplit(record["url"])
        filename = Path(url.path).name
        if (url.scheme != "https" or url.username or url.password or url.query or
                url.fragment or not filename or filename in names):
            raise ValueError("Invalid or colliding package URL")
        if not re.fullmatch(r"[0-9a-f]{64}", record["sha256"]):
            raise ValueError("Missing strong package digest")
        if not isinstance(record["size"], int) or record["size"] <= 0:
            raise ValueError("Invalid package size")
        names.add(filename)
    package_names = [record["name"] for record in lock["packages"]]
    if len(set(package_names)) != len(package_names):
        raise ValueError("Duplicate package names")
    for record in lock["packages"]:
        if not re.fullmatch(r"[0-9a-f]{32}", record.get("md5", "")):
            raise ValueError("Invalid explicit-install checksum")
        if not record.get("version") or not record.get("build"):
            raise ValueError("Missing pinned package identity")
    return lock


def cache_path(cache, record):
    return cache / Path(urllib.parse.urlsplit(record["url"]).path).name


def verify_cached(path, record):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"Missing regular cached package: {path.name}")
    if path.stat().st_size != record["size"] or sha256(path) != record["sha256"]:
        raise ValueError(f"Cached package failed integrity check; preserved: {path.name}")
    return path


def download(record, cache):
    path = cache_path(cache, record)
    if path.exists():
        return verify_cached(path, record)
    partial = path.with_name(path.name + ".part")
    if partial.is_symlink():
        raise ValueError("Refusing symlink download destination")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(record["url"], timeout=45) as source, partial.open("wb") as target:
                while block := source.read(1024 * 1024):
                    target.write(block)
                    if target.tell() > record["size"]:
                        raise ValueError(f"Download exceeds pinned size: {path.name}")
            verify_cached(partial, record)
            partial.replace(path)
            print(f"Verified {path.name}", flush=True)
            return path
        except (OSError, TimeoutError):
            if attempt == 2:
                raise
            time.sleep(attempt + 1)


def installed_matches(prefix, lock):
    records = {}
    for path in (prefix / "conda-meta").glob("*.json"):
        row = json.loads(path.read_text())
        records[row["name"]] = row
    wanted = {row["name"]: row for row in lock["packages"]}
    if set(records) != set(wanted):
        return False
    return all(
        (records[name].get("version"), records[name].get("build")) ==
        (record["version"], record["build"])
        for name, record in wanted.items()
    )


def install(root, lock, lock_hash):
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "amd64"):
        raise ValueError("The native runtime requires Linux x86_64 with glibc")
    cache = root / "downloads"
    for record in [lock["micromamba"], *lock["packages"]]:
        verify_cached(cache_path(cache, record), record)
    prefix = root / "ffmpeg"
    receipt_path = root / "RUNTIME_READY.json"
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        if receipt.get("lock_sha256") != lock_hash:
            raise ValueError("Runtime belongs to a different lock; choose a new destination")
        if not installed_matches(prefix, lock):
            raise ValueError("Installed runtime metadata changed; existing files preserved")
    else:
        intent_path = root / "INSTALL_INTENT.json"
        if prefix.exists():
            if (not intent_path.exists() or
                    json.loads(intent_path.read_text()).get("lock_sha256") != lock_hash):
                raise ValueError("Existing runtime has no matching install intent; preserved")
            if not (prefix / "conda-meta/history").is_file():
                raise ValueError("Incomplete prefix has no conda history; preserved for diagnosis")
        intent_path.write_text(json.dumps({"lock_sha256": lock_hash, "prefix": str(prefix)}, indent=2))
        explicit = root / "runtime-explicit.txt"
        # SHA256 was checked independently above. Conda explicit syntax uses MD5.
        explicit.write_text("@EXPLICIT\n" + "".join(
            cache_path(cache, record).resolve().as_uri() + "#" + record["md5"] + "\n"
            for record in lock["packages"]
        ))
        executable = cache_path(cache, lock["micromamba"])
        executable.chmod(0o700)
        command = [str(executable), "--no-rc", "--root-prefix", str(root / "mamba"),
                   "install" if prefix.exists() else "create", "--yes", "--offline",
                   "--prefix", str(prefix), "--file", str(explicit)]
        with (root / "installation.log").open("a") as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
        if not installed_matches(prefix, lock):
            raise ValueError("Installed package metadata do not match the pinned lock")
    shared = list((prefix / "lib").glob("libavdevice.so*"))
    if not shared:
        raise ValueError("Shared libavdevice was not installed")
    env = dict(os.environ)
    env["LD_LIBRARY_PATH"] = str(prefix / "lib") + (
        ":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    checked = subprocess.run([str(prefix / "bin/ffmpeg"), "-version"],
                             env=env, check=True, capture_output=True, text=True, timeout=20)
    receipt = dict(status="INSTALLED_NATIVE_DECODE_STILL_REQUIRED", prefix=str(prefix),
                   lock_sha256=lock_hash, package_count=len(lock["packages"]),
                   ffmpeg=checked.stdout.splitlines()[0])
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lock", type=Path, default=Path(__file__).resolve().parents[1] /
                        "configs/ffmpeg-linux-64-lock.json")
    parser.add_argument("--destination", type=Path, default=Path(".runtime"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--download-only", action="store_true")
    mode.add_argument("--install-offline", action="store_true")
    args = parser.parse_args()
    lock = load_lock(args.lock)
    root = args.destination.resolve()
    root.mkdir(parents=True, exist_ok=True)
    with (root / "INSTALL.lock").open("a") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        cache = root / "downloads"
        cache.mkdir(exist_ok=True)
        if not args.install_offline:
            with ThreadPoolExecutor(max_workers=4) as pool:
                list(pool.map(lambda record: download(record, cache),
                              [lock["micromamba"], *lock["packages"]]))
            (root / "DOWNLOAD_READY.json").write_text(json.dumps({
                "status": "PASS", "lock_sha256": sha256(args.lock),
                "files": len(lock["packages"]) + 1
            }, indent=2) + "\n")
        if not args.download_only:
            install(root, lock, sha256(args.lock))


if __name__ == "__main__":
    main()
