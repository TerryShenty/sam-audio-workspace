"""Plan and archive best/last checkpoints after successful training termination.

Never deletes checkpoints or retries an unknown upload outcome. On Slurm, run
the transfer phase after the GPU allocation ends, using the site's transfer node.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from checkpoint_archive import manifest, verify
from select_best_checkpoint import select


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def plan(root, expected, engineering_subset=False):
    root = Path(root).resolve()
    status = json.loads((root / "RESULT.json").read_text()).get("status")
    if status not in ("COMPLETE", "CHECKPOINTED"):
        raise ValueError("Only successfully completed or checkpointed runs may be archived")
    if expected != {"msdwild": 78, "easycom": 207} and not engineering_subset:
        raise ValueError("Formal archival requires MSDWild78 and EasyCom207")
    config = json.loads((root / "effective-config.json").read_text())
    if bool(config.get("engineering_validation_subset", False)) != engineering_subset:
        raise ValueError("Archive scope disagrees with the recorded training scope")
    latest = json.loads((root / "latest-checkpoint.json").read_text())
    last = latest.get("path", "")
    if (not isinstance(last, str) or Path(last).name != last or not last.endswith(".pt")
            or type(latest.get("global_step")) is not int or latest["global_step"] < 1):
        raise ValueError("Invalid latest successful checkpoint record")
    best = select(root, expected)
    roles = {"best": best["selected"]["checkpoint"], "last": last}
    validation_files = []
    for name in ("summary.json", "scores.json", "context.json"):
        validation_files.extend(sorted(root.glob("validation/*/" + name)))
    archives = {}
    for role, checkpoint in roles.items():
        expected_manifest = manifest(root, [root / checkpoint, *validation_files])
        if expected_manifest["files"][checkpoint]["size"] == 0:
            raise ValueError("Empty checkpoint")
        archives[role] = {"checkpoint": checkpoint, "manifest": expected_manifest}
    return {
        "version": 1,
        "scope": "ENGINEERING_SUBSET" if engineering_subset else "FORMAL_VALIDATION_285",
        "terminal_status": status,
        "latest_step": latest["global_step"],
        "selection": best,
        "roles": archives,
        "model_resume": "NOT_TESTED_BY_ARCHIVAL",
        "server_cleanup": False,
    }


def receipt_matches(receipt, record, entity, project):
    artifact = receipt.get("artifact", "")
    return (
        bool(re.fullmatch(re.escape(entity + "/" + project + "/") + r"[^/:]+:v[0-9]+", artifact))
        and receipt.get("checkpoint") == record["checkpoint"]
        and receipt.get("files") == record["manifest"]["files"]
        and receipt.get("content_roundtrip") == "PASS"
        and receipt.get("verified_download_files") == len(record["manifest"]["files"])
    )


def upload_one(root, checkpoint, env):
    subprocess.run(
        [sys.executable, str(Path(__file__).with_name("upload_results.py")),
         "--run-dir", str(root), "--checkpoint", checkpoint],
        env=env, check=True, timeout=900,
    )
    return json.loads((root / "UPLOAD_RECEIPT.json").read_text())


def archive(root, planned, entity, project, uploader=upload_one):
    if os.environ.get("SLURM_JOB_GPUS") or os.environ.get("SLURM_STEP_GPUS"):
        raise ValueError("Archive transfers must run after releasing the Slurm GPU allocation")
    if any(not re.fullmatch(r"[A-Za-z0-9_.-]+", value) for value in (entity, project)):
        raise ValueError("Explicit W&B entity/project names required")
    root = Path(root).resolve()
    transaction = dict(plan=planned, destination=dict(entity=entity, project=project))
    key = hashlib.sha256(canonical(transaction).encode()).hexdigest()
    directory = root / "artifact_handoffs" / key
    directory.mkdir(parents=True, exist_ok=True)
    with (root / "ARTIFACT_HANDOFF.lock").open("a") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Verify the frozen inputs on every invocation, even when receipts exist.
        for record in planned["roles"].values():
            verify(root, record["manifest"])
        atomic_json(directory / "PLAN.json", transaction)
        results = {}
        for role, record in planned["roles"].items():
            receipt_path = directory / (role + "-receipt.json")
            intent = directory / (role + "-intent.json")
            if receipt_path.exists():
                receipt = json.loads(receipt_path.read_text())
                if not receipt_matches(receipt, record, entity, project):
                    raise ValueError("Existing role receipt failed verification")
            else:
                # The earlier uploader retains a content-keyed verified receipt.
                # Reconcile it first, including a crash after upload but before this
                # wrapper recorded its role. Never retry an unresolved intent.
                candidates = list(results.values())
                for path in sorted((root / "upload_receipts").glob("*.json")):
                    candidates.append(json.loads(path.read_text()))
                receipt = next((row for row in candidates
                                if receipt_matches(row, record, entity, project)), None)
                if receipt is None:
                    if intent.exists():
                        raise ValueError("Unknown prior upload outcome; reconcile W&B before retrying")
                    with intent.open("x") as stream:
                        json.dump({"status": "STARTED", "checkpoint": record["checkpoint"],
                                   "destination": transaction["destination"]}, stream)
                    env = dict(os.environ, WANDB_ENTITY=entity, WANDB_PROJECT=project,
                               WANDB_MODE="online",
                               WANDB_RUN_ID="handoff-" + key[:16] + "-" + role,
                               WANDB_RESUME="allow")
                    receipt = uploader(root, record["checkpoint"], env)
                    if not receipt_matches(receipt, record, entity, project):
                        raise ValueError("Uploaded role receipt does not match frozen input")
                verify(root, record["manifest"])
                atomic_json(receipt_path, receipt)
            results[role] = receipt
        result = {
            "status": "PASS_VERIFIED_CONTENT_ROUNDTRIP",
            "transaction": key,
            "scope": planned["scope"],
            "roles": results,
            "model_resume": "NOT_TESTED_BY_ARCHIVAL",
            "server_cleanup": False,
        }
        atomic_json(directory / "RESULT.json", result)
        atomic_json(root / "BEST_LAST_HANDOFF.json", result)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--expected-counts", default='{"msdwild":78,"easycom":207}')
    parser.add_argument("--engineering-subset", action="store_true")
    parser.add_argument("--upload", action="store_true", help="Otherwise only inspect and print the plan")
    parser.add_argument("--entity", default=os.environ.get("WANDB_ENTITY") or "terryshen066-fudan-university")
    parser.add_argument("--project", default=os.environ.get("WANDB_PROJECT") or "sam-audio")
    args = parser.parse_args()
    planned = plan(args.run_dir, json.loads(args.expected_counts), args.engineering_subset)
    result = archive(args.run_dir, planned, args.entity, args.project) if args.upload else planned
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
