"""CPU bridge from a verified media/GT workflow to an encoder cache plan.

No decoding, encoding, CUDA, training, network or validation changes. A cache
plan is not a completed cache. The caller supplies the sealed runtime planner.
"""
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace
import uuid

from prepare_selected_media import (
    atomic_json, canonical, digest, receipt_index, selected_metadata,
    verified_files,
)
from prepare_training_spans import RULE, support


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def audit(workflow):
    root = Path(workflow).resolve()
    ready = read(root / "WORKFLOW_READY.json")
    require(ready["status"] == "CPU_MEDIA_AND_GT_READY"
            and ready["training_ready"] is False, "CPU/GT workflow is not ready")
    media, prepared, gtroot = (root / x for x in ("media", "prepared", "support"))
    require(Path(ready["training_rows"]) == gtroot / "train_rows.json",
            "Workflow training rows do not point at its own support output")
    files = {}

    def remember(path, expected=None, size=None):
        path = Path(path)
        require(path.is_file() and not path.is_symlink(), "Missing regular input")
        before = path.stat()
        checksum = digest(path)
        after = path.stat()
        require(before == after, "Input changed while hashing")
        require(expected is None or expected == checksum, "Input hash mismatch")
        require(size is None or size == before.st_size, "Input size mismatch")
        files[str(path)] = dict(sha256=checksum, bytes=before.st_size,
                               mtime_ns=before.st_mtime_ns, inode=before.st_ino)
        return checksum

    remember(root / "WORKFLOW_READY.json")
    remember(root / "WORKFLOW_PLAN.json")
    require(read(root / "WORKFLOW_PLAN.json") == ready["plan"], "Selection changed")
    release, videos, prompts, _, scope = selected_metadata(media)
    require(release["repo"] == ready["plan"]["repository"]
            and release["revision"] == ready["plan"]["revision"]
            and scope == ready["scope"], "Release identity or scope changed")
    ids = sorted(v["composite_id"] for v in videos)
    require((ready["plan"]["ids"] == ids and ready["plan"]["all_rows"] is False)
            or (ready["plan"]["ids"] is None and ready["plan"]["all_rows"] is True
                and scope == "COMPLETE_SELECTED_RELEASE"), "Selection coverage changed")
    for name, checksum in ready["metadata"].items():
        require(name in ("RELEASE.json", "videos.jsonl", "prompts.jsonl"),
                "Unexpected metadata file")
        remember(media / name, checksum)
    require(set(ready["metadata"]) == {"RELEASE.json", "videos.jsonl", "prompts.jsonl"},
            "Missing metadata identity")
    cpu, gt = read(prepared / "CPU_READY.json"), read(gtroot / "GT_SUPPORT_READY.json")
    remember(prepared / "CPU_READY.json", ready["cpu_receipt_sha256"])
    remember(gtroot / "GT_SUPPORT_READY.json", ready["gt_receipt_sha256"])
    require(cpu == ready["cpu_receipt"] and gt == ready["gt_receipt"],
            "Workflow references different CPU or GT receipts")
    require(cpu["status"] == "PASS" and cpu["metadata"] == ready["metadata"]
            and cpu["revision"] == release["revision"]
            and cpu["scope"] == scope, "CPU identity changed")
    require(gt["status"] == "PASS_CPU_GT_SUPPORT" and gt["rule"] == RULE
            and gt["scope"] == scope and gt["training_ready"] is False
            and gt["identity"] == dict(rule=RULE, revision=release["revision"],
                                      metadata=ready["metadata"],
                                      prepared_rows_sha256=cpu["rows_sha256"]),
            "GT identity changed")
    remember(prepared / "train_rows.json", cpu["rows_sha256"])
    require(set(gt["files"]) == {"train_rows.json", "targets.json"}, "GT file set changed")
    for name, checksum in gt["files"].items():
        remember(gtroot / name, checksum)
    raw, rows, targets = (read(p) for p in
                         (prepared / "train_rows.json", gtroot / "train_rows.json",
                          gtroot / "targets.json"))
    require(len(rows) == len(raw) == len(prompts) == ready["prompts"] == gt["prompts"],
            "Prompt count changed")
    require(len(videos) == ready["videos"] == cpu["videos"], "Video count changed")
    target_map = {(t["composite_id"], t["slot"]): t for t in targets}
    require(len(target_map) == len(targets) == cpu["targets"] == gt["targets"],
            "Missing or duplicate targets")
    index = receipt_index(media)
    for p in sorted((media / "receipts").glob("*.json")):
        remember(p)
    for video in videos:
        cid = video["composite_id"]
        archived = verified_files(media, video, index)
        for name, spec in archived.items():
            remember(media / name, spec["sha256"], spec["bytes"])
        recipe = read(media / "data" / cid / "recipe.json")
        comp_path = prepared / cid / "COMPOSITE_READY.json"
        remember(comp_path)
        comp = read(comp_path)
        key = hashlib.sha256(canonical(
            dict(metadata=ready["metadata"], video=video, files=archived)).encode()).hexdigest()
        expected = {f"{kind}_{t['slot']}.wav" for t in video["targets"]
                    for kind in ("target", "residual")}
        require(comp["input_key"] == key and set(comp["outputs"]) == expected,
                "Prepared composite identity changed")
        for name, spec in comp["outputs"].items():
            remember(prepared / cid / name, spec["sha256"], spec["bytes"])
        for t in video["targets"]:
            bound = target_map[(cid, t["slot"])]
            expected_support = support(video, recipe, t)
            require(all(bound[k] == v for k, v in expected_support.items()),
                    "GT layout no longer matches frozen source placement")
            require(bound["source_id"] == t["source_id"]
                    and bound["window_id"] == t["window_id"]
                    and bound["recipe_sha256"] == video["recipe_sha256"]
                    and bound["archived_recipe_sha256"] ==
                    archived[f"data/{cid}/recipe.json"]["sha256"]
                    and bound["target_sha256"] ==
                    comp["outputs"][f"target_{t['slot']}.wav"]["sha256"],
                    "GT target provenance changed")
    originals = {r["prompt_id"]: r for r in prompts}
    require(len(originals) == len(rows)
            and [r["prompt_id"] for r in rows] == [r["prompt_id"] for r in raw],
            "Prompt order or identity changed")
    for row, original in zip(rows, raw):
        cid, slot = row["composite_id"], row["slot"]
        expected_row = dict(original, training_gt_rule=RULE,
                            training_gt_spans=target_map[cid, slot]["intervals_seconds"])
        require(row == expected_row, "GT stage changed original prompt fields")
        require(all(row[k] == v for k, v in originals[row["prompt_id"]].items()),
                "Original published prompt changed")
        paths = dict(video_path=media / "data" / cid / "video.mp4",
                     mixture_audio_path=media / "data" / cid / "mixture.wav",
                     gt_audio_path=prepared / cid / f"target_{slot}.wav",
                     residual_audio_path=prepared / cid / f"residual_{slot}.wav")
        require(all(row[k] == str(path) for k, path in paths.items()),
                "Encoder row escaped its audited media")
    return ready, rows, files


def prepare(workflow, output, planner):
    require(not os.environ.get("SLURM_JOB_GPUS") and not os.environ.get("SLURM_STEP_GPUS"),
            "Cache input hashing/planning requires CPU resources")
    root, output = Path(workflow).resolve(), Path(output).resolve()
    require(output != root and not root.is_relative_to(output)
            and not output.is_relative_to(root), "Use an independent plan output")
    output.mkdir(parents=True, exist_ok=True)
    with (output / "PLAN.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        attempt = output / "attempts" / uuid.uuid4().hex
        attempt.mkdir(parents=True)
        ready_path = output / "CACHE_INPUT_READY.json"
        previous = None
        if ready_path.exists():
            previous = read(ready_path)
            ready_path.replace(attempt / "PREVIOUS_READY.json")
        try:
            workflow_ready, rows, files = audit(root)
            encoded_rows = copy.deepcopy(rows)
            for row in encoded_rows:
                require(not {"dataset", "clip_id", "target_source_id"} & row.keys(),
                        "Do not overwrite source row fields")
                row.update(dataset="avspeech", clip_id=row["composite_id"],
                           target_source_id=f"{row['slot']}::{row['prompt_id']}")
            dataset = SimpleNamespace(examples=[[r] for r in encoded_rows],
                                      data_root=Path("/"), max_samples=None,
                                      sample_rate=48000, seed=17,
                                      require_explicit_mixture_path=True)
            plan = planner({"train": dataset})
            require(plan["splits"]["train"]["training_support_rule"] == RULE,
                    "Runtime planner dropped GT")
            entries = plan["splits"]["train"]["entries"]
            require(len(entries) == len(rows) and all(len(e["variants"]) == 1 for e in entries),
                    "Planner changed the accepted prompt-as-row sampling semantics")
            require([e["variants"][0]["training_support"]["prompt_id"] for e in entries]
                    == [r["prompt_id"] for r in rows], "Planner lost prompt provenance")
            result = dict(status="CPU_CACHE_INPUT_READY", training_ready=False,
                          gpu_features="NOT_GENERATED", gpu_gt_forward="NOT_TESTED",
                          validation="NOT_MODIFIED", scope=workflow_ready["scope"],
                          revision=workflow_ready["plan"]["revision"], rule=RULE,
                          prompts=len(rows), targets=workflow_ready["cpu_receipt"]["targets"],
                          cache_plan_id=plan["id"], input_files=files,
                          sampling="one selected prompt per row; original ordering preserved")
            for name, value in (("encoder_rows.json", encoded_rows), ("cache_plan.json", plan)):
                dest = output / name
                if dest.exists():
                    require(read(dest) == value, "Existing output belongs to different inputs")
                else:
                    atomic_json(dest, value)
            result["outputs"] = {n: digest(output / n)
                                 for n in ("encoder_rows.json", "cache_plan.json")}
            # Do not issue a plan after a concurrent producer changed its inputs.
            for name, spec in files.items():
                st = Path(name).stat()
                require(st.st_size == spec["bytes"] and st.st_ino == spec["inode"]
                        and st.st_mtime_ns == spec["mtime_ns"], "Inputs changed during planning")
            if previous is not None:
                require(previous == result, "Previous readiness no longer matches current input")
            atomic_json(ready_path, result)
            atomic_json(attempt / "RESULT.json", result)
            return result
        except BaseException as exc:
            atomic_json(attempt / "RESULT.json", dict(status="FAILED", error=str(exc)))
            raise
