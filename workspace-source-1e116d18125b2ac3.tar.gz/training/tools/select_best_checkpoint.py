"""Select a retained checkpoint from complete real validation summaries.

Explicit dataset-equal criterion; does not upload, delete, or label partial cohorts best.
"""
import argparse,json,math
from pathlib import Path
from checkpoint_archive import digest

def select(root, expected):
    root=Path(root).resolve(); candidates=[]
    if not expected or any(type(n) is not int or n<=0 for n in expected.values()):
        raise ValueError('Positive expected dataset counts required')
    for path in sorted((root/'validation').glob('*/summary.json')):
        summary=json.loads(path.read_text())
        if set(summary)!=set(expected):raise ValueError('Incomplete validation datasets: '+path.parent.name)
        scores=[]
        for ds,n in expected.items():
            row=summary[ds]
            if type(row.get('n')) is not int or row['n']!=n:raise ValueError('Validation count mismatch: '+ds)
            score=row.get('aligned_si_sdr_db')
            if isinstance(score,bool) or not isinstance(score,(int,float)) or not math.isfinite(score):raise ValueError('Nonfinite/missing validation score')
            scores.append(score)
        checkpoint=root/(path.parent.name+'.pt')
        if not checkpoint.is_file() or not checkpoint.resolve().is_relative_to(root):
            raise ValueError('Scored checkpoint unavailable: '+checkpoint.name)
        candidates.append({'checkpoint':checkpoint.name,'score':sum(scores)/len(scores),'summary':str(path.relative_to(root)),'datasets':summary})
    if not candidates:raise ValueError('No complete scored checkpoints')
    # Deterministic lexical tie break; no claim of an earlier epoch on a tie.
    best=sorted(candidates,key=lambda r:(-r['score'],r['checkpoint']))[0]
    return {'criterion':'dataset_equal_mean_aligned_si_sdr_db','expected_counts':expected,
            'candidate_count':len(candidates),'selected':best,
            'checkpoint_sha256':digest(root/best['checkpoint']),
            'scope':'best among available complete summaries; not an unobserved epoch'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);p.add_argument('--expected-counts',required=True,help='JSON mapping, e.g. {"msdwild":78,"easycom":207}');p.add_argument('--criterion',required=True,choices=['dataset_equal_mean_aligned_si_sdr_db']);a=p.parse_args()
    root=Path(a.run_dir); result=select(root,json.loads(a.expected_counts));pending=root/'BEST_CHECKPOINT.json.tmp';pending.write_text(json.dumps(result,indent=2)+'\n');pending.replace(root/'BEST_CHECKPOINT.json');print(json.dumps(result))
