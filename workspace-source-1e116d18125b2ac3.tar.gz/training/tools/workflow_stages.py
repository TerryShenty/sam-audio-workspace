"""Actual transfer/CPU/GPU stages for the private integration candidate.

Every stage consumes this workspace's prior receipts. No training or publication
is implied by a successful preparation/cache stage.
"""
import argparse
import copy
import fcntl
import shutil
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

from workflow_contract import (check_ranks, cpu_only, inputs_unchanged, key, read,
                               selection, sha, shards, write)


def download(cfg, root):
    cpu_only()
    if "dm" not in socket.gethostname():
        raise ValueError("Use DataMover for the cluster transfer acceptance")
    from prepare_avspeech_workflow import workflow
    media = root / "avspeech/media"
    intent = root / "download-intent.json"
    pause = root / "download-interruption.json"
    if not intent.exists():
        if media.exists() and any(media.iterdir()):
            raise ValueError("Cold media acceptance requires an empty output")
        write(intent, dict(status="STARTED", cold_media=True, revision=cfg["revision"],
                           ids=cfg["ids"], existing_model_bytes_reused=True))
    elif read(intent)["revision"] != cfg["revision"] or read(intent)["ids"] != cfg["ids"]:
        raise ValueError("Download intent selection changed")
    if not pause.exists():
        try:
            workflow(root / "avspeech", cfg["revision"], cfg["ids"],
                     phase="download", download_stop_after_receipts=1)
        except subprocess.CalledProcessError as exc:
            if exc.returncode != 75:
                raise
            receipts = sorted((media / "receipts").glob("*.json"))
            if len(receipts) != 1:
                raise ValueError("Controlled stop did not leave exactly one receipt")
            write(pause, dict(status="CONTROLLED_INTERRUPT", exit_code=75,
                              receipts={str(p): sha(p) for p in receipts}))
        else:
            raise ValueError("Controlled transfer interruption was not observed")
    before = read(pause)["receipts"]
    for p, h in before.items():
        if sha(p) != h:
            raise ValueError("Interrupted verified receipt changed")
    result = workflow(root / "avspeech", cfg["revision"], cfg["ids"], phase="download")
    log = Path(result["attempt"]) / "download.log"
    if "verified receipt reused" not in log.read_text():
        raise ValueError("Resume did not prove existing receipt reuse")
    for p, h in before.items():
        if sha(p) != h:
            raise ValueError("Reused receipt rewritten")
    return dict(status="DOWNLOAD_READY", cold_media=True, controlled_interruption=True,
                resumed_receipts=len(before), revision=cfg["revision"],
                videos=result["videos"], prompts=result["prompts"],
                metadata=result["metadata"], training_ready=False)


def prepare(cfg, root):
    cpu_only()
    from prepare_avspeech_workflow import workflow
    from prepare_encoder_input import prepare as prepare_input
    from sam_audio.native_finetuning.feature_cache import make_cache_plan
    from data_manifest import verify
    from delivery_cohort import check
    # The network phase already finished. No HF download in this allocation.
    upstream = read(root / "stages/download/RESULT.json")
    if upstream["status"] != "DOWNLOAD_READY":
        raise ValueError("Download stage not ready")
    media = workflow(root / "avspeech", cfg["revision"], cfg["ids"], phase="prepare")
    planned = prepare_input(root / "avspeech", root / "encoder-input", make_cache_plan)
    if media["prompts"] != 13 or planned["targets"] != 8 or planned["prompts"] != 13:
        raise ValueError("Frozen selection coverage changed")
    validation_root = Path(cfg["validation_bundle"])
    if sha(validation_root / "manifest.json") != cfg["validation_manifest_sha256"]:
        raise ValueError("Private validation bundle identity changed")
    manifest = read(validation_root / "manifest.json")
    verify(validation_root, manifest)
    bundle = read(validation_root / "bundle.json")
    validation = read(validation_root / bundle["validation_manifest"])
    cohort = check(validation["items"], engineering_subset=False)
    if cohort["cohort_sha256"] != cfg["cohort_sha256"]:
        raise ValueError("Full285 protocol changed")
    # Bind verified old validation files by metadata so GPU stages do no bulk hash.
    snapshots = {}
    for row in manifest["files"]:
        p = validation_root / row["path"]
        stat = p.stat()
        snapshots[str(p)] = dict(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns,
                                 inode=stat.st_ino, sha256=row["sha256"])
    # Explicitly resolve the shared model cache before acquiring GPUs. This is
    # part of the new data flow; no download or model hashing happens on GPUs.
    import torch
    from sam_audio.model.config import T5EncoderConfig
    from sam_audio.model.text_encoder import T5TextEncoder
    from huggingface_hub import hf_hub_download
    torch.set_num_threads(1)
    if os.environ.get("HF_HUB_CACHE") != cfg["hf_hub_cache"]:
        raise ValueError("Explicit offline model cache binding missing")
    cached_config = hf_hub_download("t5-base", "config.json", local_files_only=True)
    model_root = Path(cfg["model"])
    model_config = read(model_root / "config.json")
    text = T5TextEncoder(T5EncoderConfig(**model_config["text_encoder"]))
    if text.pretrained_identity != cfg["base_signature"]["text_encoder_identity"]:
        raise ValueError("Offline text encoder identity changed")
    del text
    if torch.cuda.is_initialized():
        raise ValueError("CPU preflight unexpectedly initialized CUDA")
    model_files = {}
    for name, expected_hash in cfg["model_files"].items():
        path = model_root / name
        if sha(path) != expected_hash:
            raise ValueError("Model bytes changed: " + name)
        st = path.stat()
        model_files[str(path)] = dict(bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                                      inode=st.st_ino, sha256=expected_hash)
    plan = read(root / "encoder-input/cache_plan.json")
    for rank in range(cfg["world"]):
        shards(plan, rank, cfg["world"])
    result = dict(status="CPU_INPUT_READY", inputs=planned, model_files=model_files,
                  explicit_hf_cache=cfg["hf_hub_cache"], t5_config=cached_config,
                  validation=dict(root=str(validation_root), bundle=bundle,
                                  manifest=manifest, snapshots=snapshots, cohort=cohort),
                  reused_validation=True, new_training_cache=False, training_ready=False)
    return result


def encode(cfg, root):
    import torch
    from sam_audio import SAMAudio, SAMAudioProcessor
    from sam_audio.native_finetuning.feature_cache import ComponentStore, FrozenExtractor, build_components
    from sam_audio.native_finetuning.optimized_utils import StageTimer
    from sam_audio.native_finetuning.delivery_impl import model_signature
    rank, world = int(os.environ["LOCAL_RANK"]), int(os.environ["WORLD_SIZE"])
    if world != cfg["world"]:
        raise ValueError("GPU request and worker count disagree")
    before = read(root / "stages/prepare/RESULT.json")
    if before["status"] != "CPU_INPUT_READY":
        raise ValueError("CPU preparation missing")
    inputs_unchanged(before["inputs"]["input_files"])
    inputs_unchanged(before["model_files"])
    plan = read(root / "encoder-input/cache_plan.json")
    if sha(root / "encoder-input/cache_plan.json") != before["inputs"]["outputs"]["cache_plan.json"]:
        raise ValueError("CPU plan changed")
    partition = shards(plan, rank, world)
    identity = key(dict(plan=plan, revision=cfg["revision"], model=cfg["base_signature"]))
    output = root / "encoded"
    report = output / f"rank{rank}.json"
    if report.exists():
        raise ValueError("Encoding rank already has a receipt; reconcile before reuse")
    start = time.monotonic()
    torch.set_num_threads(1)
    torch.cuda.set_device(rank)
    torch.manual_seed(2026)
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True)
    device = torch.device("cuda", rank)
    model = SAMAudio.from_pretrained(cfg["model"], strict=True, visual_ranker=None,
                                    text_ranker=None, span_predictor=None)
    model.to(device=device, dtype=torch.bfloat16).eval().requires_grad_(False)
    processor = SAMAudioProcessor.from_pretrained(cfg["model"])
    signature_cfg = read(cfg["train_config"])
    signature_cfg.update(max_seconds=None, video_frame_chunk=8)
    signature = model_signature(cfg["model"], signature_cfg, processor, model)
    if signature["verified_base"] != cfg["base_signature"]:
        raise ValueError("Loaded encoder base changed")
    # The signature describes encoder math. GT is bound in the plan/catalog,
    # not supplied to the frozen shared mixture encoder.
    signature["workflow"] = dict(revision=cfg["revision"], full_duration=True,
                                 video_frame_chunk=8, shared_encoding="nullGT",
                                 train_rule="source-placement-480000-samples-v1")
    store = ComponentStore(output / "components", signature)
    extractor = FrozenExtractor(model, processor, device, torch.bfloat16,
                                StageTimer(device), to_cpu=True, video_frame_chunk=8)
    assigned = dict(partition, splits={})
    original_put = store.put
    completed = []

    def put(kind, item, value):
        original_put(kind, item, value)
        completed.append([kind, item])
        write(output / f"progress-rank{rank}.json",
              dict(rank=rank, completed=completed, seconds=time.monotonic()-start))
        print(f"ENCODED rank={rank} kind={kind} count={len(completed)}", flush=True)

    store.put = put
    result = build_components(assigned, store, extractor, rank=0, world_size=1)
    properties = torch.cuda.get_device_properties(rank)
    if torch.cuda.max_memory_allocated(rank) >= properties.total_memory * .92:
        raise ValueError("Insufficient encoding memory headroom")
    receipt = dict(result, status="ENCODED", rank=rank, world=world,
                   identity=identity, assigned={k: sorted(v) for k, v in partition.items()},
                   signature=signature, gpu_uuid=str(properties.uuid),
                   peak_bytes=torch.cuda.max_memory_allocated(rank),
                   seconds=time.monotonic()-start, completed=completed)
    write(report, receipt)
    return receipt


def export(cfg, root):
    cpu_only()
    import torch
    from sam_audio.native_finetuning.feature_cache import ComponentStore, finalize_catalog
    from sam_audio.native_finetuning.training_support import check_entry
    from delivery_cohort import check
    from export_bundle import export as export_bundle
    torch.set_num_threads(1)
    prepared = read(root / "stages/prepare/RESULT.json")
    inputs_unchanged(prepared["inputs"]["input_files"])
    inputs_unchanged(prepared["validation"]["snapshots"])
    plan = read(root / "encoder-input/cache_plan.json")
    identity = key(dict(plan=plan, revision=cfg["revision"], model=cfg["base_signature"]))
    reports = [read(root / f"encoded/rank{rank}.json") for rank in range(cfg["world"])]
    check_ranks(reports, plan, cfg["world"], identity)
    if any(r["signature"] != reports[0]["signature"] for r in reports):
        raise ValueError("Encoder signatures differ")
    store = ComponentStore(root / "encoded/components", reports[0]["signature"])
    catalog = read(finalize_catalog(copy.deepcopy(plan), store, 48000))
    original = read(root / "encoder-input/encoder_rows.json")
    if len(catalog["splits"]["train"]["entries"]) != len(original):
        raise ValueError("Encoded target coverage changed")

    def finite(value):
        if isinstance(value, torch.Tensor):
            if value.is_floating_point() and not torch.isfinite(value).all():
                raise ValueError("Nonfinite encoded tensor")
        elif isinstance(value, dict):
            for v in value.values():
                finite(v)

    files, seen = [], set()
    for entry, row in zip(catalog["splits"]["train"]["entries"], original):
        refs = entry["variants"][0]
        if refs["prompt"] != row["prompt"].strip():
            raise ValueError("Encoded prompt changed")
        assembled = store.assemble(refs)
        finite(assembled)
        args = assembled["forward_args"]
        labels = args["anchor_ids"].gather(1, args["anchor_alignment"])
        if int((labels == 1).sum()) != 250 or labels.shape[1] != assembled["clean"].shape[1]:
            raise ValueError("New cache lost complete target GT support")
        for kind in ("mixture", "video", "clean", "text"):
            p = store.path(kind, refs[kind])
            if p not in seen:
                seen.add(p)
                finite(torch.load(p, map_location="cpu", weights_only=True))
                files.append(dict(source=str(p),
                                  destination=str(p.relative_to(root / "encoded"))))
    vr = Path(cfg["validation_bundle"])
    vb = prepared["validation"]["bundle"]
    validation = read(vr / vb["validation_manifest"])
    check(validation["items"], engineering_subset=False)
    supervision = check_entry(catalog, validation, read(cfg["train_config"]))
    staging = root / "export-input"
    staging.mkdir(exist_ok=False)
    write(staging / "catalog.json", catalog)
    files.append(dict(source=str(staging / "catalog.json"), destination="catalog.json"))
    # Existing validation has independent filenames. Preserve their exact bytes;
    # never replace with newly sampled validation or training GT anchors.
    names = {r["destination"] for r in files}
    for row in prepared["validation"]["manifest"]["files"]:
        name = row["path"]
        if not name.startswith("validation/"):
            continue
        if name in names:
            raise ValueError("Training/validation file collision")
        names.add(name)
        files.append(dict(source=str(vr / name), destination=name))
    audit_path = staging / "AUDIT.json"
    write(audit_path, dict(status="PASS", source_plan=plan["id"], rank_count=len(reports),
                           train_rows=len(original), supervision=supervision,
                           validation_scope="FORMAL_285", reused_validation=True))
    mapping = dict(audit=str(audit_path), files=files,
                   bundle=dict(train_catalog="catalog.json", train_components="components",
                               validation_manifest=vb["validation_manifest"],
                               scope="ENGINEERING_HF13_GT_TRAIN",
                               training_supervision=supervision,
                               validation_cohort=prepared["validation"]["cohort"]))
    manifest = export_bundle(mapping, root / "bundle")
    return dict(status="BUNDLE_READY", new_encoded_training_rows=len(original),
                reused_validation=True, validation_count=285, files=len(manifest["files"]),
                bytes=manifest["total_bytes"], manifest_sha256=sha(root / "bundle/manifest.json"),
                supervision=supervision, training_ready=True, training_executed=False,
                full_delivery="NOT_ACCEPTED")


def training(cfg, root, stage):
    """Execute run.sh and its real CLI wrappers, without calling a trainer API."""
    source = Path(__file__).resolve().parents[1]
    positions = {"train2": (0, 2), "train5": (2, 5),
                 "train8": (5, 8), "train9": (8, 9)}
    if stage not in positions:
        raise ValueError("Unplanned training stage")
    start, end = positions[stage]
    if read(root / "stages/export/RESULT.json")["status"] != "BUNDLE_READY":
        raise ValueError("No independent new bundle")
    output = root / "train"
    history = root / "stages" / stage / "previous"
    history.mkdir(parents=True, exist_ok=False)
    for name in ("RESULT.json", "effective-config.json", "WORKFLOW_RESULT.json", "FINALIZATION.json"):
        if (output / name).exists():
            shutil.copyfile(output / name, history / name)
    inputs_unchanged(read(root / "stages/prepare/RESULT.json")["model_files"])
    if start:
        prior = read(root / f"stages/audit{start}/RESULT.json")
        inputs_unchanged(prior["checkpoints"])
        resume = output / f"step-{start}.pt"
    command = ["bash", str(source / "run.sh"), "--config", cfg["train_config"],
               "--data-root", str(root / "bundle"), "--model", cfg["model"],
               "--output", str(output), "--epochs", "2", "--microbatch", "1",
               "--global-batch", "2", "--max-steps", "9",
               "--runtime-audit", "runtime-audit/" + stage]
    if start:
        command += ["--resume", str(resume)]
    if end != 9:
        command += ["--stop-after-step", str(end)]
    subprocess.run(command, check=True)
    terminal = read(output / "RESULT.json")
    wrapped = read(output / "WORKFLOW_RESULT.json")
    expected = "COMPLETE" if end == 9 else "CHECKPOINTED"
    if terminal["status"] != expected:
        raise ValueError("Trainer did not reach its planned terminal boundary")
    status = "ARCHIVAL_DEFERRED" if end == 9 else "TRAINING_CHECKPOINTED"
    if wrapped["status"] != status:
        raise ValueError("CLI wrapper terminal status mismatch")
    ranks = [read(output / "runtime-audit" / stage / f"rank{r}.json")
             for r in range(cfg["world"])]
    if len({r["gpu_uuid"] for r in ranks}) != cfg["world"]:
        raise ValueError("No distinct GPU computation")
    for rank, r in enumerate(ranks):
        if (r["rank"] != rank or r["status"] != "PASS"
                or [u["after"] for u in r["updates"]] != list(range(start+1, end+1))):
            raise ValueError("Per-rank actual optimization incomplete")
    return dict(status="TRAIN_STAGE_READY", start_step=start, end_step=end,
                terminal=terminal, wrapper=wrapped, ranks=ranks,
                full_delivery="NOT_ACCEPTED")


def audit_training(cfg, root, stage):
    cpu_only()
    import torch
    from audit_workflow_checkpoint import inspect, load_verified
    from sam_audio.native_finetuning.training_support import check_entry
    from delivery_cohort import check
    torch.set_num_threads(1)
    end = int(stage.removeprefix("audit"))
    train_result = read(root / f"stages/train{end}/RESULT.json")
    if train_result["end_step"] != end:
        raise ValueError("Wrong completed training stage")
    bundle = read(root / "bundle/bundle.json")
    catalog = read(root / "bundle" / bundle["train_catalog"])
    validation = read(root / "bundle" / bundle["validation_manifest"])
    config = read(cfg["train_config"])
    supervision = check_entry(catalog, validation, config)
    cohort = check(validation["items"], engineering_subset=False)
    config.update(max_steps=9, num_epochs=2, batch_size=1, world_size=2,
                  gradient_accumulation_steps=1, effective_batch_size=2,
                  compile=False, save_every=1, training_probe_max_targets=0,
                  training_supervision=supervision, validation_cohort=cohort,
                  model_local_path=cfg["model"], output_dir=str(root / "train"),
                  resume_from=(str(root / "train" / f"step-{ {2:0,5:2,8:5,9:8}[end] }.pt") if end != 2 else None))
    identity = dict(plan_id=catalog["plan_id"], signature=catalog["signature"],
                    training_supervision=supervision)
    names = {2: ["step-2.pt"], 5: ["half-1.pt", "step-5.pt"],
             8: ["epoch-1.pt", "step-8.pt"], 9: ["step-9.pt", "final.pt"]}[end]
    step_by_name = {"half-1.pt": 4, "epoch-1.pt": 7, "final.pt": 9}
    reports, snapshots = {}, {}
    for name in names:
        p = root / "train" / name
        stat = p.stat()
        trusted = dict(size=stat.st_size, sha256=sha(p))
        step = step_by_name.get(name, int(name[5:-3]) if name.startswith("step-") else None)
        expected = dict(position=[step, step // 7, step % 7],
                        verified_base=cfg["base_signature"], data_identity=identity,
                        config=config, scope="ENGINEERING_HF13_GT_NEW_WORKFLOW")
        state = load_verified(p, trusted)
        reports[name] = dict(inspect(state, expected), file=trusted,
                             config_sha256=key(state["config"]),
                             data_identity_sha256=key(state["data_identity"]))
        if reports[name]["model_tensors"] != 484 or reports[name]["trainable_elements"] != 42668032:
            raise ValueError("Incomplete trained state")
        del state
        snapshots[str(p)] = dict(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns,
                                 inode=stat.st_ino, sha256=trusted["sha256"])
    # Every complete validation must preserve the immutable protocol and noise.
    metric_dirs = {2: [], 5: [("half-1", 4)], 8: [("epoch-1", 7)], 9: [("final", 9)]}[end]
    for name, step in metric_dirs:
        directory = root / "train/validation" / name
        scores = read(directory / "scores.json")
        context = read(directory / "context.json")
        if len(scores) != 285 or context != dict(global_step=step, checkpoint=name+".pt"):
            raise ValueError("Incomplete validation or wrong coordinate")
        indexes = {e["index"]: e for e in validation["items"]}
        import math
        if sorted(r["index"] for r in scores) != sorted(indexes):
            raise ValueError("Validation coverage changed")
        for row in scores:
            if row["dataset"] != indexes[row["index"]]["dataset"]:
                raise ValueError("Validation identity mismatch")
            if not all(math.isfinite(row[k]) for k in
                       ("aligned_si_sdr_db", "si_sdr_db", "si_sdri_db")):
                raise ValueError("Nonfinite validation score")
        if name != "half-1":
            first = read(root / "train/validation/half-1/scores.json")
            if [(r["index"], r["noise_sha256"]) for r in scores] != [
                    (r["index"], r["noise_sha256"]) for r in first]:
                raise ValueError("Validation noise protocol changed")
    return dict(status="TRAIN_CPU_AUDIT_READY", end_step=end, reports=reports,
                checkpoints=snapshots, full_delivery="NOT_ACCEPTED")


def archive_results(cfg, root):
    cpu_only()
    if "dm" not in socket.gethostname():
        raise ValueError("Use DataMover for archival")
    import math
    import wandb
    from finalize_run import finalize
    from archive_best_last import plan
    train = root / "train"
    if read(root / "stages/audit9/RESULT.json")["status"] != "TRAIN_CPU_AUDIT_READY":
        raise ValueError("New completed run not yet audited")
    if read(train / "RESULT.json")["status"] != "COMPLETE":
        raise ValueError("Natural completion required")
    run_id = (train / "wandb-run-id.txt").read_text().strip()
    cloud = wandb.Api(timeout=60).run("terryshen066-fudan-university/sam-audio/" + run_id)
    remote = list(cloud.scan_history(page_size=100))
    local = [__import__("json").loads(line) for line in (train / "tracking.jsonl").read_text().splitlines()]
    matches = {}
    for name, step in (("half-1.pt", 4), ("epoch-1.pt", 7), ("final.pt", 9)):
        expected = [r for r in local if r.get("validation/checkpoint") == name]
        actual = [r for r in remote if r.get("validation/checkpoint") == name]
        if len(expected) != 1 or len(actual) != 1 or len(expected[0]) != 10:
            raise ValueError("Missing or duplicate cloud validation")
        expected = expected[0]
        if any(expected[f"validation/{dataset}/n"] != count
               for dataset, count in (("msdwild", 78), ("easycom", 207))):
            raise ValueError("Cloud validation count changed")
        if expected["validation/global_step"] != step:
            raise ValueError("Cloud score step changed")
        for k, v in expected.items():
            if isinstance(v, (int, float)):
                if not math.isfinite(v) or not math.isclose(v, actual[0][k], rel_tol=1e-6, abs_tol=1e-7):
                    raise ValueError("Cloud score differs: " + k)
            elif v != actual[0][k]:
                raise ValueError("Cloud coordinate differs")
        matches[name] = expected
    write(root / "CLOUD_SCORE_AUDIT.json", dict(status="PASS", run_id=run_id, records=matches))
    if not (root / "GPU_FINALIZATION.json").exists():
        write(root / "GPU_FINALIZATION.json", read(train / "FINALIZATION.json"))
    planned = plan(train, {"msdwild": 78, "easycom": 207}, False)
    result = finalize(train)
    if result["status"] != "ARCHIVED_VERIFIED_CONTENT":
        raise ValueError("Automatic finalization incomplete")
    directory = root / "restored"
    directory.mkdir(exist_ok=True)
    restored = {}
    for role in ("best", "last"):
        receipt = result["roles"][role]
        upload = directory / (role + "-upload.json")
        write(upload, receipt)
        target = directory / role
        env = dict(os.environ, WANDB_CACHE_DIR=str(directory / ("cache-" + role)),
                   WANDB_ARTIFACT_DIR=str(directory / ("artifacts-" + role)))
        subprocess.run([sys.executable, str(Path(__file__).with_name("restore_checkpoint.py")),
                        "--receipt", str(upload), "--output", str(target)], env=env,
                       check=True, timeout=900)
        restored[role] = read(target / "RESTORE_RECEIPT.json")
    return dict(status="ARCHIVE_AND_RESTORE_READY", transaction=result["transaction"],
                roles=restored, selection=planned["selection"], full_delivery="NOT_ACCEPTED",
                remaining="Actual downloaded-weight optimization through this controller")


def restorecheck(cfg, root):
    cpu_only()
    archive = read(root / "stages/archive/RESULT.json")
    if archive["status"] != "ARCHIVE_AND_RESTORE_READY":
        raise ValueError("Independent cloud restore incomplete")
    prior = {}
    for end in (5, 8, 9):
        prior.update(read(root / f"stages/audit{end}/RESULT.json")["reports"])
    plans = {}
    for role in ("best", "last"):
        receipt = archive["roles"][role]
        path = Path(receipt["checkpoint"])
        if receipt["content_verification"] != "PASS" or path.name not in prior:
            raise ValueError("Downloaded checkpoint lacks original CPU state evidence")
        report = prior[path.name]
        st = path.stat()
        if st.st_size != report["file"]["size"] or sha(path) != report["file"]["sha256"]:
            raise ValueError("Downloaded checkpoint differs from inspected original")
        start = report["step"]
        if start not in (4, 7, 9) or (role == "last" and start != 9):
            raise ValueError("Unplanned artifact position")
        plans[role] = dict(checkpoint=str(path), start=start, end=start+1,
                           horizon=10 if start==9 else 9, original_report=report,
                           snapshot={str(path): dict(bytes=st.st_size,
                               mtime_ns=st.st_mtime_ns, inode=st.st_ino,
                               sha256=report["file"]["sha256"])})
    return dict(status="RESTORED_INPUTS_READY", roles=plans)


def resume(cfg, root):
    source = Path(__file__).resolve().parents[1]
    prepared = read(root / "stages/restorecheck/RESULT.json")
    if prepared["status"] != "RESTORED_INPUTS_READY":
        raise ValueError("Restored input receipt missing")
    results = {}
    for role, plan in prepared["roles"].items():
        inputs_unchanged(plan["snapshot"])
        inputs_unchanged(read(root / "stages/prepare/RESULT.json")["model_files"])
        output = root / "continued" / role
        command = ["bash", str(source / "run.sh"), "--config", cfg["train_config"],
                   "--data-root", str(root / "bundle"), "--model", cfg["model"],
                   "--output", str(output), "--epochs", "2", "--microbatch", "1",
                   "--global-batch", "2", "--max-steps", str(plan["horizon"]),
                   "--resume", plan["checkpoint"], "--stop-after-step", str(plan["end"]),
                   "--runtime-audit", "runtime-audit/continued"]
        if plan["start"] == 9:
            command += ["--resume-max-steps-from", "9"]
        subprocess.run(["timeout", "--kill-after=10", "240", *command], check=True)
        terminal = read(output / "RESULT.json")
        wrapped = read(output / "WORKFLOW_RESULT.json")
        ranks = [read(output / "runtime-audit/continued" / f"rank{r}.json") for r in range(2)]
        if (terminal["status"] != "CHECKPOINTED" or wrapped["status"] != "TRAINING_CHECKPOINTED"
                or len({r["gpu_uuid"] for r in ranks}) != 2):
            raise ValueError("Downloaded continuation did not complete cleanly")
        for rank, r in enumerate(ranks):
            if (r["rank"] != rank or r["status"] != "PASS"
                    or [u["after"] for u in r["updates"]] != [plan["end"]]):
                raise ValueError("Downloaded weight did not receive an actual update")
        results[role] = dict(plan=plan, ranks=ranks, terminal=terminal, wrapper=wrapped)
    return dict(status="DOWNLOADED_OPTIMIZATION_READY", roles=results)


def resumeaudit(cfg, root):
    cpu_only()
    import torch
    from audit_workflow_checkpoint import inspect, load_verified
    from sam_audio.native_finetuning.training_support import check_entry
    from delivery_cohort import check
    torch.set_num_threads(1)
    done = read(root / "stages/resume/RESULT.json")
    if done["status"] != "DOWNLOADED_OPTIMIZATION_READY":
        raise ValueError("Actual downloaded optimization not complete")
    b = read(root / "bundle/bundle.json")
    catalog = read(root / "bundle" / b["train_catalog"])
    validation = read(root / "bundle" / b["validation_manifest"])
    reports = {}
    for role, record in done["roles"].items():
        plan = record["plan"]
        inputs_unchanged(plan["snapshot"])
        if sha(plan["checkpoint"]) != plan["original_report"]["file"]["sha256"]:
            raise ValueError("Original downloaded checkpoint changed")
        output = root / "continued" / role
        config = read(cfg["train_config"])
        supervision = check_entry(catalog, validation, config)
        identity = dict(plan_id=catalog["plan_id"], signature=catalog["signature"],
                        training_supervision=supervision)
        config.update(max_steps=plan["horizon"], num_epochs=2, batch_size=1, world_size=2,
                      gradient_accumulation_steps=1, effective_batch_size=2, compile=False,
                      save_every=1, training_probe_max_targets=0,
                      training_supervision=supervision,
                      validation_cohort=check(validation["items"], engineering_subset=False),
                      model_local_path=cfg["model"], output_dir=str(output),
                      resume_from=plan["checkpoint"])
        if plan["start"] == 9:
            config["resume_max_steps_from"] = 9
            config["resume_horizon_extension_applied"] = dict(
                policy="explicit-terminal-constant-warmup50-one-step-v1",
                previous_max_steps=9, requested_max_steps=10, checkpoint_global_step=9,
                epoch_capacity=14, checkpoint_path=plan["checkpoint"],
                original_config_sha256=plan["original_report"]["config_sha256"],
                data_identity_sha256=key(identity),
                reason="constant schedule and unchanged warmup are independent of max_steps",
                original_checkpoint_modified=False)
        end = plan["end"]
        path = output / f"step-{end}.pt"
        trusted = dict(size=path.stat().st_size, sha256=sha(path))
        state = load_verified(path, trusted)
        expected = dict(position=[end, end//7, end%7], verified_base=cfg["base_signature"],
                        data_identity=identity, config=config, scope="ENGINEERING_HF13_GT_NEW_WORKFLOW")
        report = inspect(state, expected)
        original = load_verified(plan["checkpoint"], plan["original_report"]["file"])
        changed = sum(not torch.equal(v, original["trainable_model"][n])
                      for n, v in state["trainable_model"].items())
        if not changed:
            raise ValueError("No saved model changed after downloaded optimization")
        reports[role] = dict(report, file=trusted, changed_model_tensors=changed)
        del state, original
    return dict(status="PASS_PRIVATE_ENGINEERING_ONE_COMMAND_WORKFLOW", roles=reports,
                validation_counts={"msdwild": 78, "easycom": 207},
                public_delivery="NOT_ACCEPTED_TOP_LEVEL_PUBLIC_RELEASE_PENDING",
                reused_environment=True, reused_validation=True,
                training_scope="ENGINEERING_HF13_GT",
                observed_training_frames=sorted({f["frames"] for stage in ("train2","train5","train8","train9")
                    for rank in read(root/"stages"/stage/"RESULT.json")["ranks"] for f in rank["forwards"]}),
                original_downloads_preserved=True, server_cleanup=False,
                limits=["UNC staged controller, not a standalone server installation",
                        "Training remains frozen HF13 engineering subset",
                        "No claim of full AVSpeech training or longer-example memory safety"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--stage", required=True, choices=[
        "download", "prepare", "encode", "export", "train2", "audit2",
        "train5", "audit5", "train8", "audit8", "train9", "audit9", "archive",
        "restorecheck", "resume", "resumeaudit"])
    args = parser.parse_args()
    cfg = selection(read(args.config))
    root = Path(cfg["workspace"]).resolve()
    directory = root / "stages" / args.stage
    directory.mkdir(parents=True, exist_ok=True)
    # Per-rank encoder processes own disjoint components; other stages are singleton.
    lockname = "rank-"+os.environ["LOCAL_RANK"] if args.stage == "encode" else "stage"
    with (directory / (lockname+".lock")).open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (directory / "RESULT.json").exists():
            raise ValueError("Completed stage must be verified by the controller, not rerun")
        started = time.monotonic()
        if args.stage.startswith("train"):
            receipt = training(cfg, root, args.stage)
        elif args.stage.startswith("audit"):
            receipt = audit_training(cfg, root, args.stage)
        elif args.stage == "archive":
            receipt = archive_results(cfg, root)
        else:
            receipt = globals()[args.stage](cfg, root)
        receipt.update(stage=args.stage, elapsed_seconds=time.monotonic()-started,
                       config_identity=key(cfg))
        if args.stage != "encode":
            path = root / "stages" / args.stage / "RESULT.json"
            if path.exists():
                raise ValueError("A stage result already exists; do not overwrite it")
            write(path, receipt)
        print(receipt["status"], flush=True)

if __name__ == "__main__":
    main()
