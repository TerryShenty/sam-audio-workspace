"""CPU-only translation of historical validation inputs into a portable export fragment.

Preserves original feature hashes, seeds, durations and query identities. Does not
copy tensors or certify runtime correctness. Merge files with the training export
plan and run export_bundle only after the separate full source audit passes.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
from data_manifest import sha


def build(rows, expected=None, verify_files=True):
    if not rows:
        raise ValueError('Empty validation cohort')
    counts = Counter(x['row']['dataset'] for x in rows)
    if expected is not None and dict(counts) != expected:
        raise ValueError('Validation cohort count mismatch')
    files, items, seen, media = [], [], set(), {}
    for x in rows:
        r = x['row']
        index = r['row_index']
        if type(index) is not int or index < 0 or index in seen:
            raise ValueError('Invalid or duplicate original row index')
        seen.add(index)
        if type(x.get('noise_seed')) is not int or not 0 <= x['noise_seed'] < 2**63:
            raise ValueError('Original noise seed required')
        frames = x['features']['latent_frames']
        if type(frames) is not int or frames not in (250, 500, 750):
            raise ValueError('Unsupported original duration')
        for key in ('clip_id', 'target_source_id', 'prompt'):
            if not isinstance(r.get(key), str) or not r[key].strip():
                raise ValueError('Missing validation identity: ' + key)
        source = Path(x['features']['path']).resolve()
        digest = x['features']['sha256']
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid original feature digest')
        if verify_files and (not source.is_file() or sha(source) != digest):
            raise ValueError('Original feature unavailable or changed at row ' + str(index))
        name = 'validation/features/' + str(index) + '.pt'
        files.append({'source': str(source), 'destination': name})
        item = {'index': index, 'dataset': r['dataset'], 'clip_id': r['clip_id'],
                'target_source_id': r['target_source_id'], 'prompt': r['prompt'],
                'category': r.get('category'), 'source_row_index': x.get('source_row_index'),
                'noise_seed': x['noise_seed'], 'latent_frames': frames,
                'features_file': name, 'features_sha256': digest}
        for old, new in [('gt_audio_path', 'gt_audio'), ('mixture_audio_path', 'mixture_audio')]:
            path = Path(r[old]).resolve()
            if verify_files and not path.is_file():
                raise ValueError('Missing validation audio at row ' + str(index))
            # Deduplicate shared files, keeping names independent of server paths.
            key = str(path)
            if key not in media:
                media[key] = 'validation/media/' + str(len(media)) + path.suffix
                files.append({'source': key, 'destination': media[key]})
            item[new] = media[key]
        items.append(item)
    return {'validation': {'stores': {}, 'items': items}, 'files': files,
            'audit': {'status': 'FILES_CHECKED_NOT_RUNTIME_VERIFIED' if verify_files else 'PLAN_ONLY',
                      'rows': len(items), 'datasets': dict(counts)}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputs', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    result = build(json.loads(Path(args.inputs).read_text()),
                   expected={'msdwild': 78, 'easycom': 207}, verify_files=not args.plan_only)
    out = Path(args.output)
    if out.exists():
        raise ValueError('Use a new output directory')
    out.mkdir(parents=True)
    manifest = out / 'validation.json'
    manifest.write_text(json.dumps(result['validation'], indent=2) + '\n')
    result['files'].append({'source': str(manifest.resolve()), 'destination': 'validation/manifest.json'})
    (out / 'files.json').write_text(json.dumps(result['files'], indent=2) + '\n')
    (out / 'AUDIT.json').write_text(json.dumps(result['audit'], indent=2) + '\n')


if __name__ == '__main__':
    main()
