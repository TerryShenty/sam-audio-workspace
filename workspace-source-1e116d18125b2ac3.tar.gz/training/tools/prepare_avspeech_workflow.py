"""Run pinned AVSpeech download, CPU audio and GT support preparation.

On a standalone server use --phase all (the default). Managed clusters can use
--phase download on the transfer host, then --phase prepare on a CPU allocation.
This does not create GPU features or GPU anchors, validation data or training.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

from prepare_selected_media import atomic_json, digest, selected_metadata
from prepare_training_spans import RULE


def selection(revision, ids, all_rows):
    if not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("Use an immutable 40-character HF commit, not main or a tag")
    if bool(ids) == bool(all_rows):
        raise ValueError("Choose exactly one of --ids and --all")
    if ids and (len(set(ids)) != len(ids) or
                any(not re.fullmatch(r"[A-Za-z0-9_-]+", x) for x in ids)):
        raise ValueError("Composite IDs must be unique and safe")
    return dict(repository="TerryShenty/avspeech-93942", revision=revision,
                ids=sorted(ids) if ids else None, all_rows=bool(all_rows))


def check_media(media, plan):
    release, videos, prompts, _, scope = selected_metadata(media)
    if release["repo"] != plan["repository"] or release["revision"] != plan["revision"]:
        raise ValueError("Downloaded release differs from the requested immutable version")
    if plan["ids"] is not None:
        if sorted(v["composite_id"] for v in videos) != plan["ids"]:
            raise ValueError("Downloaded selection differs from the requested videos")
    elif scope != "COMPLETE_SELECTED_RELEASE":
        raise ValueError("--all requires complete videos, targets and prompt counts")
    return release, videos, prompts, scope


def run_stage(command, log_path):
    with log_path.open("w") as stream:
        subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)


def workflow(directory, revision, ids=None, all_rows=False, phase="all",
             runner=run_stage, download_stop_after_receipts=None):
    if os.environ.get("SLURM_JOB_GPUS") or os.environ.get("SLURM_STEP_GPUS"):
        raise ValueError("Download, hashing and audio preparation require CPU resources")
    if phase not in ("all", "download", "prepare"):
        raise ValueError("Unknown preparation phase")
    plan = selection(revision, ids, all_rows)
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    tools = Path(__file__).resolve().parent
    media, prepared, support = root / "media", root / "prepared", root / "support"
    if any(p.is_symlink() for p in (media, prepared, support)):
        raise ValueError("Workflow outputs must be local directories, not shared symlinks")
    with (root / "WORKFLOW.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        plan_path = root / "WORKFLOW_PLAN.json"
        if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
            raise ValueError("Workspace belongs to another selection; use a new directory")
        # Refuse adoption of an unrelated download without binding a new plan.
        if not plan_path.exists() and (media / "RELEASE.json").exists():
            check_media(media, plan)
        atomic_json(plan_path, plan)
        attempt = root / "attempts" / uuid.uuid4().hex
        attempt.mkdir(parents=True)
        ready = root / "WORKFLOW_READY.json"
        if ready.exists():
            ready.replace(attempt / "PREVIOUS_WORKFLOW_READY.json")
        receipt = dict(status="RUNNING", phase=phase, plan=plan,
                       training_ready=False, gpu_cache="NOT_PREPARED",
                       gt_span="NOT_PREPARED", validation="NOT_MODIFIED",
                       attempt=str(attempt))
        atomic_json(root / "WORKFLOW_LAST_ATTEMPT.json", receipt)
        try:
            # Invalidate previous readiness before checking current inputs.
            if (media / "RELEASE.json").exists():
                check_media(media, plan)
            elif phase == "prepare":
                raise ValueError("Complete the download phase before CPU preparation")
            if phase in ("all", "download"):
                command = [sys.executable, str(tools / "download_selected_avspeech.py"),
                           "--repo", plan["repository"], "--revision", revision,
                           "--output", str(media)]
                command += ["--all"] if all_rows else ["--ids", *plan["ids"]]
                if download_stop_after_receipts is not None:
                    command += ["--stop-after-receipts", str(download_stop_after_receipts)]
                runner(command, attempt / "download.log")
            _, videos, prompts, scope = check_media(media, plan)
            receipt.update(videos=len(videos), prompts=len(prompts), scope=scope,
                           metadata={n: digest(media / n) for n in
                                     ("RELEASE.json", "videos.jsonl", "prompts.jsonl")})
            if phase in ("all", "prepare"):
                cpu_path = prepared / "CPU_READY.json"
                old_cpu_stat = cpu_path.stat() if cpu_path.exists() else None
                runner([sys.executable, str(tools / "prepare_selected_media.py"),
                        "--media", str(media), "--output", str(prepared)],
                       attempt / "prepare.log")
                if old_cpu_stat is not None and cpu_path.stat() == old_cpu_stat:
                    raise ValueError("Preparation returned without a fresh CPU receipt")
                cpu = json.loads(cpu_path.read_text())
                if (cpu["status"] != "PASS" or cpu["revision"] != revision or
                        cpu["videos"] != len(videos) or cpu["prompts"] != len(prompts) or
                        cpu["metadata"] != receipt["metadata"] or
                        cpu["rows_sha256"] != digest(prepared / "train_rows.json")):
                    raise ValueError("CPU receipt does not match the downloaded selection")
                cpu_sha = digest(cpu_path)
                gt_path = support / "GT_SUPPORT_READY.json"
                old_gt_stat = gt_path.stat() if gt_path.exists() else None
                runner([sys.executable, str(tools / "prepare_training_spans.py"),
                        "--media", str(media), "--prepared", str(prepared),
                        "--output", str(support)], attempt / "support.log")
                if old_gt_stat is not None and gt_path.stat() == old_gt_stat:
                    raise ValueError("GT preparation returned without a fresh support receipt")
                gt = json.loads(gt_path.read_text())
                identity = dict(rule=RULE, revision=revision, metadata=receipt["metadata"],
                                prepared_rows_sha256=cpu["rows_sha256"])
                targets = sum(len(v["targets"]) for v in videos)
                if (gt["status"] != "PASS_CPU_GT_SUPPORT" or gt["identity"] != identity or
                        gt["rule"] != RULE or gt["scope"] != scope or
                        gt["prompts"] != len(prompts) or gt["targets"] != targets or
                        gt["training_ready"] is not False or gt["gpu_anchors"] != "NOT_TESTED" or
                        gt["validation"] != "NOT_MODIFIED" or
                        gt["crop"] != "PRESERVED_RENDERED_VIDEO" or
                        set(gt["files"]) != {"train_rows.json", "targets.json"}):
                    raise ValueError("GT receipt does not match the prepared selection")
                if any(digest(support / n) != sha for n, sha in gt["files"].items()):
                    raise ValueError("GT support files changed after preparation")
                if (digest(cpu_path) != cpu_sha or
                        digest(prepared / "train_rows.json") != cpu["rows_sha256"] or
                        any(digest(media / n) != sha for n, sha in receipt["metadata"].items())):
                    raise ValueError("Inputs changed during GT preparation")
                receipt.update(status="CPU_MEDIA_AND_GT_READY", cpu_receipt=cpu,
                               cpu_receipt_sha256=cpu_sha, gt_receipt=gt,
                               gt_receipt_sha256=digest(gt_path),
                               gt_span="CPU_SUPPORT_VERIFIED_GPU_NOT_TESTED",
                               training_rows=str(support / "train_rows.json"))
                atomic_json(ready, receipt)
            else:
                receipt["status"] = "DOWNLOAD_COMPLETE_CPU_PREPARATION_REQUIRED"
            atomic_json(attempt / "RESULT.json", receipt)
            atomic_json(root / "WORKFLOW_LAST_ATTEMPT.json", receipt)
            return receipt
        except BaseException as exc:
            receipt.update(status="FAILED", error=str(exc))
            atomic_json(attempt / "RESULT.json", receipt)
            atomic_json(root / "WORKFLOW_LAST_ATTEMPT.json", receipt)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True)
    parser.add_argument("--revision", required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--ids", nargs="+")
    group.add_argument("--all", action="store_true")
    parser.add_argument("--phase", choices=["all", "download", "prepare"], default="all")
    args = parser.parse_args()
    print(json.dumps(workflow(args.directory, args.revision, args.ids, args.all,
                             args.phase), indent=2))


if __name__ == "__main__":
    main()
