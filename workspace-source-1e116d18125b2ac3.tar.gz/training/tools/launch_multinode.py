"""One bounded, non-retrying torchrun agent per explicitly selected server.

This does not allocate cloud resources. A controller must provision distinct
machines, verify/stage inputs and enforce the paid-resource lifetime separately.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
from launch_distributed import bounded_run


def command_and_environment(args, environment):
    if not 2 <= args.nodes <= 16 or not 1 <= args.gpus_per_node <= 8:
        raise ValueError("Experimental fixed topology requires 2–16 nodes, 1–8 GPUs per node")
    if not 0 <= args.node_rank < args.nodes or not 1 <= args.master_port <= 65535:
        raise ValueError("Invalid node rank or rendezvous port")
    if not args.master_address or args.master_address in ("localhost", "127.0.0.1", "::1"):
        raise ValueError("A peer-reachable private master address is required")
    if not 1 <= args.timeout <= 1800:
        raise ValueError("Explicit process bound must be at most 1800 seconds")
    if any(k in environment for k in ("RANK", "LOCAL_RANK", "WORLD_SIZE")):
        raise ValueError("Do not nest this controller inside torchrun")
    machines = args.machine_ids
    if (len(machines) != args.nodes or len(set(machines)) != args.nodes
            or not all(isinstance(v, str) and v for v in machines)):
        raise ValueError("One distinct provider machine ID is required per node")
    if args.machine_id != machines[args.node_rank]:
        raise ValueError("Provider machine ID does not match node assignment")
    identity = args.cpu_input_identity
    if len(identity) != 64 or any(c not in "0123456789abcdef" for c in identity):
        raise ValueError("Expected CPU input receipt SHA256")
    env = dict(environment, SAM_PROVIDER_MACHINE_ID=args.machine_id,
               SAM_EXPECTED_MACHINE_IDS=json.dumps(machines),
               SAM_CPU_INPUT_IDENTITY=identity,
               HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
               TORCH_NCCL_ASYNC_ERROR_HANDLING="1")
    command = [sys.executable, "-m", "torch.distributed.run",
               f"--nnodes={args.nodes}", f"--node_rank={args.node_rank}",
               f"--nproc_per_node={args.gpus_per_node}",
               "--max-restarts=0", "--rdzv_backend=static",
               "--rdzv_conf=timeout=120",
               f"--master_addr={args.master_address}",
               f"--master_port={args.master_port}"]
    if args.phase == "probe":
        if args.training_args:
            raise ValueError("Probe does not accept a training command")
        env.update(SAM_MULTINODE_PROBE="1", SAM_PROBE_OUTPUT=str(args.output / "probe"))
        command += [str(Path(__file__).with_name("distributed_probe.py"))]
    else:
        training = list(args.training_args)
        if training and training[0] == "--":
            training = training[1:]
        if not training or Path(training[0]).name != "train_delivery.py":
            raise ValueError("The bounded trainer must be train_delivery.py")
        if "--multi-node" not in training:
            raise ValueError("Trainer must explicitly select multi-node mode")
        command += training
    return command, env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nodes", type=int, required=True)
    parser.add_argument("--gpus-per-node", type=int, required=True)
    parser.add_argument("--node-rank", type=int, required=True)
    parser.add_argument("--machine-id", required=True)
    parser.add_argument("--machine-ids", type=json.loads, required=True)
    parser.add_argument("--master-address", required=True)
    parser.add_argument("--master-port", type=int, required=True)
    parser.add_argument("--cpu-input-identity", required=True)
    parser.add_argument("--timeout", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=("probe", "train"), required=True)
    parser.add_argument("training_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    args.output = args.output.resolve()
    command, env = command_and_environment(args, os.environ)
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "LOCK").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        intent = dict(command=command, timeout=args.timeout, node_rank=args.node_rank,
                      machine_ids=args.machine_ids, input_identity=args.cpu_input_identity,
                      phase=args.phase, automatic_restarts=0)
        # An existing intent is never cleared/retried automatically, even if its
        # result is missing. The external controller must reconcile the workers.
        with (args.output / "INTENT.json").open("x") as handle:
            json.dump(intent, handle, indent=2)
        def stop(signum, frame):
            raise InterruptedError(f"Signal {signum}")
        previous = signal.signal(signal.SIGTERM, stop)
        result = dict(status="FAILED", phase=args.phase, node_rank=args.node_rank,
                      intent_sha256=hashlib.sha256((args.output / "INTENT.json").read_bytes()).hexdigest())
        try:
            result.update(bounded_run(command, env, args.output / "process.log", args.timeout))
            result["status"] = "PROCESS_EXITED_REQUIRES_RANK_AUDIT" if result["exit_code"] == 0 else "FAILED"
        except BaseException as exc:
            result["error_type"] = type(exc).__name__
            raise
        finally:
            signal.signal(signal.SIGTERM, previous)
            result["paid_resource_shutdown"] = "EXTERNAL_CONTROLLER_REQUIRED"
            (args.output / "PROCESS_RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
        raise SystemExit(result["exit_code"])


if __name__ == "__main__":
    main()
