#!/usr/bin/env bash
# Source before starting Python: its dynamic loader reads LD_LIBRARY_PATH at launch.
# A shared FFmpeg installation is needed; a static ffmpeg executable is insufficient.
if [[ -z "${SAM_FFMPEG_PREFIX:-}" && -f "$PWD/.runtime/RUNTIME_READY.json" ]]; then
  export SAM_FFMPEG_PREFIX="$PWD/.runtime/ffmpeg"
fi
if [[ -n "${SAM_FFMPEG_PREFIX:-}" ]]; then
  if [[ ! -d "$SAM_FFMPEG_PREFIX/lib" ]]; then
    printf '%s\n' 'SAM_FFMPEG_PREFIX must name an FFmpeg installation containing lib/.' >&2
    return 1
  fi
  if ! compgen -G "$SAM_FFMPEG_PREFIX/lib/libavdevice.so*" >/dev/null; then
    printf '%s\n' 'The chosen FFmpeg installation has no shared libavdevice. Install shared FFmpeg libraries before running setup.' >&2
    return 1
  fi
  export LD_LIBRARY_PATH="$SAM_FFMPEG_PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
  if [[ -x "$SAM_FFMPEG_PREFIX/bin/ffmpeg" ]]; then
    export PATH="$SAM_FFMPEG_PREFIX/bin:$PATH"
  fi
fi
