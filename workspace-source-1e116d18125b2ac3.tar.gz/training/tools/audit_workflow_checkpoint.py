"""CPU inspection of this delivery's AdamW/EMA checkpoint format, no execution."""
from collections import Counter
import hashlib
import math
from pathlib import Path
import random


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inspect(state, expected):
    import torch
    step, epoch, update = expected["position"]
    require(state["format"] == "sam_audio_native_referring_v1"
            and state["optimized_recipe"] == 1, "Checkpoint format")
    require([state[k] for k in ("global_step", "epoch", "next_update")]
            == [step, epoch, update], "Saved data position")
    require(state["world_size"] == 2, "World size")
    require(state["verified_base"] == expected["verified_base"], "Base identity")
    require(state["data_identity"] == expected["data_identity"], "Data/supervision identity")
    config = state["config"]
    for key, value in expected["config"].items():
        require(config.get(key) == value, "Configuration: " + key)
    require(0 < step <= config["max_steps"] and 0 <= epoch <= config["num_epochs"],
            "Step/epoch bounds")
    require(state["referring_aux"] is None, "This audit is for the no-auxiliary recipe")
    model = state["trainable_model"]
    optimizer, scheduler, ema = (state[k] for k in ("optimizer", "scheduler", "ema"))
    require(isinstance(model, dict) and bool(model), "Empty model")
    require(isinstance(optimizer, dict) and bool(optimizer["state"]), "Empty optimizer")
    require(scheduler["last_epoch"] == step and scheduler["_step_count"] == step + 1,
            "Scheduler position")
    require(ema["updates"] == step and ema["decay"] == config["ema_decay"], "EMA position")
    groups = optimizer["param_groups"]
    ids = [pid for group in groups for pid in group["params"]]
    require(len(ids) == len(set(ids)) == len(model)
            and set(ids) == set(optimizer["state"]), "Optimizer parameter coverage")
    require(len(scheduler["_last_lr"]) == len(groups) == len(scheduler["base_lrs"]),
            "Scheduler group coverage")
    for i, group in enumerate(groups):
        require(math.isclose(group["lr"], scheduler["_last_lr"][i], rel_tol=1e-12)
                and math.isclose(group["initial_lr"], scheduler["base_lrs"][i], rel_tol=1e-12),
                "Scheduler learning rates")
    require(set(ema["shadow"]) == {"sam_audio." + name for name in model},
            "EMA parameter coverage")
    rng = state["rng_by_rank"]
    require(isinstance(rng, list) and len(rng) == 2, "Per-rank RNG coverage")
    for record in rng:
        random.Random().setstate(record["python"])
        generator = torch.Generator(device="cpu")
        generator.set_state(record["torch"])
        cuda = record["cuda"]
        require(torch.is_tensor(cuda) and cuda.device.type == "cpu"
                and cuda.dtype == torch.uint8 and cuda.ndim == 1 and cuda.numel() > 0,
                "Stored CUDA RNG record")

    def finite_tensor(value, label):
        require(torch.is_tensor(value) and value.device.type == "cpu"
                and value.is_floating_point() and bool(torch.isfinite(value).all()),
                "Nonfinite or invalid tensor: " + label)

    model_shapes = Counter()
    trainable_elements = 0
    for name, value in model.items():
        finite_tensor(value, name)
        model_shapes[tuple(value.shape)] += 1
        trainable_elements += value.numel()
        shadow = ema["shadow"]["sam_audio." + name]
        finite_tensor(shadow, "EMA:" + name)
        require(shadow.shape == value.shape and shadow.dtype == torch.float32,
                "EMA shape/dtype")
    moment_shapes = Counter()
    for pid, record in optimizer["state"].items():
        counter = record["step"]
        require(torch.is_tensor(counter) and counter.numel() == 1
                and bool(torch.isfinite(counter)) and float(counter) == step,
                "Optimizer step")
        avg, square = record["exp_avg"], record["exp_avg_sq"]
        finite_tensor(avg, "Adam first moment")
        finite_tensor(square, "Adam second moment")
        require(avg.shape == square.shape and bool((square >= 0).all()),
                "Optimizer moment shape/sign")
        moment_shapes[tuple(avg.shape)] += 1
    require(moment_shapes == model_shapes, "Optimizer/model shape multiset")
    return dict(status="PASS_CPU_CHECKPOINT_STATE", step=step, epoch=epoch,
                next_update=update, world_size=2, model_tensors=len(model),
                trainable_elements=trainable_elements, optimizer_tensors=len(ids),
                ema_tensors=len(ema["shadow"]), scheduler_step=scheduler["last_epoch"],
                rng_ranks=len(rng), scope=expected["scope"],
                limits=["Structure/finite/coverage checks, not CUDA RNG replay",
                        "Optimizer tensor shape multiset, not model-to-ID name association",
                        "Does not establish effective resumed GPU optimization"])


def load_verified(path, record):
    import torch
    path = Path(path)
    require(path.stat().st_size == record["size"] and sha(path) == record["sha256"],
            "Trusted checkpoint bytes differ")
    # This format uses only tensors and builtin values; never enable arbitrary
    # unpickling to work around an unknown checkpoint type.
    return torch.load(path, map_location="cpu", weights_only=True)
