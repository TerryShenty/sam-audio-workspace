"""Explicit single-node GPU plans. No hardware probe or Torch import on import."""
import math
import os


def profile(gpus=2, global_batch=None):
    if type(gpus) is not int or not 1 <= gpus <= 8:
        raise ValueError("Choose 1–8 GPUs on one node; larger hosts may expose a subset")
    batch = max(2, gpus) if global_batch is None else global_batch
    if type(batch) is not int or batch < gpus or batch % gpus:
        raise ValueError("Global batch must be a positive multiple of the selected GPUs")
    # The bounded selection contains 13 prompt rows; microbatch remains one.
    # Match LengthBucketPlan's rank padding and final partial accumulation.
    accumulation = batch // gpus
    updates = math.ceil(math.ceil(13 / gpus) / accumulation)
    return dict(gpus=gpus, microbatch=1, global_batch=batch,
                accumulation=accumulation, updates_per_epoch=updates,
                epochs=math.ceil(9 / updates), max_steps=9,
                training_encoder_gpus=min(gpus, 3), validation_encoder_gpus=gpus,
                training_gpus=gpus, nodes=1,
                hardware_acceptance="TWO_A100_REFERENCE_ONLY_OTHER_COUNTS_NOT_GPU_TESTED")


def check_inventory(devices, required, environment=None):
    """Respect CUDA visibility and reject unsupported setup before worker launch.

    22 GiB reported capacity allows nominal 24 GB cards with driver reservations.
    This is a conservative entry policy for the tested 10/20s BF16 profile,
    not a guarantee against OOM or an assertion about longer inputs.
    """
    env = os.environ if environment is None else environment
    if type(required) is not int or not 1 <= required <= 8:
        raise ValueError("Invalid requested GPU count")
    if int(env.get("SLURM_JOB_NUM_NODES", "1")) != 1:
        raise ValueError("This entry supports one node; multi-node rendezvous is not implemented")
    if any(name in env for name in ("LOCAL_RANK", "RANK", "WORLD_SIZE")):
        raise ValueError("Run the entry once, not inside another torchrun process")
    if len(devices) < required:
        raise ValueError(f"Need {required} visible CUDA GPUs, found {len(devices)}; check CUDA_VISIBLE_DEVICES")
    if (env.get("SLURM_JOB_GPUS") or env.get("SLURM_STEP_GPUS")) and len(devices) != required:
        raise ValueError(f"This phase uses {required} GPUs; request exactly that many in its GPU allocation")
    selected = devices[:required]
    if len({d["uuid"] for d in selected}) != required:
        raise ValueError("Selected CUDA devices must have distinct UUIDs")
    if any(not d["bf16"] or d["memory_bytes"] < 22 * 1024**3 for d in selected):
        raise ValueError("This BF16 engineering profile requires BF16 support and at least 22 GiB reported capacity per GPU (nominal 24 GB class)")
    if any(str(d["uuid"]).startswith("MIG-") or "MIG" in d["name"] for d in selected):
        raise ValueError("MIG partitions are not accepted by this workflow")
    if len({(d["name"], tuple(d["capability"]), d["memory_bytes"]) for d in selected}) != 1:
        raise ValueError("Select a homogeneous GPU subset; mixed devices are not accepted")
    return dict(selected=selected, selected_count=required,
                visible_count=len(devices), unused_visible_count=len(devices)-required,
                memory_policy_gib=22, memory_policy_is_oom_guarantee=False)


def probe(required):
    import torch
    devices = []
    for index in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(index)
        # Query properties only; don't allocate a CUDA context on unused GPUs.
        bf16 = torch.version.cuda is not None and p.major >= 8
        devices.append(dict(logical_index=index, uuid=str(p.uuid), name=p.name,
                            memory_bytes=p.total_memory,
                            capability=[p.major, p.minor], bf16=bf16))
    return check_inventory(devices, required)


def receipts(reports, gpus):
    if (len(reports) != gpus or {r.get("rank") for r in reports} != set(range(gpus))
            or len({r.get("gpu_uuid") for r in reports}) != gpus
            or not all(r.get("gpu_uuid") for r in reports)):
        raise ValueError("Missing/duplicate rank or GPU receipt")
    for r in reports:
        if (r.get("world_size") != gpus or r.get("status") != "PASS"
                or not r.get("updates") or not r.get("forwards")
                or any(u["after"] != u["before"]+1 or not math.isfinite(u["delta"])
                       or u["delta"] <= 0 for u in r["updates"])
                or any(f.get("finite") is not True or f.get("positives") != 250
                       for f in r["forwards"])):
            raise ValueError("Every selected rank must perform real finite training")
    sequences = [[(u["before"], u["after"]) for u in r["updates"]] for r in reports]
    if any(v != sequences[0] for v in sequences[1:]):
        raise ValueError("Rank optimizer positions disagree")
