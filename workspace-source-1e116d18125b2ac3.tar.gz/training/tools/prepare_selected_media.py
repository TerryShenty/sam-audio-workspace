"""Prepare verified HF AVSpeech media on CPU, preserving every selected prompt.

Uses the existing lossless target/residual audio, without synthesis, normalization,
new splits or prompt rewriting. Interrupted attempts retain their staging files;
completed composites are reusable only after checking input and output hashes.
This prepares audio paths, not GPU caches or GT-span conditioning.
"""
import argparse
from collections import Counter, defaultdict
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import uuid


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def atomic_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def safe_path(root, name):
    root = Path(root).resolve()
    path = (root / name).resolve()
    if Path(name).is_absolute() or ".." in Path(name).parts or not path.is_relative_to(root):
        raise ValueError("Unsafe media path")
    return path


def selected_metadata(root):
    root = Path(root)
    release = json.loads((root / "RELEASE.json").read_text())
    if release["repo"] != "TerryShenty/avspeech-93942" or not re.fullmatch(
            r"[0-9a-f]{40}", release["revision"]):
        raise ValueError("Expected pinned selected AVSpeech release")
    videos = [json.loads(x) for x in (root / "videos.jsonl").read_text().splitlines()]
    prompts = [json.loads(x) for x in (root / "prompts.jsonl").read_text().splitlines()]
    ids = [v["composite_id"] for v in videos]
    if not ids or len(set(ids)) != len(ids) or release["videos"] != len(ids):
        raise ValueError("Incomplete or duplicate selected videos")
    if any(not re.fullmatch(r"[A-Za-z0-9_-]+", cid) for cid in ids):
        raise ValueError("Unsafe composite ID")
    known_ids = set(ids)
    by_target = defaultdict(list)
    for row in prompts:
        if row["composite_id"] not in known_ids or not row.get("prompt", "").strip():
            raise ValueError("Unknown video or empty prompt")
        if type(row["slot"]) is not int or row["slot"] < 0:
            raise ValueError("Invalid prompt target slot")
        by_target[row["composite_id"], row["slot"]].append(row)
    prompt_ids = [p["prompt_id"] for p in prompts]
    if not prompts or len(set(prompt_ids)) != len(prompt_ids):
        raise ValueError("Duplicate or missing prompt IDs")
    expected_targets = set()
    for video in videos:
        if video["sample_rate"] != 48000 or type(video["samples"]) is not int or video["samples"] <= 0:
            raise ValueError("Unexpected sample rate or duration")
        slots = [x["slot"] for x in video["targets"]]
        if not slots or len(set(slots)) != len(slots) or any(type(s) is not int or s < 0 for s in slots):
            raise ValueError("Invalid target slots")
        for target in video["targets"]:
            key = video["composite_id"], target["slot"]
            expected_targets.add(key)
            rows = by_target[key]
            if not rows or len(rows) != target["prompt_count"]:
                raise ValueError("Every GT target must retain all selected prompts")
            for row in rows:
                for field in ("source_id", "window_id"):
                    if row[field] != target[field]:
                        raise ValueError("Prompt target identity changed")
                if row["recipe_sha256"] != video["recipe_sha256"]:
                    raise ValueError("Prompt recipe changed")
    if set(by_target) != expected_targets:
        raise ValueError("Prompt references unknown target")
    scope = "COMPLETE_SELECTED_RELEASE" if (
        len(videos) == release["status"].get("expected_videos")
        and len(prompts) == release["status"].get("prompts_available")
        and len(expected_targets) == release["status"].get("expected_targets")
    ) else "ENGINEERING_SUBSET"
    return release, videos, prompts, by_target, scope


def receipt_index(root):
    """Scan receipt metadata once, rather than once per selected video."""
    found = {}
    for receipt_path in sorted((Path(root) / "receipts").glob("*.json")):
        receipt = json.loads(receipt_path.read_text())
        identity = receipt["identity"]
        if not re.fullmatch(r"[0-9a-f]{40}", identity["commit"]):
            raise ValueError("Mutable download receipt")
        for row in receipt["files"]:
            name = row["path"]
            spec = {"bytes": row["bytes"], "sha256": row["sha256"]}
            if name in found and found[name] != spec:
                raise ValueError("Conflicting media receipts")
            found[name] = spec
    return found


def verified_files(root, video, index):
    """Require downloader receipts for every input and recheck their content."""
    root = Path(root).resolve()
    cid = video["composite_id"]
    required = {f"data/{cid}/{name}" for name in ("video.mp4", "mixture.wav", "recipe.json")}
    for target in video["targets"]:
        required.update(f"data/{cid}/{kind}_{target['slot']}.wv" for kind in ("target", "residual"))
    if not required <= index.keys():
        raise ValueError("Downloaded media has incomplete verification receipts")
    found = {name: index[name] for name in sorted(required)}
    for name, spec in found.items():
        path = safe_path(root, name)
        if path.stat().st_size != spec["bytes"] or digest(path) != spec["sha256"]:
            raise ValueError("Downloaded media no longer matches receipt")
    return found


def check_recipe(recipe, video):
    if recipe["composite_id"] != video["composite_id"] or recipe["mode"] != video["mode"]:
        raise ValueError("Recipe layout identity mismatch")
    for target in video["targets"]:
        source = recipe["inputs"][target["slot"]]
        if any(source[k] != target[k] for k in ("source_id", "window_id")):
            raise ValueError("Recipe target identity mismatch")


def decode_composite(root, stage, video):
    import numpy as np
    import soundfile as sf
    cid = video["composite_id"]
    source = root / "data" / cid
    mix, sr = sf.read(source / "mixture.wav", dtype="float32", always_2d=True)
    expected_shape = (video["samples"], 1)
    if sr != 48000 or mix.shape != expected_shape or not np.isfinite(mix).all():
        raise ValueError("Invalid mixture samples")
    probe = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-of", "json", str(source / "video.mp4")],
        timeout=60))
    stream = next(s for s in probe["streams"] if s["codec_type"] == "video")
    if abs(float(stream["duration"]) - len(mix) / sr) >= .15:
        raise ValueError("Video duration disagrees with mixture")
    audit = []
    for target in video["targets"]:
        slot = target["slot"]
        waves = {}
        for kind in ("target", "residual"):
            name = f"{kind}_{slot}.wav"
            subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-threads", "1",
                            "-i", str(source / f"{kind}_{slot}.wv"),
                            "-c:a", "pcm_f32le", str(stage / name)], check=True, timeout=120)
            wave, rate = sf.read(stage / name, dtype="float32", always_2d=True)
            if rate != sr or wave.shape != expected_shape or not np.isfinite(wave).all():
                raise ValueError("Decoded GT has invalid shape, duration or values")
            waves[kind] = wave
        error = float(np.max(np.abs(waves["target"] + waves["residual"] - mix)))
        if error > 2e-6:
            raise ValueError("Target plus residual differs from original mixture")
        audit.append(dict(slot=slot, reconstruction_max_abs=error))
    return audit


def prepare(root, output, decoder=decode_composite):
    if os.environ.get("SLURM_JOB_GPUS") or os.environ.get("SLURM_STEP_GPUS"):
        raise ValueError("Run media decoding and hashing on CPU before requesting GPUs")
    root, output = Path(root).resolve(), Path(output).resolve()
    if root == output or root.is_relative_to(output):
        raise ValueError("Preparation output must not contain the media input")
    release, videos, prompts, by_target, scope = selected_metadata(root)
    metadata = {name: digest(root / name) for name in ("RELEASE.json", "videos.jsonl", "prompts.jsonl")}
    output.mkdir(parents=True, exist_ok=True)
    with (output / "PREPARATION.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        identity = dict(version=1, source_root=str(root), metadata=metadata)
        identity_path = output / "PREPARATION_IDENTITY.json"
        if identity_path.exists() and json.loads(identity_path.read_text()) != identity:
            raise ValueError("Output belongs to different inputs; preserve it and use a new output")
        atomic_json(identity_path, identity)
        attempt_id = uuid.uuid4().hex
        # Retain previous ready evidence if verification fails on this invocation.
        prior = output / "CPU_READY.json"
        if prior.exists():
            history = output / "history"
            history.mkdir(exist_ok=True)
            prior.replace(history / f"CPU_READY-before-{attempt_id}.json")
        counts = Counter()
        new = reused = 0
        rows = []
        try:
            index = receipt_index(root)
            for video in videos:
                cid = video["composite_id"]
                inputs = verified_files(root, video, index)
                check_recipe(json.loads((root / "data" / cid / "recipe.json").read_text()), video)
                key = hashlib.sha256(canonical(dict(metadata=metadata, video=video, files=inputs)).encode()).hexdigest()
                dest = output / cid
                if dest.exists():
                    receipt = json.loads((dest / "COMPOSITE_READY.json").read_text())
                    expected_outputs = {f"{k}_{t['slot']}.wav"
                                        for t in video["targets"] for k in ("target", "residual")}
                    if receipt["input_key"] != key or receipt["outputs"].keys() != expected_outputs:
                        raise ValueError("Completed composite belongs to different input")
                    for name, spec in receipt["outputs"].items():
                        path = safe_path(dest, name)
                        if path.stat().st_size != spec["bytes"] or digest(path) != spec["sha256"]:
                            raise ValueError("Prepared audio changed; preserve it for diagnosis")
                    reused += 1
                else:
                    stage = output / f".staging-{cid}-{attempt_id}"
                    stage.mkdir()
                    audit = decoder(root, stage, video)
                    if verified_files(root, video, index) != inputs:
                        raise ValueError("Media changed during decoding")
                    names = [f"{kind}_{t['slot']}.wav" for t in video["targets"] for kind in ("target", "residual")]
                    receipt = dict(input_key=key, targets=audit, inputs=inputs,
                                   outputs={n: dict(bytes=(stage / n).stat().st_size,
                                                    sha256=digest(stage / n)) for n in names})
                    atomic_json(stage / "COMPOSITE_READY.json", receipt)
                    stage.rename(dest)
                    new += 1
                for target in video["targets"]:
                    slot = target["slot"]
                    for row in by_target[cid, slot]:
                        rows.append(dict(row, video_path=str(root / "data" / cid / "video.mp4"),
                                         mixture_audio_path=str(root / "data" / cid / "mixture.wav"),
                                         gt_audio_path=str(dest / f"target_{slot}.wav"),
                                         residual_audio_path=str(dest / f"residual_{slot}.wav"),
                                         samples=video["samples"], sample_rate=48000))
                        counts[row["category"] + "/" + row["subtype"]] += 1
                print(json.dumps(dict(composite_id=cid, new_composites=new, reused_composites=reused)), flush=True)
            if any(digest(root / name) != checksum for name, checksum in metadata.items()):
                raise ValueError("Source metadata changed during preparation")
            atomic_json(output / "train_rows.json", rows)
            result = dict(status="PASS", scope=scope, revision=release["revision"],
                          videos=len(videos), targets=len(by_target), prompts=len(rows),
                          category_subtype_counts=dict(sorted(counts.items())),
                          new_composites=new, reused_composites=reused,
                          metadata=metadata, rows_sha256=digest(output / "train_rows.json"),
                          gpu_cache="NOT_PREPARED", training_gt_anchors="NOT_PREPARED",
                          prompt_rewriting=False, resynthesis=False, validation_split_created=False)
            atomic_json(output / "CPU_READY.json", result)
            atomic_json(output / "LAST_ATTEMPT.json", dict(result, attempt=attempt_id))
            return result
        except Exception as error:
            atomic_json(output / "LAST_ATTEMPT.json",
                        dict(status="FAILED", attempt=attempt_id, error_type=type(error).__name__,
                             error=str(error), new_composites=new, reused_composites=reused))
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--media", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.media, args.output), indent=2))


if __name__ == "__main__":
    main()
