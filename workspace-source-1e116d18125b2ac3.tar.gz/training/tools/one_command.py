"""Private UNC integration controller with one journal and sequential allocations.

Run on Longleaf's login host. CPU/data movement never occupies a GPU allocation.
Unknown submission/transfer outcomes fail closed for reconciliation; no blind retry.
"""
import argparse
import fcntl
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

from workflow_contract import key, read, selection, sha, write

STAGES = ("download", "prepare", "encode", "export", "train2", "audit2", "train5",
          "audit5", "train8", "audit8", "train9", "audit9", "archive",
          "restorecheck", "resume", "resumeaudit")
TERMINAL = {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED"}
STATUS = dict(download="DOWNLOAD_READY", prepare="CPU_INPUT_READY", encode="ENCODED",
              export="BUNDLE_READY", archive="ARCHIVE_AND_RESTORE_READY",
              restorecheck="RESTORED_INPUTS_READY", resume="DOWNLOADED_OPTIMIZATION_READY",
              resumeaudit="PASS_PRIVATE_ENGINEERING_ONE_COMMAND_WORKFLOW")
STATUS.update({s: "TRAIN_STAGE_READY" for s in STAGES if s.startswith("train")})
STATUS.update({s: "TRAIN_CPU_AUDIT_READY" for s in STAGES if s.startswith("audit")})


def resource(stage):
    if stage in ("download", "archive"):
        return dict(kind="transfer", seconds=1800)
    if stage in ("train5", "train8", "train9"):
        return dict(kind="gpu", cpus=4, memory_gb=64, minutes=20, seconds=1050, gpus=2)
    if stage == "resume":
        return dict(kind="gpu", cpus=4, memory_gb=64, minutes=10, seconds=520, gpus=2)
    if stage in ("encode", "train2"):
        return dict(kind="gpu", cpus=4, memory_gb=64, minutes=5, seconds=240, gpus=2)
    # Full model/T5 identity hashing/imports are CPU-only and may take longer than
    # the 7-second media preparation. Prior T5 preflight measured 46.5 seconds.
    return dict(kind="cpu", cpus=2, memory_gb=8 if stage=="prepare" else 4,
                minutes=8 if stage=="prepare" else 5,
                seconds=420 if stage=="prepare" else 240, gpus=0)


def execute(argv):
    return subprocess.run(argv, check=True, text=True, capture_output=True).stdout.strip()


def verify_source(cfg):
    source = Path(cfg["source"])
    manifest = read(source / "SOURCE_MANIFEST.json")
    # The pinned manifest is part of config identity. No hidden source updates.
    if sha(source / "SOURCE_MANIFEST.json") != cfg["source_manifest_sha256"]:
        raise ValueError("Source manifest changed")
    for path, expected in manifest.items():
        if sha(source / path) != expected:
            raise ValueError("Source changed: " + path)
    if sha(cfg["train_config"]) != cfg["train_config_sha256"]:
        raise ValueError("Training config changed")
    if not Path(cfg["python"]).is_file():
        raise ValueError("Accepted persistent Python unavailable")


def environment(cfg, stage):
    source = cfg["source"]
    env = dict(PYTHONPATH=source+"/src", SAM_PYTHON=cfg["python"],
               SAM_FFMPEG_PREFIX=cfg["ffmpeg_prefix"], GPUS="2",
               OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
               PYTHONUNBUFFERED="1", PYTHONNOUSERSITE="1",
               HF_HUB_CACHE=cfg["hf_hub_cache"], HF_HUB_OFFLINE="1",
               TRANSFORMERS_OFFLINE="1", CUBLAS_WORKSPACE_CONFIG=":4096:8",
               NCCL_P2P_DISABLE="1", NCCL_DEBUG="WARN", WANDB_MODE="online",
               WANDB_ENTITY="terryshen066-fudan-university", WANDB_PROJECT="sam-audio",
               WANDB_INIT_TIMEOUT="45", WANDB_NAME="engineering-one-command-"+stage,
               XDG_CACHE_HOME=cfg["xdg_cache"])
    if stage == "download":
        env.update(HF_HUB_OFFLINE="0", TRANSFORMERS_OFFLINE="0")
    if resource(stage)["kind"] != "gpu":
        env["CUDA_VISIBLE_DEVICES"] = ""
    return env


def script(cfg, config_path, stage):
    spec = resource(stage)
    root = Path(cfg["workspace"])
    directory = root / "stages" / stage
    lines = ["#!/bin/bash"]
    if spec["kind"] != "transfer":
        lines += [f"#SBATCH --job-name=sam-one-{stage}",
                  f"#SBATCH --partition={'gpu_interactive' if spec['kind']=='gpu' else 'interact'}",
                  "#SBATCH --qos=normal", "#SBATCH --nodes=1", "#SBATCH --ntasks=1",
                  f"#SBATCH --cpus-per-task={spec['cpus']}", f"#SBATCH --mem={spec['memory_gb']}G",
                  f"#SBATCH --time=00:{spec['minutes']:02d}:00", "#SBATCH --no-requeue",
                  f"#SBATCH --output={directory}/job-%j.log"]
        if spec["kind"] == "gpu":
            lines += ["#SBATCH --gres=gpu:nvidia_a100-pcie-40gb:2"]
    lines += ["set -euo pipefail", "module purge", "module load python/3.12.2",
              "cd "+shlex.quote(cfg["source"]), "unset WANDB_RUN_ID"]
    for k, v in environment(cfg, stage).items():
        lines += ["export "+k+"="+shlex.quote(v)]
    lines += ["source "+shlex.quote(cfg["source"]+"/tools/media_env.sh")]
    if spec["kind"] == "gpu":
        lines += ["nvidia-smi --query-gpu=timestamp,uuid,name,utilization.gpu,memory.used,memory.total --format=csv -l 5 > "+shlex.quote(str(directory/"gpu.csv"))+" &",
                  "MONITOR=$!", "trap 'kill \"$MONITOR\" 2>/dev/null || true' EXIT"]
    args = [cfg["python"]]
    if stage == "encode":
        args += ["-m", "torch.distributed.run", "--standalone", "--max-restarts=0", "--nproc_per_node=2"]
    args += [cfg["source"]+"/tools/workflow_stages.py", "--config", str(config_path), "--stage", stage]
    lines += [shlex.join(["timeout", "--kill-after=10", str(spec["seconds"]), *args])]
    return "\n".join(lines)+"\n"


def accounting(job, runner=execute):
    raw = runner(["sacct", "-n", "-P", "-j", job,
                  "--format=JobIDRaw,State,ExitCode,ElapsedRaw,MaxRSS,AllocTRES"])
    rows = [line.split("|") for line in raw.splitlines() if line.strip()]
    if not rows or not any(r[0]==job for r in rows):
        return None
    if any(r[1].split()[0].rstrip('+') not in TERMINAL for r in rows):
        return None
    # Missing steps during accounting propagation cannot authorize the next job.
    if not any(r[0]==job+".batch" for r in rows) or not any(r[0]==job+".extern" for r in rows):
        return None
    return dict(rows=rows, success=all(r[1]=="COMPLETED" and r[2]=="0:0" for r in rows))


def verify_held(raw, cfg, stage, path):
    fields = dict(re.findall(r"(?:^|\s)(\w+)=(\S+)", raw))
    spec = resource(stage)
    exact = dict(JobState="PENDING", Reason="JobHeldUser", Requeue="0", Dependency="(null)",
                 NumNodes="1", NumTasks="1", NumCPUs=str(spec["cpus"]),
                 Command=str(path), WorkDir=cfg["source"],
                 TimeLimit=f"00:{spec['minutes']:02d}:00",
                 MinMemoryNode=str(spec["memory_gb"])+"G")
    for name, value in exact.items():
        if fields.get(name) != value:
            raise ValueError(f"Held request {name}: {fields.get(name)} != {value}")
    tres = fields.get("TresPerNode", "")
    if spec["kind"] == "gpu":
        if tres != "gres/gpu:nvidia_a100-pcie-40gb:2":
            raise ValueError("Held GPUs do not match two workers and finalizer")
    elif "gpu" in fields.get("ReqTRES", "") or "gpu" in tres:
        raise ValueError("CPU-only stage unexpectedly requests GPUs")
    return fields


def verify_stage(cfg, stage, journal):
    root = Path(cfg["workspace"])
    if stage == "encode":
        from workflow_contract import check_ranks
        plan = read(root / "encoder-input/cache_plan.json")
        reports = [read(root/f"encoded/rank{r}.json") for r in range(2)]
        identity = key(dict(plan=plan, revision=cfg["revision"], model=cfg["base_signature"]))
        check_ranks(reports, plan, 2, identity)
        paths = [root/f"encoded/rank{r}.json" for r in range(2)]
    else:
        paths = [root/"stages"/stage/"RESULT.json"]
        receipt = read(paths[0])
        if receipt["status"] != STATUS[stage] or receipt["config_identity"] != key(cfg):
            raise ValueError("Stale/incomplete stage receipt: "+stage)
    hashes = {str(p):sha(p) for p in paths}
    if journal.get("receipts") not in (None, hashes):
        raise ValueError("Completed stage evidence changed")
    return hashes


def run(config_path, through, runner=execute, sleeper=time.sleep):
    cfg = selection(read(config_path))
    cpu = os.environ.get("SLURM_JOB_ID") or os.environ.get("SLURM_JOB_GPUS")
    if cpu:
        raise ValueError("Controller must stay outside compute allocations")
    root = Path(cfg["workspace"])
    root.mkdir(parents=True, exist_ok=True)
    with (root/"CONTROLLER.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        verify_source(cfg)
        path = root/"JOURNAL.json"
        journal = read(path) if path.exists() else dict(config_identity=key(cfg), stages={})
        if journal["config_identity"] != key(cfg):
            raise ValueError("Controller configuration changed")
        if "predecessors" not in journal:
            predecessors = {}
            for job in cfg.get("completed_predecessor_jobs", []):
                result = accounting(job, runner)
                if result is None or not result["success"]:
                    raise ValueError("Predecessor/all steps not accepted: "+job)
                predecessors[job] = result
            journal["predecessors"] = predecessors
        write(path, journal)
        for stage in STAGES[:STAGES.index(through)+1]:
            verify_source(cfg)
            existing = journal["stages"].get(stage)
            if existing and existing["status"] == "ACCEPTED":
                verify_stage(cfg, stage, existing)
                continue
            directory = root/"stages"/stage
            directory.mkdir(parents=True, exist_ok=True)
            batch = directory/"stage.sh"
            body = script(cfg, config_path, stage)
            if batch.exists() and batch.read_text() != body:
                raise ValueError("Staged script changed")
            if not batch.exists():
                batch.write_text(body)
            spec = resource(stage)
            if existing is None:
                live = runner(["squeue", "-a", "-h", "-u", "tyshen", "-o", "%i|%j|%T|%R"])
                if any(any(prefix in row.split('|')[1] for prefix in cfg["queue_guard_prefixes"])
                       for row in live.splitlines() if '|' in row):
                    raise ValueError("Another handoff job is active; refusing a duplicate")
                existing = dict(status="TRANSFER_INTENT" if spec["kind"]=="transfer" else "SUBMISSION_INTENT",
                                source_manifest=cfg["source_manifest_sha256"], script_sha256=sha(batch),
                                spec=spec, before_queue=live)
                journal["stages"][stage] = existing
                write(path, journal)
                if spec["kind"] == "transfer":
                    # Synchronous SSH; on an unknown outcome, inspect receipts/processes.
                    # A subsequent call will refuse to repeat this persistent intent.
                    with (directory/"transfer.log").open("w") as log:
                        subprocess.run(["ssh", "-o", "BatchMode=yes", cfg["datamover"],
                                        shlex.join(["bash", str(batch)])], check=True,
                                       stdout=log, stderr=subprocess.STDOUT, timeout=spec["seconds"]+60)
                    existing["status"]="EXECUTED"
                    write(path, journal)
                else:
                    job = runner(["sbatch", "--hold", "--parsable", "--chdir", cfg["source"], str(batch)])
                    if not re.fullmatch(r"[0-9]+", job):
                        raise ValueError("Unknown sbatch result; reconcile, do not submit again")
                    existing.update(job_id=job, status="HELD")
                    write(path, journal)
            if existing.get("status") in ("SUBMISSION_INTENT", "TRANSFER_INTENT"):
                raise ValueError("Unknown prior side effect; reconcile journal before retry")
            if spec["kind"] != "transfer":
                job = existing["job_id"]
                if existing["status"] == "HELD":
                    held = runner(["scontrol", "show", "job", "-o", job])
                    existing["held_verification"] = verify_held(held, cfg, stage, batch)
                    if sha(batch) != existing["script_sha256"]:
                        raise ValueError("Batch changed while held")
                    verify_source(cfg)
                    existing["status"] = "RELEASE_INTENT"
                    write(path, journal)
                    runner(["scontrol", "release", job])
                    existing["status"] = "SUBMITTED"
                    write(path, journal)
                if existing["status"] == "RELEASE_INTENT":
                    live = runner(["scontrol", "show", "job", "-o", job])
                    if "Reason=JobHeldUser" in live:
                        raise ValueError("Release outcome unresolved; inspect held job, never submit a duplicate")
                # A crash after release cannot cause resubmission or a second release.
                while True:
                    result = accounting(job, runner)
                    if result is not None:
                        existing["accounting"] = result
                        existing["status"] = "EXECUTED" if result["success"] else "FAILED"
                        write(path, journal)
                        if not result["success"]:
                            raise ValueError("Stage failed; retain evidence and diagnose: "+stage)
                        break
                    sleeper(15)
            existing.update(receipts=verify_stage(cfg, stage, existing), status="ACCEPTED")
            write(path, journal)
            print("ACCEPTED", stage, existing.get("job_id", "DataMover"), flush=True)
        write(root/"CONTROLLER_RESULT.json", dict(status="PREFIX_ACCEPTED" if through!=STAGES[-1]
              else "PASS_PRIVATE_ENGINEERING_WORKFLOW", through=through, config_identity=key(cfg),
              public_delivery="NOT_ACCEPTED", public_validation_revision=cfg.get("public_validation_revision"),
              training_scope="ENGINEERING_HF13_GT", reused_validation=True, reused_environment=True))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", required=True, type=Path)
    p.add_argument("--through", choices=STAGES, default=STAGES[-1])
    args=p.parse_args()
    run(args.config.resolve(), args.through)


if __name__=="__main__":
    main()
