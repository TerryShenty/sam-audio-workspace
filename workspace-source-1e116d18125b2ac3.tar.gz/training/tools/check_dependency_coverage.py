"""Check direct dependency names before no-deps installation, not ABI compatibility."""
import re
import tomllib
from pathlib import Path


def name(requirement):
    match = re.match(r'^([A-Za-z0-9][A-Za-z0-9._-]*)', requirement.strip())
    if not match:
        raise ValueError(f'Unsupported requirement: {requirement!r}')
    return re.sub(r'[-_.]+', '-', match.group(1)).lower()


def check(declared, locked):
    available = {name(line) for line in locked.splitlines()
                 if line.strip() and not line.lstrip().startswith('#')}
    missing = sorted({name(item) for item in declared} - available)
    if missing:
        raise ValueError('Reference requirements omit declared dependencies: ' + ', '.join(missing))
    return len(declared)


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    project = tomllib.loads((root / 'pyproject.toml').read_text())
    count = check(project['project']['dependencies'], (root / 'requirements-reference.txt').read_text())
    print(f'Direct dependency name coverage passed ({count}); runtime compatibility not yet tested.')
