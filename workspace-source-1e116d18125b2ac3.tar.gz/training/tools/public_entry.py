"""Portable, explicit public-bundle entry; preparation stays off Slurm GPUs.

The bundle may be produced by the raw-media workflow or explicitly imported.
Importing an audited bundle does not claim a cold end-to-end media preparation.
No account names, cluster paths, allocation commands or credentials are embedded.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE / 'src'))
from workflow_contract import cpu_only, inputs_unchanged, key, read, sha, write
from delivery_cohort import check as check_cohort
from gpu_profile import profile, probe, receipts


def snapshot(path, checksum=None):
    path = Path(path).resolve()
    stat = path.stat()
    return dict(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns, inode=stat.st_ino,
                **({'sha256': checksum} if checksum else {}))


def public_bundle(bundle, validation, pin):
    if (bundle.get('status') != 'VERIFIED_EXPORT'
            or bundle.get('public_validation_revision') != pin.get('revision')
            or bundle.get('validation_features_provenance') != 'FRESH_ALL285_PUBLIC_MEDIA'):
        raise ValueError('A verified bundle of the pinned public validation features is required')
    cohort = check_cohort(validation['items'], engineering_subset=False)
    if cohort['cohort_sha256'] != pin['cohort_sha256'] or cohort['counts'] != pin['counts']:
        raise ValueError('Pinned complete validation cohort changed')
    provenance = validation.get('provenance', {})
    if (provenance.get('public_revision') != pin['revision']
            or provenance.get('fresh_features') is not True
            or provenance.get('conditioning') != 'nullGT'):
        raise ValueError('Missing fresh public feature provenance')
    for row in validation['items']:
        original = row.get('original_public_row', {})
        for name in ('index', 'dataset', 'prompt', 'noise_seed', 'latent_frames'):
            if original.get(name) != row[name]:
                raise ValueError('Public protocol field changed: '+name)
        if any(name in row for name in ('training_support', 'anchor_ids', 'anchor_alignment')):
            raise ValueError('Validation conditioning GT is forbidden')
    return cohort


def command(request, source=SOURCE):
    shape = profile(request["gpus"], request.get("global_batch"))
    args = ['bash', str(source / 'run.sh'), '--config', request['training_config'],
            '--data-root', request['data_root'], '--model', request['model'],
            '--output', str(Path(request['directory']) / 'train'), '--epochs', str(shape['epochs']),
            '--microbatch', '1', '--global-batch', str(shape['global_batch']), '--max-steps', '9',
            '--runtime-audit', 'public-entry-runtime']
    if request.get('resume'):
        args += ['--resume', request['resume']]
    if request.get('stop_after_step') is not None:
        args += ['--stop-after-step', str(request['stop_after_step'])]
    return args


def environment(request, inherited=None):
    env = dict(os.environ if inherited is None else inherited)
    # These are public identifiers/settings, never a token or credential value.
    env.update(SAM_PYTHON=request['python'], GPUS=str(request['gpus']), HF_HUB_CACHE=request['hf_hub_cache'],
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONNOUSERSITE='1',
               WANDB_ENTITY=request['wandb_entity'], WANDB_PROJECT=request['wandb_project'],
               WANDB_MODE='online', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               MKL_NUM_THREADS='1', PYTHONUNBUFFERED='1')
    env.pop('WANDB_RUN_ID', None)
    # The operator's explicit NCCL setting is preserved. The accepted launcher
    # handles absent settings and is the only communication fallback authority.
    return env


def validate_request(request):
    if request.get('profile') != 'engineering-public285':
        raise ValueError('Unknown engineering profile')
    profile(request.get('gpus'), request.get('global_batch'))
    if not request.get('wandb_entity') or not request.get('wandb_project'):
        raise ValueError('Supply your own W&B entity and project')
    if bool(request.get('resume')) != bool(request.get('resume_sha256')):
        raise ValueError('Explicit resume path and trusted SHA256 are both required')
    stop = request.get('stop_after_step')
    if stop is not None and (type(stop) is not int or not 1 <= stop <= 9):
        raise ValueError('Stop boundary must be within the fixed nine-step profile')
    for field in ('data_manifest_sha256', 'resume_sha256'):
        value = request.get(field)
        if value is not None and (len(value) != 64 or any(c not in '0123456789abcdef' for c in value)):
            raise ValueError('Invalid checksum: '+field)
    return request


def prepare(request):
    cpu_only()
    from data_manifest import path_in, verify
    from bundle_contract import validate_links
    from sam_audio.native_finetuning.training_support import check_entry
    validate_request(request)
    root = Path(request['directory'])
    ready = root / 'INPUT_READY.json'
    if ready.exists():
        history = root / 'history'; history.mkdir(exist_ok=True)
        ready.rename(history / f'INPUT_READY-{time.time_ns()}.json')
    source_manifest = read(SOURCE / 'SOURCE_MANIFEST.json')
    files = {}
    for name, expected in source_manifest.items():
        path = SOURCE / name
        if path.is_symlink() or sha(path) != expected:
            raise ValueError('Source changed: '+name)
        files[str(path)] = snapshot(path, expected)
    data = Path(request['data_root'])
    if sha(data / 'manifest.json') != request['data_manifest_sha256']:
        raise ValueError('Data manifest differs from requested immutable identity')
    manifest = read(data / 'manifest.json')
    verify(data, manifest)
    bundle = read(data / 'bundle.json')
    validate_links(data, bundle, [r['path'] for r in manifest['files']])
    validation = read(data / bundle['validation_manifest'])
    pin = read(SOURCE / 'configs/validation_release.json')
    cohort = public_bundle(bundle, validation, pin)
    cfg = read(request['training_config'])
    catalog = read(data / bundle['train_catalog'])
    if len(catalog["splits"]["train"]["entries"]) != 13:
        raise ValueError("The bounded GPU plan requires exactly 13 training rows")
    supervision = check_entry(catalog, validation, cfg)
    if supervision != bundle['training_supervision']:
        raise ValueError('GT supervision and bundle disagree')
    shape = profile(request['gpus'], request.get('global_batch'))
    if (cfg.get('max_steps') != 9 or cfg.get('num_epochs') != shape['epochs']
            or cfg.get('world_size') != shape['gpus']
            or cfg.get('effective_batch_size') != shape['global_batch']
            or cfg.get('gradient_accumulation_steps') != shape['accumulation']
            or cfg.get('training_scope') != 'ENGINEERING_HF13_GT'
            or cfg.get('engineering_validation_subset') is not False):
        raise ValueError('This entry is the fixed engineering training/full285 profile')
    for item in manifest['files']:
        path = path_in(data, item['path'])
        if (data / item['path']).is_symlink():
            raise ValueError('Symlink input is not accepted')
        files[str(path)] = snapshot(path, item['sha256'])
    for path in (data / 'manifest.json', Path(request['training_config'])):
        files[str(path)] = snapshot(path, sha(path))
    model_receipt = read(request['model_receipt'])
    if (model_receipt.get('status') != 'CPU_INPUT_READY'
            or model_receipt.get('explicit_hf_cache') != request['hf_hub_cache']):
        raise ValueError('Explicit CPU-verified model/cache receipt required')
    inputs_unchanged(model_receipt['model_files'])
    expected_model_paths = {str(Path(request['model']) / name) for name in ('checkpoint.pt', 'config.json')}
    if set(model_receipt['model_files']) != expected_model_paths:
        raise ValueError('CPU model receipt belongs to another model directory')
    files.update(model_receipt['model_files'])
    if request.get('resume'):
        checkpoint = Path(request['resume'])
        if checkpoint.is_symlink() or sha(checkpoint) != request['resume_sha256']:
            raise ValueError('Resume checkpoint differs from its trusted audit')
        files[str(checkpoint)] = snapshot(checkpoint, request['resume_sha256'])
    value = dict(status='PUBLIC_ENTRY_INPUT_READY', request_identity=key(request),
                 source_manifest_sha256=sha(SOURCE / 'SOURCE_MANIFEST.json'),
                 data_manifest_sha256=request['data_manifest_sha256'], inputs=files,
                 public_revision=pin['revision'], cohort=cohort, supervision=supervision,
                 preparation_mode='EXPLICIT_VERIFIED_BUNDLE_AND_MODEL_RECEIPT_REUSE',
                 cold_download=False, fresh_environment=False, training_executed=False,
                 validation_feature_provenance=bundle['validation_features_provenance'])
    write(ready, value)
    return value


def train(request, runner=subprocess.run):
    root = Path(request['directory'])
    ready = read(root / 'INPUT_READY.json')
    if ready.get('status') != 'PUBLIC_ENTRY_INPUT_READY' or ready['request_identity'] != key(request):
        raise ValueError('Missing or stale CPU input receipt')
    if sha(SOURCE / 'SOURCE_MANIFEST.json') != ready['source_manifest_sha256']:
        raise ValueError('Prepared source identity changed')
    inputs_unchanged(ready['inputs'])
    intent = root / 'TRAIN_INTENT.json'
    if intent.exists():
        raise ValueError('Training intent already exists; reconcile the previous process/result')
    write(root / 'GPU_CHECK.json', probe(request['gpus']))
    args = command(request)
    write(intent, dict(status='STARTED', request_identity=key(request), argv=args,
                       input_receipt_sha256=sha(root / 'INPUT_READY.json')))
    started = time.monotonic()
    runner(args, env=environment(request), check=True)
    result = read(root / 'train/RESULT.json')
    wrapper = read(root / 'train/WORKFLOW_RESULT.json')
    expected = 'CHECKPOINTED' if request.get('stop_after_step') is not None else 'COMPLETE'
    if result.get('status') != expected:
        raise ValueError('Training did not reach the requested boundary')
    ranks = [read(root / f'train/public-entry-runtime/rank{r}.json') for r in range(request['gpus'])]
    receipts(ranks, request['gpus'])
    value = dict(status='PUBLIC_ENTRY_TRAINING_FINISHED', terminal=result, wrapper=wrapper,
                 request_identity=key(request), public_revision=ready['public_revision'],
                 data_manifest_sha256=ready['data_manifest_sha256'], seconds=time.monotonic()-started,
                 ranks=ranks, cold_start=False, scope='ENGINEERING_GT13_PUBLIC285_BUNDLE_CONSUMPTION')
    write(root / 'ENTRY_RESULT.json', value)
    return value


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase', choices=['prepare', 'train', 'finalize'], required=True)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--data-root', type=Path)
    p.add_argument('--data-manifest-sha256')
    p.add_argument('--model', type=Path)
    p.add_argument('--model-receipt', type=Path)
    p.add_argument('--hf-hub-cache', type=Path)
    p.add_argument('--wandb-entity')
    p.add_argument('--wandb-project', default='sam-audio')
    p.add_argument('--training-config', type=Path, default=SOURCE/'configs/engineering-public.json')
    p.add_argument('--resume', type=Path)
    p.add_argument('--resume-sha256')
    p.add_argument('--stop-after-step', type=int)
    p.add_argument('--gpus', type=int, default=2)
    p.add_argument('--global-batch', type=int)
    args = p.parse_args(); root = args.directory.resolve(); root.mkdir(parents=True, exist_ok=True)
    with (root / 'PUBLIC_ENTRY.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        request_path = root / 'REQUEST.json'
        if args.phase == 'prepare':
            required = ['data_root', 'data_manifest_sha256', 'model', 'model_receipt', 'hf_hub_cache', 'wandb_entity']
            if any(getattr(args, name) is None for name in required):
                p.error('prepare requires data root/hash, model/CPU receipt/cache, and your W&B entity')
            request = dict(profile='engineering-public285', python=sys.executable,
                           **{k:(str(v.resolve()) if isinstance(v, Path) else v) for k,v in vars(args).items() if k!='phase'})
            validate_request(request)
            if request_path.exists() and read(request_path) != request:
                raise ValueError('Workspace belongs to another request; choose a new directory')
            if (root / 'TRAIN_INTENT.json').exists():
                raise ValueError('Training started; preparation cannot rewrite its receipt')
            write(request_path, request)
            result = prepare(request)
        else:
            request = validate_request(read(request_path))
            if args.phase == 'train':
                result = train(request)
            else:
                cpu_only()
                if read(root/'ENTRY_RESULT.json')['terminal']['status'] != 'COMPLETE':
                    raise ValueError('Only a newly completed run can be finalized')
                from finalize_run import finalize
                result = finalize(root/'train', environment(request))
                write(root/'ENTRY_FINALIZATION.json', result)
        print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','ranks')}, indent=2))


if __name__ == '__main__':
    main()
