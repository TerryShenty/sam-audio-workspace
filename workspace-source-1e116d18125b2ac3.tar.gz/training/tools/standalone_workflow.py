"""Public engineering workflow: raw inputs -> new caches -> training -> archival.

On an ordinary Linux GPU server the default command runs the stages in order.
On a cluster, run preparation/export/finalization on CPU or transfer facilities
and use --only for GPU stages. No scheduler, host path or user account is assumed.
An interrupted compute/upload intent requires reconciliation, never blind retry.
"""
import argparse
import copy
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE / "src"))
from workflow_contract import read, write, sha, key, cpu_only, inputs_unchanged, check_ranks
from gpu_profile import profile, probe

STAGES = ("download", "prepare", "encode-training", "encode-validation", "export", "train", "finalize")
REVISION = "2c3321bba55a1a728bbb60a8bce220738ea90613"
IDS = ["avspeech_fixed100k_000000", "avspeech_fixed100k_000001", "avspeech_fixed100k_000003"]


def snapshot(path):
    path = Path(path).resolve()
    before = path.stat()
    digest = sha(path)
    if path.stat() != before:
        raise ValueError("File changed during CPU verification")
    return str(path), dict(bytes=before.st_size, inode=before.st_ino,
                           mtime_ns=before.st_mtime_ns, sha256=digest)


def identity(request):
    if request.get("profile") != "engineering-hf13-public285":
        raise ValueError("Unknown engineering profile")
    profile(request.get("world"), request.get("global_batch"))
    if request.get("revision") != REVISION or request.get("ids") != IDS:
        raise ValueError("The reproducible engineering selection changed")
    if not request.get("wandb_entity") or not request.get("wandb_project"):
        raise ValueError("Supply your own W&B entity/project")
    for field in ("reuse_model_receipt", "reuse_model_receipt_sha256"):
        if bool(request.get(field)) != bool(request.get("reuse_model")):
            raise ValueError("Explicit model reuse requires directory, receipt and trusted receipt SHA")
    return key(request)


def configure(request):
    pin = read(SOURCE / "configs/model_release.json")
    os.environ.update(HF_HUB_CACHE=request["hf_hub_cache"],
                      SAM_T5_REVISION=pin["t5_revision"], SAM_PYTHON=request["python"],
                      GPUS=str(request["world"]), PYTHONNOUSERSITE="1", OMP_NUM_THREADS="1",
                      OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                      CUBLAS_WORKSPACE_CONFIG=":4096:8",
                      WANDB_ENTITY=request["wandb_entity"],
                      WANDB_PROJECT=request["wandb_project"], WANDB_MODE="online")
    os.environ.pop("WANDB_RUN_ID", None)


def cpu_model(request, root):
    """Create an ordinary user's model receipt, or verify explicitly requested reuse."""
    cpu_only()
    pin = read(SOURCE / "configs/model_release.json")
    reused = request.get("reuse_model")
    if reused:
        receipt = Path(request["reuse_model_receipt"])
        if sha(receipt) != request["reuse_model_receipt_sha256"]:
            raise ValueError("Requested model receipt changed")
        old = read(receipt)
        expected = {str(Path(reused) / name) for name in pin["files"]}
        if (old.get("status") != "CPU_INPUT_READY" or set(old["model_files"]) != expected
                or old["explicit_hf_cache"] != request["hf_hub_cache"]):
            raise ValueError("Model receipt belongs to different paths/cache")
        inputs_unchanged(old["model_files"])
        for name, digest in pin["files"].items():
            if old["model_files"][str(Path(reused) / name)]["sha256"] != digest:
                raise ValueError("Model receipt is not for the pinned SAM weights")
        result = dict(status="CPU_INPUT_READY", model_files=old["model_files"],
                      explicit_hf_cache=request["hf_hub_cache"],
                      base_signature=pin["base_signature"], model=str(reused),
                      reused_model_preflight=True, source_receipt_sha256=sha(receipt))
    else:
        # Access to the gated SAM repository uses the caller's normal HF login.
        # Credentials are never copied into configuration or journals.
        model = root / "models/sam-audio"
        files = {}
        for name, expected in pin["files"].items():
            path, spec = snapshot(model / name)
            if spec["sha256"] != expected:
                raise ValueError("Pinned model hash differs: " + name)
            files[path] = spec
        result = dict(status="CPU_INPUT_READY", model=str(model), model_files=files,
                      explicit_hf_cache=request["hf_hub_cache"],
                      base_signature=pin["base_signature"], reused_model_preflight=False)
    # The new immutable-revision call path is checked even for explicit reuse;
    # no CUDA, network download or repeated SAM checkpoint deserialization.
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    import torch
    from sam_audio.model.config import T5EncoderConfig
    from sam_audio.model.text_encoder import T5TextEncoder
    torch.set_num_threads(1)
    text = T5TextEncoder(T5EncoderConfig(**read(Path(result["model"]) / "config.json")["text_encoder"]))
    if text.pretrained_identity != pin["base_signature"]["text_encoder_identity"]:
        raise ValueError("Pinned offline T5/tokenizer identity differs")
    del text
    if torch.cuda.is_initialized():
        raise ValueError("CPU model preparation initialized CUDA")
    result["actual_pinned_t5_verified"] = True
    write(root / "MODEL_READY.json", result)
    return result


def download(request, root):
    cpu_only()
    os.environ.pop("HF_HUB_OFFLINE", None)
    os.environ.pop("TRANSFORMERS_OFFLINE", None)
    pin = read(SOURCE / "configs/model_release.json")
    if not request.get("reuse_model"):
        from huggingface_hub import snapshot_download, HfApi
        snapshot_download(pin["repository"], revision=pin["revision"],
                          allow_patterns=list(pin["files"]),
                          local_dir=str(root / "models/sam-audio"),
                          cache_dir=request["hf_hub_cache"])
        available = HfApi().list_repo_files(pin["t5_repository"], revision=pin["t5_revision"])
        weight = "model.safetensors" if "model.safetensors" in available else "pytorch_model.bin"
        if weight not in available:
            raise ValueError("Pinned T5 release has no supported weight file")
        snapshot_download(pin["t5_repository"], revision=pin["t5_revision"],
                          allow_patterns=["config.json", weight,
                                          "tokenizer.json", "tokenizer_config.json",
                                          "special_tokens_map.json", "spiece.model"],
                          cache_dir=request["hf_hub_cache"])
    from prepare_avspeech_workflow import workflow
    from download_validation_data import prepare as download_validation
    reuse_training = request.get("reuse_training_media")
    if reuse_training:
        import_training_media(Path(reuse_training), root / "avspeech/media")
    validation_pin = read(SOURCE / "configs/validation_release.json")
    if request.get("reuse_validation_archive"):
        source = Path(request["reuse_validation_archive"])
        spec = validation_pin["archive"]
        if source.stat().st_size != spec["size"] or sha(source) != spec["sha256"]:
            raise ValueError("Reusable public archive differs from its immutable pin")
        target = root / "public-validation/media-release" / spec["path"]
        copy_verified(source, target, spec["sha256"])
    training = workflow(root / "avspeech", REVISION, IDS, phase="download")
    validation = download_validation(validation_pin,
                                     root / "public-validation/media-release")
    return dict(status="DOWNLOADED", training=training, validation=validation,
                model_bytes_reused=bool(request.get("reuse_model")),
                training_download_bytes_reused=bool(reuse_training),
                validation_archive_bytes_reused=bool(request.get("reuse_validation_archive")))


def copy_verified(source, target, expected):
    source, target = Path(source), Path(target)
    if source.is_symlink() or sha(source) != expected:
        raise ValueError("Reusable file differs from its verification")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if target.is_symlink() or sha(target) != expected:
            raise ValueError("Imported output changed; do not silently overwrite it")
        return
    temp = target.with_suffix(target.suffix + ".importing")
    shutil.copyfile(source, temp)
    if sha(temp) != expected:
        raise ValueError("Imported copy differs")
    temp.replace(target)


def import_training_media(source, target):
    """Copy only verified selected raw bytes; never adopt cache/GT/run receipts."""
    from prepare_avspeech_workflow import selection, check_media
    from data_manifest import path_in
    check_media(source, selection(REVISION, IDS, False))
    paths = {}
    for receipt in sorted((source / "receipts").glob("*.json")):
        value = read(receipt)
        if not set(value["identity"]["ids"]) <= set(IDS) or not value["files"]:
            raise ValueError("Unrelated raw download receipt")
        for row in value["files"]:
            name = row["path"]
            path = path_in(source, name)
            if path.stat().st_size != row["bytes"]:
                raise ValueError("Reusable raw size changed")
            if name in paths and paths[name] != row["sha256"]:
                raise ValueError("Conflicting download receipts")
            paths[name] = row["sha256"]
        paths[str(receipt.relative_to(source))] = sha(receipt)
    if not paths:
        raise ValueError("No verified raw download receipts")
    for name in ("RELEASE.json", "videos.jsonl", "prompts.jsonl"):
        paths[name] = sha(source / name)
    for name, expected in paths.items():
        copy_verified(path_in(source, name), path_in(target, name), expected)
    check_media(target, selection(REVISION, IDS, False))


def prepare(request, root):
    cpu_only()
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    model = cpu_model(request, root)
    # Media transfer is public; the accepted helpers retain per-archive verified
    # receipts and can resume interruption without downloading verified bytes.
    from prepare_avspeech_workflow import workflow
    from prepare_encoder_input import prepare as plan_training
    from prepare_public_validation_input import prepare as plan_validation
    from sam_audio.native_finetuning.feature_cache import make_cache_plan
    media = workflow(root / "avspeech", REVISION, IDS, phase="prepare")
    train = plan_training(root / "avspeech", root / "encoder-input", make_cache_plan)
    if (media["prompts"], train["targets"], train["prompts"]) != (13, 8, 13):
        raise ValueError("Engineering training coverage changed")
    pin = SOURCE / "configs/validation_release.json"
    cfg = dict(output=str(root / "public-validation"), release_config=str(pin),
               release_config_sha256=sha(pin), accepted_model_receipt=str(root / "MODEL_READY.json"),
               accepted_model_receipt_sha256=sha(root / "MODEL_READY.json"),
               hf_hub_cache=request["hf_hub_cache"], model=model["model"],
               base_signature=model["base_signature"], offline_prepared_media=True,
               world=request["world"])
    write(root / "validation-prepare.json", cfg)
    validation = plan_validation(root / "validation-prepare.json")
    shape = profile(request["world"], request.get("global_batch"))
    train_cfg = read(SOURCE / "configs/engineering-public.json")
    train_cfg.update(world_size=shape["gpus"], effective_batch_size=shape["global_batch"],
                     gradient_accumulation_steps=shape["accumulation"], num_epochs=shape["epochs"])
    write(root / "training-config.json", train_cfg)
    common = dict(world=shape["training_encoder_gpus"], revision=REVISION, model=model["model"],
                  base_signature=model["base_signature"],
                  train_config=str(root / "training-config.json"))
    write(root / "training-encode.json", common)
    # Keep the already GPU-tested training encoder API unchanged.
    write(root / "stages/prepare/RESULT.json",
          dict(status="CPU_INPUT_READY", inputs=train, model_files=model["model_files"]))
    vroot = root / "public-validation"
    vcfg = dict(input=str(vroot / "ENCODER_INPUT.json"), ready=str(vroot / "CPU_READY.json"),
                input_sha256=validation["input_sha256"], ready_sha256=sha(vroot / "CPU_READY.json"),
                plan_identity=validation["plan_identity"], public_revision=validation["public_revision"],
                source_manifest_sha256=sha(SOURCE / "SOURCE_MANIFEST.json"),
                selection="all285", expected_counts={"msdwild": 78, "easycom": 207})
    write(root / "validation-encode.json", vcfg)
    files = dict(train["input_files"], **validation["media_files"], **model["model_files"])
    for name, expected in read(SOURCE / "SOURCE_MANIFEST.json").items():
        path, spec = snapshot(SOURCE / name)
        if spec["sha256"] != expected:
            raise ValueError("Prepared source changed: " + name)
        files[path] = spec
    for path in (root / "training-config.json", root / "training-encode.json", root / "validation-encode.json",
                 root / "encoder-input/cache_plan.json", vroot / "ENCODER_INPUT.json",
                 vroot / "CPU_READY.json", root / "MODEL_READY.json"):
        name, spec = snapshot(path)
        files[name] = spec
    return dict(status="PREPARED", inputs=files,
                reused_training_download_bytes=bool(request.get("reuse_training_media")),
                reused_validation_archive_bytes=bool(request.get("reuse_validation_archive")),
                reused_model_preflight=bool(request.get("reuse_model")),
                training_features="NOT_GENERATED", validation_features="NOT_GENERATED")


def gpu_stage(request, root, stage):
    shape = profile(request["world"], request.get("global_batch"))
    world = shape["training_encoder_gpus"] if stage == "encode-training" else request["world"]
    inputs_unchanged(read(root / "journal/prepare.json")["result"]["inputs"])
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    if stage == "encode-training":
        worker = [str(SOURCE / "tools/standalone_workflow.py"),
                  "--worker-training", str(root)]
    else:
        worker = [str(SOURCE / "tools/encode_public_validation.py"),
                  "--config", str(root / "validation-encode.json"),
                  "--output", str(root / "validation-features")]
    subprocess.run([request["python"], "-m", "torch.distributed.run", "--standalone",
                    "--nnodes=1", f"--nproc_per_node={world}", *worker], check=True)
    if stage == "encode-training":
        cfg = read(root / "training-encode.json")
        plan = read(root / "encoder-input/cache_plan.json")
        reports = [read(root / f"encoded/rank{rank}.json") for rank in range(world)]
        check_ranks(reports, plan, world, key(dict(plan=plan, revision=REVISION,
                                            model=cfg["base_signature"])))
        return dict(status="ENCODED", rank_receipts=reports)
    from public_validation_contract import finalize
    return finalize(root / "validation-features", root / "validation-encode.json")


def export(request, root):
    cpu_only()
    import torch
    from sam_audio.native_finetuning.feature_cache import ComponentStore, finalize_catalog
    from sam_audio.native_finetuning.training_support import check_entry
    from public_validation_export import validation_fragment
    from public_validation_contract import load_inputs, merge
    from export_bundle import export as export_bundle
    torch.set_num_threads(1)
    prepared = read(root / "journal/prepare.json")["result"]
    inputs_unchanged(prepared["inputs"])
    cfg = read(root / "training-encode.json")
    plan = read(root / "encoder-input/cache_plan.json")
    world = cfg["world"]
    ranks = [read(root / f"encoded/rank{rank}.json") for rank in range(world)]
    check_ranks(ranks, plan, world, key(dict(plan=plan, revision=REVISION, model=cfg["base_signature"])))
    if any(r["signature"] != ranks[0]["signature"] for r in ranks):
        raise ValueError("Training encoder signatures differ")
    store = ComponentStore(root / "encoded/components", ranks[0]["signature"])
    catalog = read(finalize_catalog(copy.deepcopy(plan), store, 48000))
    originals = read(root / "encoder-input/encoder_rows.json")
    if len(catalog["splits"]["train"]["entries"]) != len(originals):
        raise ValueError("Training cache coverage changed")
    files, seen = [], set()
    def finite(value):
        if isinstance(value, torch.Tensor):
            if value.is_floating_point() and not torch.isfinite(value).all().item():
                raise ValueError("Nonfinite training cache")
        elif isinstance(value, dict):
            for v in value.values():
                finite(v)
    for entry, row in zip(catalog["splits"]["train"]["entries"], originals):
        refs = entry["variants"][0]
        if len(entry["variants"]) != 1 or refs["prompt"] != row["prompt"].strip():
            raise ValueError("Training prompt coverage changed")
        assembled = store.assemble(refs)
        finite(assembled)
        forward = assembled["forward_args"]
        labels = forward["anchor_ids"].gather(1, forward["anchor_alignment"])
        if int((labels == 1).sum()) != 250 or labels.shape[1] != assembled["clean"].shape[1]:
            raise ValueError("GT source-placement support changed")
        for kind in ("mixture", "video", "clean", "text"):
            path = store.path(kind, refs[kind])
            if path not in seen:
                finite(torch.load(path, map_location="cpu", weights_only=True))
                files.append(dict(source=str(path), destination=str(path.relative_to(root / "encoded"))))
                seen.add(path)
    subprocess.run([request["python"], str(SOURCE / "tools/audit_public_validation.py"),
                    "--config", str(root / "validation-encode.json"),
                    "--output", str(root / "validation-features")], check=True)
    vcfg, vplan, vready, _ = load_inputs(root / "validation-encode.json")
    feature_root = root / "validation-features"
    merge([read(feature_root / f"rank-{r}/RESULT.json") for r in range(vplan["world"])],
          vplan, vready, vcfg, feature_root)
    validation, vfiles = validation_fragment(read(feature_root / "CPU_AUDIT.json"),
                                            vplan, vready, feature_root)
    files.extend(vfiles)
    supervision = check_entry(catalog, validation, read(cfg["train_config"]))
    staging = root / "export-input"
    staging.mkdir(exist_ok=False)
    write(staging / "catalog.json", catalog)
    write(staging / "validation.json", validation)
    files += [dict(source=str(staging / "catalog.json"), destination="catalog.json"),
              dict(source=str(staging / "validation.json"), destination="validation/manifest.json")]
    audit = staging / "AUDIT.json"
    write(audit, dict(status="PASS", public_revision=vplan["public_revision"],
                     new_training_cache=True, new_validation_cache=True,
                     supervision=supervision, cohort=vplan["cohort"]))
    manifest = export_bundle(dict(audit=str(audit), files=files, bundle=dict(
        train_catalog="catalog.json", train_components="components",
        validation_manifest="validation/manifest.json", training_supervision=supervision,
        validation_cohort=vplan["cohort"], scope="ENGINEERING_HF13_GT_TRAIN",
        public_validation_revision=vplan["public_revision"],
        validation_features_provenance="FRESH_ALL285_PUBLIC_MEDIA")), root / "bundle")
    # Use the same actual CLI entry as the prepared-bundle acceptance, with a
    # receipt generated here. The outsider supplies no private preflight file.
    model = read(root / "MODEL_READY.json")
    subprocess.run(["bash", str(SOURCE / "bundle-start.sh"), "--phase", "prepare",
                    "--directory", str(root / "entry"), "--data-root", str(root / "bundle"),
                    "--data-manifest-sha256", sha(root / "bundle/manifest.json"),
                    "--model", model["model"], "--model-receipt", str(root / "MODEL_READY.json"),
                    "--hf-hub-cache", request["hf_hub_cache"], "--wandb-entity", request["wandb_entity"],
                    "--wandb-project", request["wandb_project"],
                    "--gpus", str(request["world"]),
                    "--global-batch", str(profile(request["world"], request.get("global_batch"))["global_batch"]),
                    "--training-config", str(root / "training-config.json")], check=True)
    return dict(status="EXPORTED", files=len(manifest["files"]), bytes=manifest["total_bytes"],
                manifest_sha256=sha(root / "bundle/manifest.json"),
                training_cache_new=True, validation_cache_new=True)


def run_stage(request, root, stage):
    if stage == "download":
        return download(request, root)
    if stage == "prepare":
        return prepare(request, root)
    if stage.startswith("encode-"):
        return gpu_stage(request, root, stage)
    if stage == "export":
        return export(request, root)
    if stage == "finalize":
        cpu_only()
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    subprocess.run(["bash", str(SOURCE / "bundle-start.sh"), "--phase",
                    "train" if stage == "train" else "finalize",
                    "--directory", str(root / "entry")], check=True)
    receipt = root / "entry" / ("ENTRY_RESULT.json" if stage == "train" else "ENTRY_FINALIZATION.json")
    result = read(receipt)
    if stage == "train" and result["terminal"]["status"] != "COMPLETE":
        raise ValueError("Engineering training did not naturally complete")
    if stage == "finalize" and result["status"] != "ARCHIVED_VERIFIED_CONTENT":
        raise ValueError("Best/last archival has not been verified")
    return result


def verify_completed(root, stage, record, request):
    if record.get("request_identity") != identity(request) or record.get("status") != "COMPLETE":
        raise ValueError("Incomplete or mismatched stage; reconcile before retry")
    # Output metadata is immutable after acceptance; compute never hashes media.
    for path, digest in record.get("outputs", {}).items():
        if sha(path) != digest:
            raise ValueError("Accepted stage metadata changed: " + stage)
    return record["result"]


def execute(request, root, through, only=None, runner=run_stage):
    journal = root / "journal"
    journal.mkdir(exist_ok=True)
    for stage in STAGES[:STAGES.index(through) + 1]:
        receipt = journal / (stage + ".json")
        if receipt.exists():
            verify_completed(root, stage, read(receipt), request)
            continue
        if only and only != stage:
            raise ValueError("Required preceding stage is missing: " + stage)
        if stage in ("download", "prepare", "export", "finalize"):
            cpu_only()
        intent = journal / (stage + "-INTENT.json")
        if intent.exists() and stage not in ("download", "prepare"):
            raise ValueError("Unresolved " + stage + " intent; inspect process and output before retry")
        if intent.exists() and read(intent)["request_identity"] != identity(request):
            raise ValueError("Stage intent belongs to another request")
        if stage.startswith("encode-") or stage == "train":
            shape = profile(request["world"], request.get("global_batch"))
            ranks = shape["training_encoder_gpus"] if stage == "encode-training" else request["world"]
            write(root / (stage + "-GPU_CHECK.json"), probe(ranks))
        if not intent.exists():
            write(intent, dict(status="STARTED", request_identity=identity(request), started=time.time()))
        started = time.monotonic()
        result = runner(request, root, stage)
        outputs = {}
        paths = {
            "download": ["avspeech/media/RELEASE.json",
                         "public-validation/media-release/DOWNLOAD_RECEIPT.json"],
            "prepare": ["MODEL_READY.json", "training-config.json", "training-encode.json", "validation-encode.json"],
            "encode-training": [f"encoded/rank{r}.json" for r in range(profile(request["world"], request.get("global_batch"))["training_encoder_gpus"])],
            "encode-validation": ["validation-features/RESULT.json"],
            "export": ["bundle/manifest.json", "entry/INPUT_READY.json"],
            "train": ["entry/ENTRY_RESULT.json"],
            "finalize": ["entry/ENTRY_FINALIZATION.json"],
        }[stage]
        for path in paths:
            target = root / path
            outputs[str(target)] = sha(target)
        write(receipt, dict(status="COMPLETE", request_identity=identity(request),
                            result=result, outputs=outputs, seconds=time.monotonic() - started))
    return dict(status="COMPLETE" if through == "finalize" else "PREFIX_COMPLETE",
                through=through, scope="ENGINEERING_HF13_PUBLIC285",
                reused_environment=request.get("environment_preexisting", False),
                reused_model_preflight=bool(request.get("reuse_model")))


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--worker-training":
        root = Path(sys.argv[2]).resolve()
        from workflow_stages import encode
        encode(read(root / "training-encode.json"), root)
        return
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--directory", type=Path)
    p.add_argument("--gpus", type=int)
    p.add_argument("--global-batch", type=int)
    p.add_argument("--gpu-plan", action="store_true", help="Print the bounded single-node plan without downloads or Torch")
    p.add_argument("--check-gpus", action="store_true", help="Inspect visible CUDA hardware without launching training")
    p.add_argument("--wandb-entity")
    p.add_argument("--wandb-project")
    p.add_argument("--hf-hub-cache", type=Path)
    p.add_argument("--reuse-model", type=Path)
    p.add_argument("--reuse-model-receipt", type=Path)
    p.add_argument("--reuse-model-receipt-sha256")
    p.add_argument("--reuse-training-media", type=Path)
    p.add_argument("--reuse-validation-archive", type=Path)
    p.add_argument("--through", choices=STAGES, default="finalize")
    p.add_argument("--only", choices=STAGES)
    args = p.parse_args()
    if args.gpu_plan or args.check_gpus:
        value = profile(args.gpus if args.gpus is not None else 2, args.global_batch)
        if args.check_gpus:
            value["hardware"] = probe(value["gpus"])
        print(json.dumps(value, indent=2))
        return
    if args.directory is None:
        p.error("--directory is required for workflow execution")
    root = args.directory.resolve()
    root.mkdir(parents=True, exist_ok=True)
    with (root / "WORKFLOW.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        path = root / "WORKFLOW_REQUEST.json"
        if path.exists():
            request = read(path)
            if args.gpus is not None and args.gpus != request["world"]:
                raise ValueError("GPU count changed: use a new workspace; checkpoint resharding is unsupported")
            if args.global_batch is not None and args.global_batch != request["global_batch"]:
                raise ValueError("Global batch changed: use a new workspace")
            for field in ("wandb_entity", "wandb_project", "hf_hub_cache", "reuse_model", "reuse_model_receipt",
                          "reuse_model_receipt_sha256", "reuse_training_media", "reuse_validation_archive"):
                value = getattr(args, field)
                if value is not None and (str(value.resolve()) if isinstance(value, Path) else value) != request.get(field):
                    raise ValueError("Existing workspace request changed: " + field)
        else:
            shape = profile(args.gpus if args.gpus is not None else 2, args.global_batch)
            request = dict(profile="engineering-hf13-public285", world=shape["gpus"],
                           global_batch=shape["global_batch"],
                           revision=REVISION, ids=IDS, directory=str(root), python=sys.executable,
                           source_manifest_sha256=sha(SOURCE / "SOURCE_MANIFEST.json"),
                           wandb_entity=args.wandb_entity, wandb_project=args.wandb_project or "sam-audio",
                           environment_preexisting=bool(os.environ.get("SAM_ENVIRONMENT_REUSED")),
                           hf_hub_cache=str((args.hf_hub_cache or root / "hf-cache").resolve()),
                           reuse_model=str(args.reuse_model.resolve()) if args.reuse_model else None,
                           reuse_model_receipt=str(args.reuse_model_receipt.resolve()) if args.reuse_model_receipt else None,
                           reuse_model_receipt_sha256=args.reuse_model_receipt_sha256,
                           reuse_training_media=str(args.reuse_training_media.resolve()) if args.reuse_training_media else None,
                           reuse_validation_archive=str(args.reuse_validation_archive.resolve()) if args.reuse_validation_archive else None)
            identity(request)
            write(path, request)
        if sha(SOURCE / "SOURCE_MANIFEST.json") != request["source_manifest_sha256"]:
            raise ValueError("Workspace source version changed")
        if request["python"] != sys.executable:
            raise ValueError("Workspace Python environment changed")
        configure(request)
        result = execute(request, root, args.only or args.through, args.only)
        write(root / "WORKFLOW_RESULT.json", result)
        print(result, flush=True)


if __name__ == "__main__":
    main()
