"""Audit training GT support from frozen AVSpeech recipes on CPU.

Matches the previous AVSpeech rule: one ten-second source interval at its
composite offset, including silence within that interval. This is not VAD.
It preserves all prompt fields and the already rendered video/crop. It does
not touch validation, encode GPU features or certify training readiness.
"""
import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import uuid

from prepare_selected_media import (
    atomic_json, canonical, check_recipe, digest, receipt_index, safe_path,
    selected_metadata, verified_files,
)

RULE = "source-placement-480000-samples-v1"
SAMPLE_RATE = 48000
SOURCE_SAMPLES = 480000


def support(video, recipe, target):
    """Return the exact original source-placement rule, never infer activity."""
    check_recipe(recipe, video)
    arity = video["arity"]
    if (type(arity) is not int or arity not in (2, 3, 4, 5)
            or recipe.get("arity") != arity
            or len(recipe["inputs"]) != arity
            or sorted(t["slot"] for t in video["targets"]) != list(range(arity))):
        raise ValueError("Incomplete frozen layout or target slots")
    mode = video["mode"]
    if mode not in ("temporal", "spatial", "visibility", "onscreen_offscreen"):
        raise ValueError("Unknown composition rule")
    if recipe.get("final_recipe_frozen") is not True or recipe.get("state") != "READY":
        raise ValueError("Recipe is not final and ready")
    total = SOURCE_SAMPLES * (arity if mode == "temporal" else 1)
    if video["samples"] != total or video["sample_rate"] != SAMPLE_RATE:
        raise ValueError("Duration differs from the frozen ten-second-source rule")
    source = recipe["inputs"][target["slot"]]
    start, end = source["start"], source["end"]
    if (not all(type(x) in (int, float) and math.isfinite(x) for x in (start, end))
            or start < 0 or abs(end - start - 10) > 1e-6):
        raise ValueError("Source window is not ten seconds")
    crop = source["crop_xywh"]
    if (len(crop) != 4 or any(type(x) is not int for x in crop)
            or min(crop[:2]) < 0 or min(crop[2:]) <= 0
            or type(source["visible"]) is not bool):
        raise ValueError("Invalid frozen crop or visibility")
    offset = target["slot"] * SOURCE_SAMPLES if mode == "temporal" else 0
    return dict(support_samples=[offset, offset + SOURCE_SAMPLES],
                intervals_seconds=[[offset / SAMPLE_RATE, (offset + SOURCE_SAMPLES) / SAMPLE_RATE]],
                crop_xywh=crop, output_size=source["output_size"],
                visible=source["visible"], source_start=start, source_end=end)


def audit_target(path, samples, interval):
    import numpy as np
    import soundfile as sf
    wave, rate = sf.read(path, dtype="float32", always_2d=True)
    if (rate != SAMPLE_RATE or wave.shape != (samples, 1)
            or not np.isfinite(wave).all()):
        raise ValueError("Prepared target is not finite full-length 48kHz mono")
    start, end = interval
    if np.count_nonzero(wave[:start]) or np.count_nonzero(wave[end:]):
        raise ValueError("Target has nonzero samples outside frozen support")
    # Quiet/zero frames inside support remain part of the original supervision.
    return dict(outside_nonzero=0, inside_nonzero=int(np.count_nonzero(wave[start:end])),
                sample_count=samples)


def prepare(media, prepared, output, audio_auditor=audit_target):
    if os.environ.get("SLURM_JOB_GPUS") or os.environ.get("SLURM_STEP_GPUS"):
        raise ValueError("GT support preparation requires CPU resources")
    media, prepared, output = (Path(x).resolve() for x in (media, prepared, output))
    if any(output == p or output.is_relative_to(p) or p.is_relative_to(output)
           for p in (media, prepared)):
        raise ValueError("Use an independent output; preserve prepared media")
    output.mkdir(parents=True, exist_ok=True)
    with (output / "GT_SUPPORT.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        attempt = uuid.uuid4().hex
        history = output / "attempts" / attempt
        history.mkdir(parents=True)
        ready_path = output / "GT_SUPPORT_READY.json"
        if ready_path.exists():
            ready_path.replace(history / "PREVIOUS_READY.json")
        try:
            release, videos, prompts, _, scope = selected_metadata(media)
            metadata = {n: digest(media / n) for n in
                        ("RELEASE.json", "videos.jsonl", "prompts.jsonl")}
            cpu = json.loads((prepared / "CPU_READY.json").read_text())
            rows_path = prepared / "train_rows.json"
            if (cpu["status"] != "PASS" or cpu["metadata"] != metadata
                    or cpu["revision"] != release["revision"]
                    or cpu["rows_sha256"] != digest(rows_path)):
                raise ValueError("CPU preparation receipt does not match current media")
            rows = json.loads(rows_path.read_text())
            by_prompt = {r["prompt_id"]: r for r in rows}
            if len(by_prompt) != len(rows) or set(by_prompt) != {r["prompt_id"] for r in prompts}:
                raise ValueError("Prepared prompt coverage changed")
            for original in prompts:
                if any(by_prompt[original["prompt_id"]].get(k) != v for k, v in original.items()):
                    raise ValueError("Original prompt fields changed")
            identity = dict(rule=RULE, revision=release["revision"], metadata=metadata,
                            prepared_rows_sha256=cpu["rows_sha256"])
            identity_path = output / "IDENTITY.json"
            if identity_path.exists() and json.loads(identity_path.read_text()) != identity:
                raise ValueError("Output belongs to different supervision inputs")
            atomic_json(identity_path, identity)
            index, targets, audits = receipt_index(media), {}, []
            for video in videos:
                cid = video["composite_id"]
                files = verified_files(media, video, index)
                recipe_path = media / "data" / cid / "recipe.json"
                # The HF packer replaces host-specific paths with provenance
                # URIs and reserializes JSON. Its file hash differs from the
                # original recipe identity retained in videos/prompts metadata.
                # verified_files checks actual bytes against the archive receipt.
                public_recipe_sha = files[f"data/{cid}/recipe.json"]["sha256"]
                recipe = json.loads(recipe_path.read_text())
                folder = prepared / cid
                receipt = json.loads((folder / "COMPOSITE_READY.json").read_text())
                import hashlib
                expected_key = hashlib.sha256(canonical(
                    dict(metadata=metadata, video=video, files=files)).encode()).hexdigest()
                expected_names = {f"{kind}_{t['slot']}.wav"
                                  for t in video["targets"] for kind in ("target", "residual")}
                if receipt["input_key"] != expected_key or receipt["outputs"].keys() != expected_names:
                    raise ValueError("Prepared composite receipt mismatch")
                for name, spec in receipt["outputs"].items():
                    path = safe_path(folder, name)
                    if path.stat().st_size != spec["bytes"] or digest(path) != spec["sha256"]:
                        raise ValueError("Prepared target/residual changed")
                for target in video["targets"]:
                    slot = target["slot"]
                    item = support(video, recipe, target)
                    path = folder / f"target_{slot}.wav"
                    audit = audio_auditor(path, video["samples"], item["support_samples"])
                    key = cid, slot
                    targets[key] = dict(item, composite_id=cid, slot=slot,
                                        source_id=target["source_id"], window_id=target["window_id"],
                                        recipe_sha256=video["recipe_sha256"],
                                        archived_recipe_sha256=public_recipe_sha,
                                        target_sha256=receipt["outputs"][path.name]["sha256"])
                    audits.append(dict(composite_id=cid, slot=slot, **audit))
            enriched = []
            for row in rows:
                target = targets[row["composite_id"], row["slot"]]
                cid, slot = row["composite_id"], row["slot"]
                paths = dict(video_path=media / "data" / cid / "video.mp4",
                             mixture_audio_path=media / "data" / cid / "mixture.wav",
                             gt_audio_path=prepared / cid / f"target_{slot}.wav",
                             residual_audio_path=prepared / cid / f"residual_{slot}.wav")
                if any(Path(row[k]).resolve() != p for k, p in paths.items()):
                    raise ValueError("Prepared row points outside its verified target")
                if any(k in row for k in ("training_gt_spans", "training_gt_rule")):
                    raise ValueError("Do not overwrite preexisting supervision")
                enriched.append(dict(row, training_gt_spans=target["intervals_seconds"],
                                     training_gt_rule=RULE))
            if any(digest(media / n) != checksum for n, checksum in metadata.items()):
                raise ValueError("Metadata changed during support preparation")
            atomic_json(output / "train_rows.json", enriched)
            atomic_json(output / "targets.json", list(targets.values()))
            result = dict(status="PASS_CPU_GT_SUPPORT", rule=RULE, scope=scope,
                          training_ready=False, gpu_anchors="NOT_TESTED",
                          validation="NOT_MODIFIED", crop="PRESERVED_RENDERED_VIDEO",
                          identity=identity, targets=len(targets), prompts=len(enriched),
                          files={n: digest(output / n) for n in ("train_rows.json", "targets.json")},
                          waveform_audit=audits)
            atomic_json(ready_path, result)
            atomic_json(history / "RESULT.json", result)
            return result
        except BaseException as exc:
            atomic_json(history / "RESULT.json", dict(status="FAILED", error=str(exc)))
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--media", required=True)
    parser.add_argument("--prepared", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.media, args.prepared, args.output), indent=2))


if __name__ == "__main__":
    main()
