"""Actual full-duration encoding of public media; no scoring or GT conditioning."""
def main():
    import argparse
    import faulthandler
    import os
    import time
    from pathlib import Path
    from public_validation_contract import (load_inputs, partition, inputs_unchanged, RECIPE, STATUS,
                          write, check_signature)
    p = argparse.ArgumentParser()
    p.add_argument("--output", required=True)
    p.add_argument("--config", required=True)
    args = p.parse_args()
    cfg, plan, ready, rows = load_inputs(args.config)
    rank, world = int(os.environ["LOCAL_RANK"]), int(os.environ["WORLD_SIZE"])
    if int(os.environ["LOCAL_WORLD_SIZE"]) != world or world != plan["world"]:
        raise ValueError("Single-node world must match the prepared plan")
    assigned = partition(rows, rank, world)
    if (os.environ.get("HF_HUB_CACHE") != plan["hf_hub_cache"]
            or os.environ.get("HF_HUB_OFFLINE") != "1"
            or os.environ.get("TRANSFORMERS_OFFLINE") != "1"):
        raise ValueError("Explicit accepted offline model cache required")
    # CPU/DataMover verified bytes. GPU startup only checks unchanged file stats.
    inputs_unchanged(ready["model_files"])
    media = {str(Path(plan["media_root"]) / r[k]): ready["media_files"][str(Path(plan["media_root"]) / r[k])]
             for r in assigned for k in ("video", "mixture_audio", "gt_audio")}
    inputs_unchanged(media)
    out = Path(args.output).resolve() / f"rank-{rank}"
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    receipt = dict(status="STARTING", rank=rank, world=world, rows=[],
                   input_sha256=cfg["input_sha256"], plan_identity=cfg["plan_identity"],
                   recipe=RECIPE, gt_audio_read=False)
    faulthandler.enable()  # Fatal signal only; no periodic native stack walking.
    try:
        import torch
        from sam_audio import SAMAudio, SAMAudioProcessor
        from sam_audio.native_finetuning.feature_cache import FrozenExtractor
        from sam_audio.native_finetuning.optimized_utils import StageTimer
        from sam_audio.native_finetuning.delivery_impl import model_signature
        torch.set_num_threads(1)
        torch.cuda.set_device(rank)
        device = torch.device("cuda", rank)
        props = torch.cuda.get_device_properties(rank)
        receipt["gpu_uuid"] = str(props.uuid)
        receipt["gpu_total_bytes"] = props.total_memory
        receipt["python_prefix"] = __import__("sys").prefix
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True)
        torch.manual_seed(2026)
        print(f"MODEL_LOADING rank={rank} uuid={props.uuid}", flush=True)
        model = SAMAudio.from_pretrained(plan["model"], strict=True, visual_ranker=None,
                                        text_ranker=None, span_predictor=None)
        model.to(device=device, dtype=torch.bfloat16).eval().requires_grad_(False)
        processor = SAMAudioProcessor.from_pretrained(plan["model"])
        signature_cfg = dict(dtype="bfloat16", max_seconds=None, video_frame_chunk=8,
                             allow_tf32=True, sam_audio_model="facebook/sam-audio-large-tv")
        sig = model_signature(plan["model"], signature_cfg, processor, model)
        check_signature(sig, plan)
        receipt["model_signature"] = sig
        extractor = FrozenExtractor(model, processor, device, torch.bfloat16,
                                    StageTimer(device), to_cpu=True, video_frame_chunk=8)
        torch.cuda.synchronize()
        receipt["imports_model_ready_seconds"] = time.monotonic() - started
        print(f"MODEL_READY rank={rank} seconds={receipt['imports_model_ready_seconds']}", flush=True)
        for row in assigned:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats(device)
            row_start = time.monotonic()
            mix = extractor.mixture(extractor.read_audio(str(Path(plan["media_root"]) / row["mixture_audio"])))
            if mix["latent_frames"] != row["latent_frames"]:
                raise ValueError("Original full duration changed")
            forward = dict(mix["forward_args"])
            forward["masked_video_features"] = extractor.video(str(Path(plan["media_root"]) / row["video"]), mix)
            forward.update(extractor.text(row["prompt"]))
            torch.cuda.synchronize()
            encode_seconds = time.monotonic() - row_start
            if forward["anchor_ids"].tolist() != [[0, 3]]:
                raise ValueError("GT conditioning forbidden")
            if not all(not v.is_floating_point() or torch.isfinite(v).all().item() for v in forward.values()):
                raise ValueError("Nonfinite features")
            path = out / f"row-{row['index']}.pt"
            tmp = path.with_suffix(".partial")
            torch.save(dict(forward=forward, latent_frames=mix["latent_frames"]), tmp)
            tmp.replace(path)
            peak = torch.cuda.max_memory_allocated(device)
            if peak >= props.total_memory * .92:
                raise RuntimeError("Insufficient memory headroom")
            record = dict(row=row, path=str(path), latent_frames=mix["latent_frames"],
                          finite=True, anchor_ids=[[0, 3]], encoding_seconds=encode_seconds,
                          row_seconds=time.monotonic()-row_start, peak_gpu_bytes=peak,
                          tensors={k:dict(shape=list(v.shape), dtype=str(v.dtype)) for k,v in forward.items()})
            receipt["rows"].append(record)
            receipt.update(status="ENCODING", seconds=time.monotonic()-started)
            write(out / "PROGRESS.json", receipt)
            print(f"ENCODED rank={rank} index={row['index']} dataset={row['dataset']} "
                  f"seconds={encode_seconds:.6f} peak={peak} count={len(receipt['rows'])}/{len(assigned)}", flush=True)
        inputs_unchanged(media)
        receipt["status"] = STATUS
    except BaseException as exc:
        receipt.update(status="FAILED", error=type(exc).__name__ + ": " + str(exc))
        raise
    finally:
        receipt["seconds"] = time.monotonic()-started
        write(out / "RESULT.json", receipt)


if __name__ == "__main__":
    main()
