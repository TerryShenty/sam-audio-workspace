"""Small immutable stage contracts shared by the private integration entry."""
import hashlib
import json
import os
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def key(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def cpu_only():
    if os.environ.get("SLURM_JOB_GPUS") or os.environ.get("SLURM_STEP_GPUS"):
        raise ValueError("Transfer, hashing and preparation require CPU resources")


def inputs_unchanged(inputs):
    for name, spec in inputs.items():
        stat = Path(name).stat()
        if (stat.st_size, stat.st_mtime_ns, stat.st_ino) != (
                spec["bytes"], spec["mtime_ns"], spec["inode"]):
            raise ValueError("Prepared input changed: " + name)


def shards(plan, rank, world):
    if world < 1 or not 0 <= rank < world or len(plan["mixtures"]) < world:
        raise ValueError("World size exceeds nonempty mixture work")
    # The encoder itself stays unchanged; each worker receives disjoint tasks.
    return {kind: {k: plan[kind][k] for i, k in enumerate(sorted(plan[kind]))
                   if i % world == rank} for kind in ("mixtures", "texts")}


def check_ranks(reports, plan, world, identity):
    if len(reports) != world or {r["rank"] for r in reports} != set(range(world)):
        raise ValueError("Missing or duplicated rank")
    if len({r["gpu_uuid"] for r in reports}) != world:
        raise ValueError("Ranks share GPU UUID")
    for r in reports:
        assigned = shards(plan, r["rank"], world)
        expected = {k: sorted(v) for k, v in assigned.items()}
        if (r["status"] != "ENCODED" or r["identity"] != identity
                or r["world"] != world or r["assigned"] != expected
                or not r["new_components"].get("mixture")
                or not r["new_components"].get("video")):
            raise ValueError("Encoding receipt does not match sealed work")


def selection(config):
    if config.get("private_validation") is not True:
        raise ValueError("This candidate requires explicit private validation mode")
    if config.get("training_scope") != "ENGINEERING_HF13_GT":
        raise ValueError("This bounded candidate is for the frozen engineering selection")
    if config.get("uses_public_validation_download") is not False:
        raise ValueError("Reused local validation cannot count as fresh public download")
    if len(config["ids"]) != 3 or len(set(config["ids"])) != 3:
        raise ValueError("Exactly three unique frozen composites required")
    if config["world"] != 2:
        raise ValueError("This resource plan requires two ranks")
    if config["revision"] != "2c3321bba55a1a728bbb60a8bce220738ea90613":
        raise ValueError("Engineering release revision changed")
    return config
