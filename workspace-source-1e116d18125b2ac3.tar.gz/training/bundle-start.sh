#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source tools/media_env.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
exec "${SAM_PYTHON:-$PWD/.venv/bin/python}" tools/public_entry.py "$@"
