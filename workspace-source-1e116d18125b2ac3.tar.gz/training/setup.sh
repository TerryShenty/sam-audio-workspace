#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${PYTHON_BIN:=python3.12}"
"$PYTHON_BIN" -c 'import sys,platform; assert sys.version_info[:2]==(3,12), "Python 3.12 required"; assert platform.system()=="Linux" and platform.machine()=="x86_64", "Linux x86_64 required"'
if [[ -z "${SAM_FFMPEG_PREFIX:-}" ]]; then
  "$PYTHON_BIN" tools/prepare_media_runtime.py --destination "$PWD/.runtime"
  export SAM_FFMPEG_PREFIX="$PWD/.runtime/ffmpeg"
fi
source tools/media_env.sh
"$PYTHON_BIN" tools/check_dependency_coverage.py
if [[ ! -x .venv/bin/python ]]; then "$PYTHON_BIN" -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements-reference.txt
# Install the included code, without replacing the pinned dependency versions.
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python tools/repair_decord_metadata.py
.venv/bin/python -m pip check
.venv/bin/python tools/preflight.py --output ENVIRONMENT_REPORT.json
printf '%s\n' 'Environment checks passed; GPU/data/resume acceptance still required.'
