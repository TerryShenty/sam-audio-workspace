# Start here

Use [README.md](README.md) for the single-server engineering command,
[HARDWARE.md](HARDWARE.md) for supported options and actual hardware evidence,
and [MULTINODE.md](MULTINODE.md) for the separate prepared-input two-server test.
Read [COMMUNICATION.md](COMMUNICATION.md) before paying for a multi-node cluster.
The default uses two GPUs and only three training videos / thirteen prompts,
with all 285 validation examples. It does not start full-corpus production.
Use your own authorized HF and W&B accounts. Never commit credentials.
