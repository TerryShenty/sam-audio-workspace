#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for argument in "$@"; do
  if [[ "$argument" == --gpu-plan ]]; then
    exec "${SAM_PYTHON:-python3}" tools/standalone_workflow.py "$@"
  fi
done
if [[ -n "${SAM_PYTHON:-}" && ! -x "$SAM_PYTHON" ]]; then
  echo "The explicitly selected SAM_PYTHON is not executable." >&2
  exit 1
fi
if [[ -x "${SAM_PYTHON:-$PWD/.venv/bin/python}" ]]; then
  export SAM_ENVIRONMENT_REUSED=1
else
  unset SAM_ENVIRONMENT_REUSED
fi
if [[ ! -x "${SAM_PYTHON:-$PWD/.venv/bin/python}" ]]; then
  if [[ -n "${SLURM_JOB_GPUS:-}${SLURM_STEP_GPUS:-}" ]]; then
    echo "Run environment installation and preparation on CPU resources first." >&2
    exit 1
  fi
  bash setup.sh
fi
source tools/media_env.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
exec "${SAM_PYTHON:-$PWD/.venv/bin/python}" tools/standalone_workflow.py "$@"
