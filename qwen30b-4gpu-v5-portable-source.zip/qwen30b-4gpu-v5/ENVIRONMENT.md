# Environment and external dependencies

Use Linux x86_64, Python 3.12 and a site-supported NVIDIA CUDA driver. A C++ compiler is needed on CPU resources to build the four included ATen extensions. Install a mutually compatible PyTorch, torchvision, torchaudio, TorchCodec and Triton stack first, then `python -m pip install -r requirements-runtime.txt`.

Observed original environment metadata (not a fresh-install compatibility guarantee): torch 2.13.0, torchvision 0.28.0, torchaudio 2.11.0, torchcodec 0.16.0, triton 3.7.1, dacvae 1.0.0, imagebind 0.1.0. The mixed audio version must be checked with actual imports/decoding on the destination. The new environment has not been GPU-tested; do not treat this file as a complete binary lock.

The included SAM source also imports these upstream packages. Install them using their official projects and preserve their licenses:
- https://github.com/facebookresearch/dacvae
- https://github.com/facebookresearch/ImageBind
- https://github.com/facebookresearch/perception_models (the original SAM dependency used the `unpin-deps` branch; supplies `core`)
- https://github.com/lematt1991/CLAP (supplies `laion_clap`)

FFmpeg shared libraries compatible with TorchCodec and `ffmpeg` on PATH are required for waveform decoding/scoring. Use your cluster's modules or user environment. No system changes or privileged install are required by these scripts. Network/model/data transfer and compilation belong on CPU/transfer facilities, never the four-GPU allocation. Do not commit authentication tokens, local_paths.json or CPU_READY.json.

`prepare.py` builds native extensions locally before any GPU work; copied binaries from the original machine are intentionally excluded. The full package uses its bundled modified `sam_audio`, not an unrelated pip version. All source/ABI/environment changes require repeating affected qualification and creating fresh source bindings.
