"""Standalone cached BF16 training. GPU validation still required before release."""
import argparse,json,os,random,time
from pathlib import Path
from types import SimpleNamespace
from datetime import timedelta
import torch
import torch.distributed as dist
from sam_audio import SAMAudio
from sam_audio.native_finetuning import delivery_impl as impl
from sam_audio.native_finetuning.model import configure_native_tuning,native_tuning_config_from_mapping
from sam_audio.native_finetuning.feature_cache import ComponentStore
from sam_audio.native_finetuning.optimized_utils import StageTimer
from delivery_tracking import Tracker
from delivery_validation import evaluate
class BudgetStop(Exception):pass

def main():
    a=argparse.ArgumentParser();a.add_argument('--config',required=True);a.add_argument('--data-root',required=True);a.add_argument('--model',required=True);a.add_argument('--output',required=True);a.add_argument('--epochs',type=int);a.add_argument('--microbatch',type=int,default=8);a.add_argument('--global-batch',type=int,default=32);a.add_argument('--resume');a.add_argument('--max-steps',type=int);a.add_argument('--hours',type=float);a.add_argument('--compile',action='store_true');o=a.parse_args()
    rank=int(os.environ['LOCAL_RANK']);world=int(os.environ['WORLD_SIZE'])
    if o.microbatch<1 or o.global_batch%(o.microbatch*world):raise ValueError('Global batch must be divisible by microbatch * GPUs')
    root=Path(o.data_root).resolve();out=Path(o.output).resolve()
    if not o.resume and (out/'effective-config.json').exists():raise ValueError('Existing run: use explicit resume or a fresh output directory')
    out.mkdir(parents=True,exist_ok=True)
    bundle=json.loads((root/'bundle.json').read_text())
    if bundle.get('status')!='VERIFIED_EXPORT':raise ValueError('Data export not verified')
    cat=json.loads((root/bundle['train_catalog']).read_text());cfg=json.loads(Path(o.config).read_text())
    cfg.update(model_local_path=str(Path(o.model).resolve()),output_dir=str(out),resume_from=o.resume,batch_size=o.microbatch,gradient_accumulation_steps=o.global_batch//(o.microbatch*world),world_size=world,effective_batch_size=o.global_batch,max_steps=o.max_steps,compile=False)
    if o.epochs:cfg['num_epochs']=o.epochs
    if o.max_steps:cfg.update(save_every=1,training_probe_max_targets=0)
    torch.cuda.set_device(rank);device=torch.device('cuda',rank);torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.benchmark=False
    torch.use_deterministic_algorithms(True);dist.init_process_group('nccl',timeout=timedelta(minutes=15))
    random.seed(cfg['seed']);torch.manual_seed(cfg['seed'])
    tracker=Tracker(out,cfg,rank)
    sam=SAMAudio.from_pretrained(cfg['model_local_path'],visual_ranker=None,text_ranker=None,span_predictor=None,strict=True).to(device=device,dtype=torch.bfloat16).requires_grad_(False).eval()
    torch.manual_seed(314159);tuning=configure_native_tuning(sam,native_tuning_config_from_mapping(cfg));codec=sam.audio_codec.cpu()
    impl.release_frozen_encoders(sam);impl.release_frozen_encoders=lambda *_:None
    originals=[b.forward for b in sam.transformer.layers]
    if o.compile:
        for b in sam.transformer.layers:b.forward=torch.compile(b.forward,dynamic=True,options={'triton.cudagraphs':False})
    wrapper=impl.CachedFlowModel(sam,cfg['sigma_min']);store=ComponentStore(root/bundle['train_components'],cat['signature'],lru_entries=16)
    wrapper.delivery_metric_callback=tracker.log
    deadline=time.monotonic()+o.hours*3600-300 if o.hours else float('inf')
    save_original=impl.save_checkpoint
    def save(path,*args,**kw):
        save_original(path,*args,**kw);dist.barrier()
        if Path(path).stem.startswith(('epoch-','half-')) or Path(path).stem=='final':
            active=[b.forward for b in sam.transformer.layers]
            try:
                for b,f in zip(sam.transformer.layers,originals):b.forward=f
                evaluate(sam,codec,root/bundle['validation_manifest'],root,out/'validation'/Path(path).stem,rank,world,tracker)
            finally:
                for b,f in zip(sam.transformer.layers,active):b.forward=f
        if time.monotonic()>=deadline:raise BudgetStop()
    impl.save_checkpoint=save
    if rank==0:(out/'effective-config.json').write_text(json.dumps(cfg,indent=2))
    status='COMPLETE'
    try:
        impl.run_training(cfg,mode='train',feature_mode='cached',wrapper=wrapper,extractor=SimpleNamespace(timer=StageTimer(device)),catalog=cat,store=store,native_dataset=None,tuning=tuning,output=out,device=device,dtype=torch.bfloat16,rank=rank,world=world)
    except BudgetStop:status='CHECKPOINTED'
    finally:tracker.finish();dist.destroy_process_group()
    if rank==0:(out/'RESULT.json').write_text(json.dumps({'status':status}))
if __name__=='__main__':main()
