"""Explicit upload of completed score files and user-selected checkpoint; no dataset upload."""
import argparse,os,json
from pathlib import Path

def main():
    a=argparse.ArgumentParser();a.add_argument('--run-dir',required=True);a.add_argument('--checkpoint',required=True);o=a.parse_args();root=Path(o.run_dir).resolve();p=(root/o.checkpoint).resolve()
    if not p.is_relative_to(root) or not p.is_file():raise ValueError('Checkpoint must be a file within run directory')
    import wandb
    run=wandb.init(project=os.environ.get('WANDB_PROJECT','sam-audio'),entity=os.environ.get('WANDB_ENTITY') or None,job_type='upload-results')
    artifact=wandb.Artifact('solos-checkpoint-'+run.id,type='model');artifact.add_file(str(p),name=p.name)
    for f in root.glob('validation/*/summary.json'):artifact.add_file(str(f),name=str(f.relative_to(root)))
    logged=run.log_artifact(artifact);logged.wait()
    (root/'UPLOAD_RECEIPT.json').write_text(json.dumps({'artifact':logged.qualified_name,'run_url':run.url,'checkpoint':p.name},indent=2));run.finish()
if __name__=='__main__':main()
