"""Bounded CPU decoder test, independent of a dataset or GPU allocation."""
import subprocess
import tempfile
from pathlib import Path


def probe():
    import decord
    import numpy as np

    with tempfile.TemporaryDirectory(prefix='sam-decoder-') as directory:
        path = Path(directory) / 'fixture.mp4'
        subprocess.run([
            'ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
            '-f', 'lavfi', '-i', 'testsrc=size=64x64:rate=5',
            '-t', '1', '-threads', '1', '-pix_fmt', 'yuv420p', str(path),
        ], check=True, capture_output=True, timeout=30)
        reader = decord.VideoReader(str(path), ctx=decord.cpu(0), num_threads=1)
        if len(reader) != 5:
            raise ValueError(f'Expected 5 decoded frames, got {len(reader)}')
        frames = reader.get_batch([0, 4]).asnumpy()
        if frames.shape != (2, 64, 64, 3) or frames.dtype != np.uint8:
            raise ValueError(f'Invalid decoded frame shape/dtype: {frames.shape}/{frames.dtype}')
        if np.array_equal(frames[0], frames[1]) or int(frames.max()) == int(frames.min()):
            raise ValueError('Decoded fixture lost its temporal or spatial variation')
        return {'status': 'PASS', 'device': 'cpu', 'frames': len(reader),
                'batch_shape': list(frames.shape), 'scope': 'synthetic H264 fixture only'}
