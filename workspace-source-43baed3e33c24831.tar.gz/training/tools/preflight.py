import argparse,json,subprocess,sys,platform,importlib.metadata,importlib,shutil
from pathlib import Path
from data_manifest import verify,path_in
from bundle_contract import validate_links

def main():
    a=argparse.ArgumentParser();a.add_argument('--data-root');a.add_argument('--manifest');a.add_argument('--gpu',action='store_true');a.add_argument('--output',default='preflight.json');o=a.parse_args();r={'python':sys.version,'platform':platform.platform(),'checks':{},'errors':[]}
    p=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);r['checks']['pip_check']=p.stdout+p.stderr
    if p.returncode:r['errors'].append('pip check failed')
    for name in ['torch','torchaudio','torchvision','torchcodec','triton','transformers','numpy','wandb']:
        try:r['checks'][name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:r['errors'].append('Missing '+name)
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
    for module in ['torch', 'torchaudio', 'torchvision', 'torchcodec', 'decord', 'peft', 'accelerate', 'sam_audio', 'train_delivery', 'delivery_validation', 'delivery_tracking']:
        try:
            importlib.import_module(module);r['checks']['import:'+module]='PASS'
        except Exception as exc:r['errors'].append('Import '+module+': '+str(exc))
    for tool in ['git','ffmpeg']:
        try:
            q=subprocess.run([tool,'--version' if tool=='git' else '-version'],capture_output=True,text=True,timeout=15)
            if q.returncode: raise RuntimeError('exit '+str(q.returncode))
            r['checks'][tool]=(q.stdout or q.stderr).splitlines()[0]
        except Exception as exc:r['errors'].append(tool+': '+str(exc))
    try:
        from decoder_probe import probe
        r['checks']['decoder_fixture']=probe()
    except Exception as exc:r['errors'].append('Decoder fixture: '+str(exc))
    if o.data_root:
        try:
            root=Path(o.data_root);bundle=json.loads((root/'bundle.json').read_text());assert bundle['status']=='VERIFIED_EXPORT'
            for name in ('train_catalog','validation_manifest','train_components'):assert path_in(root,bundle[name]).exists()
            if not o.manifest:raise ValueError('Full file manifest required')
            manifest=json.loads(Path(o.manifest).read_text())
            r['checks']['verified_files']=verify(root,manifest)
            r['checks']['bundle_links']=validate_links(root,bundle,[f['path'] for f in manifest['files']])
        except Exception as exc:r['errors'].append('Data: '+str(exc))
    if o.gpu:
        try:
            import torch
            assert torch.cuda.is_available(),'CUDA unavailable'
            r['checks']['cuda']=torch.version.cuda
            r['checks']['gpus']=[{'name':torch.cuda.get_device_name(i),'bytes':torch.cuda.get_device_properties(i).total_memory} for i in range(torch.cuda.device_count())]
            # Only run --gpu inside an authorized GPU allocation.
            for i in range(torch.cuda.device_count()):
                x=torch.randn(64,64,device=f'cuda:{i}',requires_grad=True);loss=(x@x).square().mean();loss.backward();assert torch.isfinite(x.grad).all()
        except Exception as exc:r['errors'].append('GPU: '+str(exc))
    r['status']='PASS' if not r['errors'] else 'FAIL';Path(o.output).write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));return bool(r['errors'])
if __name__=='__main__':sys.exit(main())
