"""Rank-zero optional tracking; local JSONL remains authoritative."""
import json,os,warnings
from pathlib import Path
class Tracker:
    def __init__(self,out,config,rank):
        self.run=None;self.out=Path(out);self.rank=rank
        if rank or os.environ.get('WANDB_MODE','disabled')=='disabled':return
        try:
            import wandb
            p=self.out/'wandb-run-id.txt'
            run_id=p.read_text().strip() if p.exists() else wandb.util.generate_id()
            p.write_text(run_id+'\n')
            self.run=wandb.init(project=os.environ.get('WANDB_PROJECT','sam-audio'),entity=os.environ.get('WANDB_ENTITY') or None,id=run_id,resume='allow',config=config,dir=str(out))
        except Exception as exc:warnings.warn('W&B unavailable; local logging retained: '+type(exc).__name__)
    def log(self,value):
        if self.rank:return
        with (self.out/'tracking.jsonl').open('a') as f:f.write(json.dumps(value,allow_nan=False)+'\n')
        if self.run:
            try:self.run.log(value)
            except Exception as exc:warnings.warn('W&B log failed: '+type(exc).__name__)
    def finish(self, exit_code=0):
        if self.run:self.run.finish(exit_code=exit_code)
