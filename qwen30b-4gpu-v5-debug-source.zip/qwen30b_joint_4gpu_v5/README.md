# Qwen30B + SAM Audio four-GPU V5 debugging code

This is a narrowly scoped early code handoff requested for colleague debugging, **not a runnable standalone release**. It contains the current four-rank orchestration, joint trainer/checkpoint/validation modules and19 V5 kernel/policy modules. Broad historical research code, tests, deployment receipts, original internal paths, credentials, binary extensions, model weights and data are omitted. Some imports refer to that omitted dependency tree; dependency packaging and portable environment setup remain unfinished.

## Entry points
`source/qualification_entry.py` is the four-rank qualification entry; `qualification_run.py` handles full-state restoration checks. `production_runtime.py` and `deployment_guard.py` enforce selected feature activation. `joint_ddp.py`, `distributed_trainer.py` and `joint_checkpoint.py` cover training/synchronization/state. `joint_validation.py` generates audio from cached inputs; `validation_scoring.py` requires original validation mixture and GT waveforms. `session_parent.py` supervises a fixed scheduler allocation. V5 kernels are under `source/upstream_v2/dual_model_research_20261026/nf4_word8_attention_30b_v1/`.

## Evidence and limits
Four ranks/batch2 per rank/global8, trainable causal AUDSEG bridge, Qwen q/v LoRA8 and SAM trainable groups. V5 uses word8 NF4 decode+attention-forward INT8, preserving production long-input B2<=2048/SAM256/nativeRMS fixes. Effective config is supplied separately. CPU tiny48HF/T1640/eight updates passed; real four-L40S updates, memory, complete effective resume and817 validation remain pending. Formal24h training has not started.

Single-A10040GB/global2/fixed64 research mean0.841817s/update is not a four-GPU or other-hardware promise. V5 paired mean gain0.159848% had one positive and one negative pair; no robust universal gain or new historical absolute record is claimed.

## Portability/debugging work
Neutral /YOUR_WORKSPACE, /YOUR_HOME, /YOUR_SITE_PATH and /YOUR_SOURCE placeholders replace original site paths. Reconcile all imports, provide dependency source and matching PyTorch/Triton/CUDA/native ABI, build native extensions on CPU and generate new local source/native/model/data/validation bindings before launch. Do not remove safety/hash checks to bypass missing dependencies. Existing hash literals are historical, not a seal for this edited export.

Data upload is pending:111068training+817validation rows, Prompt/GT/split mapping, Qwen processor/AV cache, SAM mixture/video/clean cache, original validation mixture+GT waveforms. Raw videos are not required by the cached validation path. Download official model weights with your own approved HF access. No weights/data or working download command is claimed here.

Do not use the root repository SOLOs quickstart for this distinct Qwen task. Use four persistent processes in one authorized allocation; CPU/download preparation stays offGPU. Validate full model/optimizer/scheduler/EMA/allrank RNG/data/config save/restore before a long run. Never blindly execute site-specific submission logic. Original queued sources remain unchanged. Third-party code retains applicable upstream licenses; no additional rights to models/data are granted.

## Export cleanup
The unused bp_research candidate-search module and automatic communication_screen invocation were removed from this export. Accepted acceleration kernels remain because training uses them. Runtime timing/memory diagnostics and checkpoint restoration checks remain; no optimization sweep or speed-comparison runner is included. The original queued cluster code was not changed. This export is syntax-checked only and still requires missing dependencies and portable launch/config work.
