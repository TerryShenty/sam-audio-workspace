"""Own source bundle, original pretrained assets, and this task's real inputs."""
import hashlib,json,sys
from pathlib import Path
R=Path('/YOUR_WORKSPACE/qwen30b')
H=Path('/YOUR_WORKSPACE/qwen-runtime')
V=R/'production_v5_word8';U=V/'upstream_v2'

def install():
    sys.path[:0]=[str(V),str(U/'dual_model_research_20261026/nf4_word8_attention_30b_v1'),str(H/'deps_v1'),str(U),str(U/'runtime_v1'),str(U/'runtime_v1/code'),str(U/'runtime_v1/perf')]
    receipt=json.loads((R/'PRODUCTION_MODEL_METADATA.json').read_text())
    for name,digest in receipt['files'].items():
        assert hashlib.sha256((V/'model_metadata'/name).read_bytes()).hexdigest()==digest
    import common
    assert Path(common.__file__).resolve().is_relative_to(U)
    original_read=common.read
    def read(p):
        p=Path(p)
        if p.parent==R and p.name in receipt['files']:p=V/'model_metadata'/p.name
        elif p==R/'media.json':p=R/'MEDIA.json'
        if 'solos_scaling8_20261010' in str(p):raise RuntimeError('Historical benchmark inputs forbidden')
        return original_read(p)
    common.HERE=R;common.ROOT=H.parent;common.read=read
    import bridge
    assert Path(bridge.__file__).resolve().is_relative_to(U)
    bridge.HERE=R;bridge.ROOT=H.parent;bridge.read=read
    return bridge

def resolved_sources():
    result={}
    for name,module in list(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if path:
            if (name,path) in {('torch.ops','_ops.py'),('torch.classes','_classes.py')}:continue
            p=Path(path).resolve()
            if p.is_relative_to(H) and not p.is_relative_to(H/'deps_v1'):
                raise RuntimeError('Research source import escaped isolation: '+str(p))
            if p.suffix=='.py' and p.is_relative_to(V):
                result[name]=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    return result
