"""One fixed allocation; validated repair commands only, never blind restarts."""
import argparse, fcntl, hashlib, json, os, signal, subprocess, time
from pathlib import Path

def read(p):return json.loads(Path(p).read_text())
def write(p,x):
    p=Path(p);t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(p)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def validate(command, root, allocation, now):
    assert command['job_id']==allocation['job_id']
    assert command['end_epoch']==allocation['end_epoch'], 'Deadline cannot change'
    assert now<allocation['worker_stop_epoch'], 'No time for another worker'
    assert command['world_size']==4 and command['baseline_contract_sha256']==allocation['baseline_contract_sha256']
    assert command['cpu_checks']=='PASS' and command['argv'] and isinstance(command['argv'],list)
    assert all(isinstance(a,str) for a in command['argv'])
    assert command['argv'][0]=='srun' and '--ntasks=1' in command['argv']
    assert '--gpus=4' in command['argv'] and '--kill-on-bad-exit=1' in command['argv']
    assert 'torch.distributed.run' in command['argv'] and '--nproc_per_node=4' in command['argv']
    for p,h in command['source_seal'].items():
        path=Path(p).resolve();assert path.is_relative_to(root.resolve())
        assert digest(path)==h, str(path)
    if command['sequence'] and not command.get('diagnosed_fresh_qualification',False):
        assert command['previous_steps_terminal'] is True
        assert command['diagnosis'] and command['resume_manifest']
        manifest=Path(command['resume_manifest']);assert digest(manifest)==command['resume_manifest_sha256']
        assert read(manifest)['complete'] is True
    if command.get('diagnosed_fresh_qualification',False):
        assert allocation['qualification_only'] is True
        assert command['previous_steps_terminal'] is True and command['diagnosis']
        assert command['initialization']=='original_pretrained_fresh_adapters'
        assert command['production_state_discarded'] is False
    return command['argv']

BASELINE_SHA='b5be101056bf5c35225fb957f8b53ec2a28bf7c2ff0559400b3f9137b1aa375a'
def accepted_contract(root):
    value=digest(root/'production_v5_word8/QWEN_SAM_FAST_BASELINE_V5.json')
    assert value==BASELINE_SHA,'UNACCEPTED_PRODUCTION_BASELINE'
    return value

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--expected-seconds',type=int,choices=(3600,86400),required=True)
    parser.add_argument('--template',type=Path,required=True)
    parser.add_argument('--sha256',required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent.parent
    contract_sha=accepted_contract(root)
    lock=open(root/'allocation.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    job=os.environ['SLURM_JOB_ID']
    live=json.loads(subprocess.check_output(['scontrol','show','job',job,'--json']))['jobs'][0]
    start=live['start_time'];end=live['end_time']
    if isinstance(start,dict):start=start['number']
    if isinstance(end,dict):end=end['number']
    assert end-start==args.expected_seconds,'Original scheduler window differs from sealed request'
    state=root/'supervisor_runs'/job;state.mkdir(parents=True,exist_ok=False)
    (state/'inbox').mkdir()
    allocation=dict(job_id=job,start_epoch=start,end_epoch=end,worker_stop_epoch=end-600,qualification_only=args.expected_seconds==3600,
                    baseline_contract_sha256=contract_sha)
    write(state/'ALLOCATION.json',allocation)
    assert digest(args.template)==args.sha256
    template=read(args.template)
    assert template['qualification_only'] and template['requested_resources']['seconds']==args.expected_seconds==3600
    for path,sha in template['source_files'].items():assert digest(path)==sha
    output=root/'qualification_runs'/job;output.mkdir(parents=True,exist_ok=False)
    write(output/'SLURM_START.json',live)
    template.update(job_id=job,end_epoch=end,output=str(output))
    plan=output/'PLAN.json';write(plan,template)
    os.environ['SLURM_JOB_END_TIME']=str(end)
    import sys
    command=dict(job_id=job,end_epoch=end,world_size=4,sequence=0,
        baseline_contract_sha256=contract_sha,cpu_checks='PASS',source_seal=template['source_files'],
        argv=['srun','--ntasks=1','--gpus=4','--kill-on-bad-exit=1',sys.executable,'-u','-m',
              'torch.distributed.run','--standalone','--nproc_per_node=4','--max-restarts=0',
              str(Path(__file__).parent/'qualification_entry.py'),'--plan',str(plan),'--plan-sha256',digest(plan)])
    write(state/'inbox'/'0000.json',command)
    index=0;failed_at=None
    while time.time()<end-120:
        request=state/'inbox'/f'{index:04d}.json'
        if not request.exists():
            # Temporary retention is for active diagnosis, never an infinite idle lease.
            if failed_at and time.time()-failed_at>600:
                write(state/'SUPERVISOR_STOP.json',dict(reason='repair_wait_expired',time=time.time(),job_id=job));return
            if not failed_at and index==0 and time.time()-start>180:
                raise RuntimeError('Initial sealed worker command missing')
            time.sleep(5);continue
        command=read(request);assert command['sequence']==index
        argv=validate(command,root,allocation,time.time())
        write(state/f'WORKER_{index:04d}_INTENT.json',dict(command=command,time=time.time()))
        with open(state/f'worker-{index:04d}.log','ab',buffering=0) as log:
            p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            write(state/f'WORKER_{index:04d}_STARTED.json',dict(pid=p.pid,time=time.time()))
            while p.poll() is None:
                if time.time()>=end-180:
                    os.killpg(p.pid,signal.SIGTERM)
                    try:p.wait(timeout=60)
                    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
                    break
                time.sleep(5)
        rc=p.returncode
        # Never recycle a failed command. The next sealed inbox sequence is explicit.
        # A successful child also returns control here for optional prepared work.
        write(state/f'WORKER_{index:04d}_EXIT.json',dict(returncode=rc,time=time.time()))
        if rc==0 and (output/'CHECK_COMPLETE.json').exists():
            write(state/'SUPERVISOR_STOP.json',dict(reason='all_prepared_checks_finished',time=time.time(),job_id=job))
            return
        if rc==0 and (root/'TIMEBOX_REPORT.json').exists():
            report=read(root/'TIMEBOX_REPORT.json')
            if report.get('status')=='COMPLETE_FIXED_TIMEBOX':return
        failed_at=time.time();index+=1
        write(state/'REPAIR_REQUIRED.json',dict(previous_sequence=index-1,returncode=rc,time=failed_at,
              original_end_epoch=end,next_sequence=index,retention_deadline=min(end-180,failed_at+600)))

if __name__=='__main__':main()
