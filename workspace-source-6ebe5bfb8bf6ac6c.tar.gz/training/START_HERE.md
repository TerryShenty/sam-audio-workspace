Start with README.md, then FAST_PROFILE.md for the fastest accepted recipe.
