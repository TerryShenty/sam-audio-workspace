"""Explicit single-node GPU plans. No hardware probe or Torch import on import."""
import math
import os


def profile(gpus=2, global_batch=None, microbatch=1, performance_profile="bf16"):
    if type(gpus) is not int or not 1 <= gpus <= 8:
        raise ValueError("Choose 1–8 GPUs on one node; larger hosts may expose a subset")
    if microbatch not in (1, 2, 4) or type(microbatch) is not int:
        raise ValueError("The 13-row engineering entry accepts microbatch 1, 2 or 4; larger datasets use the training CLI")
    if performance_profile not in ("bf16", "solos-fast-v1"):
        raise ValueError("Unknown performance profile")
    width = gpus * microbatch
    batch = max(2, width) if global_batch is None else global_batch
    if type(batch) is not int or batch < width or batch % width:
        raise ValueError("Global batch must be a positive multiple of microbatch * selected GPUs")
    # Frozen public selection: ten 10s rows and three 20s rows. Match exact-length
    # local microbatches, rank padding and final partial accumulation.
    accumulation = batch // width
    local_batches = math.ceil(10 / microbatch) + math.ceil(3 / microbatch)
    updates = math.ceil(math.ceil(local_batches / gpus) / accumulation)
    return dict(gpus=gpus, microbatch=microbatch, global_batch=batch, performance_profile=performance_profile,
                accumulation=accumulation, updates_per_epoch=updates,
                epochs=math.ceil(9 / updates), max_steps=9,
                training_encoder_gpus=min(gpus, 3), validation_encoder_gpus=gpus,
                training_gpus=gpus, nodes=1,
                hardware_acceptance="TWO_A100_REFERENCE_ONLY_OTHER_COUNTS_NOT_GPU_TESTED")


def check_inventory(devices, required, environment=None):
    """Respect CUDA visibility and reject unsupported setup before worker launch.

    22 GiB reported capacity allows nominal 24 GB cards with driver reservations.
    This is a conservative entry policy for the tested 10/20s BF16 profile,
    not a guarantee against OOM or an assertion about longer inputs.
    """
    env = os.environ if environment is None else environment
    if type(required) is not int or not 1 <= required <= 8:
        raise ValueError("Invalid requested GPU count")
    if int(env.get("SLURM_JOB_NUM_NODES", "1")) != 1:
        raise ValueError("This entry supports one node; multi-node rendezvous is not implemented")
    if any(name in env for name in ("LOCAL_RANK", "RANK", "WORLD_SIZE")):
        raise ValueError("Run the entry once, not inside another torchrun process")
    if len(devices) < required:
        raise ValueError(f"Need {required} visible CUDA GPUs, found {len(devices)}; check CUDA_VISIBLE_DEVICES")
    if (env.get("SLURM_JOB_GPUS") or env.get("SLURM_STEP_GPUS")) and len(devices) != required:
        raise ValueError(f"This phase uses {required} GPUs; request exactly that many in its GPU allocation")
    selected = devices[:required]
    if len({d["uuid"] for d in selected}) != required:
        raise ValueError("Selected CUDA devices must have distinct UUIDs")
    if any(not d["bf16"] or d["memory_bytes"] < 22 * 1024**3 for d in selected):
        raise ValueError("This BF16 engineering profile requires BF16 support and at least 22 GiB reported capacity per GPU (nominal 24 GB class)")
    if any(str(d["uuid"]).startswith("MIG-") or "MIG" in d["name"] for d in selected):
        raise ValueError("MIG partitions are not accepted by this workflow")
    if len({(d["name"], tuple(d["capability"]), d["memory_bytes"]) for d in selected}) != 1:
        raise ValueError("Select a homogeneous GPU subset; mixed devices are not accepted")
    return dict(selected=selected, selected_count=required,
                visible_count=len(devices), unused_visible_count=len(devices)-required,
                memory_policy_gib=22, memory_policy_is_oom_guarantee=False)


def probe(required):
    import torch
    devices = []
    for index in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(index)
        # Query properties only; don't allocate a CUDA context on unused GPUs.
        bf16 = torch.version.cuda is not None and p.major >= 8
        devices.append(dict(logical_index=index, uuid=str(p.uuid), name=p.name,
                            memory_bytes=p.total_memory,
                            capability=[p.major, p.minor], bf16=bf16))
    return check_inventory(devices, required)


def receipts(reports, gpus, microbatch=1):
    if (len(reports) != gpus or {r.get("rank") for r in reports} != set(range(gpus))
            or len({r.get("gpu_uuid") for r in reports}) != gpus
            or not all(r.get("gpu_uuid") for r in reports)):
        raise ValueError("Missing/duplicate rank or GPU receipt")
    for r in reports:
        if (r.get("world_size") != gpus or r.get("status") != "PASS"
                or not r.get("updates") or not r.get("forwards")
                or any(u["after"] != u["before"]+1 or not math.isfinite(u["delta"])
                       or u["delta"] <= 0 for u in r["updates"])
                or any(f.get("batch", 1) != microbatch or type(f.get("batch", 1)) is not int or f.get("batch", 1) < 1
                       or f.get("finite") is not True or f.get("positives") != 250 * f.get("batch", 1)
                       or f.get("per_example_positives", [250]) != [250] * f.get("batch", 1)
                       for f in r["forwards"])):
            raise ValueError("Every selected rank must perform real finite training")
    sequences = [[(u["before"], u["after"]) for u in r["updates"]] for r in reports]
    if any(v != sequences[0] for v in sequences[1:]):
        raise ValueError("Rank optimizer positions disagree")
