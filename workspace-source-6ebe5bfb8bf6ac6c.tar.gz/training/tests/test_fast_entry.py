import ast,copy,json,math,random,subprocess,sys,unittest
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'));sys.path.insert(0,str(ROOT/'src'))
import gpu_profile as gp
import public_entry as entry
from delivery_acceleration import configure

class FastEntryTests(unittest.TestCase):
 def test_exact_length_plan_for_real_public_selection(self):
  tree=ast.parse((ROOT/'src/sam_audio/native_finetuning/optimized_utils.py').read_text())
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='LengthBucketPlan')
  env=dict(math=math,random=random,Counter=Counter,defaultdict=defaultdict)
  exec(compile(ast.Module(body=[cls],type_ignores=[]),'actual-sampler','exec'),env)
  for world in range(1,9):
   for micro in [1,2,4]:
    for accum in [1,2,4]:
     shape=gp.profile(world,world*micro*accum,micro,'solos-fast-v1');real=[]
     for rank in range(world):
      p=env['LengthBucketPlan']([500]*3+[250]*10,world_size=world,rank=rank,micro_batch=micro,accumulation=accum,seed=2026,exact_lengths=True)
      self.assertEqual(p.updates_per_epoch,shape['updates_per_epoch'])
      real.extend(s[1] for batch in p for s in batch if s[2])
     self.assertEqual(sorted(real),list(range(13)))
     self.assertGreaterEqual(shape['epochs']*shape['updates_per_epoch'],9)
 def test_cli_command_carries_fast_profile_and_batch(self):
  req=dict(gpus=2,global_batch=16,microbatch=4,performance_profile='solos-fast-v1',training_config='/tmp/cfg',data_root='/tmp/data',model='/tmp/model',directory='/tmp/output')
  cmd=entry.command(req)
  self.assertEqual(cmd[cmd.index('--microbatch')+1],'4')
  self.assertEqual(cmd[cmd.index('--performance-profile')+1],'solos-fast-v1')
  self.assertEqual(cmd[cmd.index('--global-batch')+1],'16')
  self.assertEqual(cmd[cmd.index('--epochs')+1],str(gp.profile(2,16,4)['epochs']))
 def test_profile_cpu_plan_zero_is_rejected(self):
  for micro in [0,-1,3,8,16,True]:
   with self.assertRaises(ValueError):gp.profile(2,16,micro)
  with self.assertRaises(ValueError):gp.profile(2,3,2)
  with self.assertRaises(ValueError):gp.profile(2,16,4,'unknown')
 def test_plan_cli_without_gpu_or_model(self):
  r=subprocess.run([sys.executable,str(ROOT/'tools/standalone_workflow.py'),'--gpu-plan','--gpus','2','--microbatch','4','--global-batch','16','--performance-profile','solos-fast-v1'],capture_output=True,text=True)
  self.assertEqual(r.returncode,0,r.stderr);v=json.loads(r.stdout);self.assertEqual(v['microbatch'],4);self.assertEqual(v['performance_profile'],'solos-fast-v1')
  r=subprocess.run([sys.executable,str(ROOT/'tools/standalone_workflow.py'),'--gpu-plan','--microbatch','0'],capture_output=True,text=True)
  self.assertNotEqual(r.returncode,0)
 def test_per_example_receipts_reject_compensating_invalid_support(self):
  r=dict(rank=0,gpu_uuid='GPU-test',world_size=1,status='PASS',updates=[dict(before=0,after=1,delta=1e-5)],forwards=[dict(finite=True,positives=1000,batch=4,per_example_positives=[250]*4)])
  gp.receipts([r],1,4)
  for bad in [[0,500,250,250],[250,250,250],None]:
   x=copy.deepcopy(r);x['forwards'][0]['per_example_positives']=bad
   with self.assertRaises(ValueError):gp.receipts([x],1,4)
  with self.assertRaises(ValueError):gp.receipts([r],1,1)
 def test_fast_config_identity_and_bf16_fallback(self):
  base=json.loads((ROOT/'configs/engineering-public.json').read_text());old=copy.deepcopy(base)
  configure(base,'bf16');self.assertEqual(base,old)
  configure(base,'solos-fast-v1');self.assertTrue(base['max_autotune_gemm']);self.assertTrue(base['frozen_linear_int8']);self.assertEqual(base['validation_precision'],'original-bf16')

if __name__=='__main__':unittest.main()
