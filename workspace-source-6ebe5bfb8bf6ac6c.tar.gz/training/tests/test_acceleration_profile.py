import ast
import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch
from types import ModuleType, SimpleNamespace
import sys

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("acceleration", ROOT/"src/delivery_acceleration.py")
acc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(acc)


class ProfileTests(unittest.TestCase):
    def test_legacy_config_unchanged(self):
        config = {"seed": 2026}
        acc.configure(config, acc.BASE)
        self.assertEqual(config, {"seed": 2026})
        acc.check_resume_profile(config, {"seed": 2026})

    def test_fast_recipe_exact(self):
        config = {"seed": 2026}
        acc.configure(config, acc.FAST)
        self.assertTrue(config["max_autotune_gemm"])
        self.assertFalse(config["deterministic"])
        self.assertEqual(config["int8_recipe"], "solos-fused-rowquant-64x128x128-v1")
        self.assertEqual(config["validation_precision"], "original-bf16")
        acc.check_resume_profile(config, copy.deepcopy(config))

    def test_profile_switch_resume_refused(self):
        config = {}
        acc.configure(config, acc.FAST)
        for current, saved in [(config, {}), ({}, config)]:
            with self.assertRaisesRegex(ValueError, "profile changed"):
                acc.check_resume_profile(current, saved)

    def test_every_fast_setting_strict(self):
        config = {}
        acc.configure(config, acc.FAST)
        for key in set(config) - {"performance_profile"}:
            with self.subTest(key=key):
                saved = dict(config)
                saved.pop(key)
                with self.assertRaises(ValueError):
                    acc.check_resume_profile(config, saved)

    def test_unknown_and_conflicting_profile(self):
        for config, profile in [({}, "unknown"), ({"performance_profile": acc.FAST}, acc.BASE),
                                ({"performance_profile": acc.BASE}, acc.FAST)]:
            with self.assertRaises(ValueError):
                acc.configure(config, profile)

    def test_actual_entry_and_loader_connected(self):
        entry = ast.parse((ROOT/"src/train_delivery.py").read_text())
        calls = [ast.unparse(n.func) for n in ast.walk(entry) if isinstance(n, ast.Call)]
        self.assertIn("configure_acceleration", calls)
        self.assertIn("Acceleration", calls)
        self.assertIn("acceleration.validation", calls)
        self.assertIn("acceleration.close", calls)
        loader = ast.parse((ROOT/"src/sam_audio/native_finetuning/delivery_impl.py").read_text())
        self.assertTrue(any(isinstance(n, ast.Call) and ast.unparse(n.func) == "check_resume_profile"
                            for n in ast.walk(loader)))

    def test_runtime_restores_validation_and_exception_state(self):
        try:
            import torch
        except ImportError:
            self.skipTest("Real torch CPU test runs in the prepared Linux environment")
        class Norm:
            def forward(self, x):
                return x
        transformer = ModuleType("sam_audio.model.transformer")
        transformer.RMSNorm = Norm
        module = torch.nn.Linear(4, 4).requires_grad_(False)
        original = module.forward
        fast_forward = lambda x: original(x)
        block = SimpleNamespace(forward=lambda x: module(x))
        sam = SimpleNamespace(transformer=SimpleNamespace(layers=[block]))
        original_block = block.forward
        def install(_):
            module.forward = fast_forward
            return [(module, original)]
        fake_int8 = ModuleType("int8_fused_rowquant_linear")
        fake_int8.install = install
        saved_sdpa = torch.nn.functional.scaled_dot_product_attention
        saved_rms = Norm.forward
        saved_determinism = torch.are_deterministic_algorithms_enabled()
        compile_calls = []
        def compile_fn(fn, **kw):
            compile_calls.append(kw)
            return lambda x: fn(x)
        with patch.dict(sys.modules, {"sam_audio.model.transformer": transformer,
                                      "int8_fused_rowquant_linear": fake_int8}), \
                patch.object(torch, "compile", compile_fn):
            runtime = acc.Acceleration(sam, acc.FAST)
            try:
                self.assertFalse(torch.are_deterministic_algorithms_enabled())
                self.assertEqual(compile_calls, [{"dynamic": True, "options": {
                    "triton.cudagraphs": False, "max_autotune_gemm": True}}])
                self.assertEqual(runtime.report["installed_frozen_linears"], 1)
                with self.assertRaisesRegex(RuntimeError, "validation test"):
                    with runtime.validation():
                        self.assertIs(module.forward, original)
                        self.assertIs(block.forward, original_block)
                        self.assertIs(Norm.forward, saved_rms)
                        self.assertIs(torch.nn.functional.scaled_dot_product_attention, saved_sdpa)
                        self.assertTrue(torch.are_deterministic_algorithms_enabled())
                        raise RuntimeError("validation test")
                self.assertIs(module.forward, fast_forward)
                self.assertFalse(torch.are_deterministic_algorithms_enabled())
            finally:
                runtime.close()
            self.assertIs(module.forward, original)
            self.assertIs(block.forward, original_block)
            self.assertIs(Norm.forward, saved_rms)
            self.assertIs(torch.nn.functional.scaled_dot_product_attention, saved_sdpa)
            self.assertEqual(torch.are_deterministic_algorithms_enabled(), saved_determinism)


if __name__ == "__main__":
    unittest.main()
