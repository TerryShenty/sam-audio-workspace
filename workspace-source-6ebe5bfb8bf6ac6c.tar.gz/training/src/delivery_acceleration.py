"""Explicit port of the measured SOLOs frozen-INT8 training recipe.

The three kernel modules are copied byte-for-byte from the accepted experiment.
This module scopes their installation to training and records resume identity.
"""
from contextlib import contextmanager


FAST = "solos-fast-v1"
BASE = "bf16"


def configure(config, profile, *, compiled=False):
    if profile not in (BASE, FAST):
        raise ValueError("Unknown performance profile")
    # Keep legacy BF16 configs byte-compatible unless a new profile is selected.
    if profile == BASE:
        if config.get("performance_profile", BASE) != BASE:
            raise ValueError("Config profile conflicts with requested BF16")
        return
    if config.get("performance_profile", FAST) != FAST:
        raise ValueError("Config profile conflicts with requested SOLOs fast recipe")
    config.update(performance_profile=FAST, deterministic=False,
                  frozen_linear_int8=True, int8_recipe="solos-fused-rowquant-64x128x128-v1",
                  block_compile=True, max_autotune_gemm=True,
                  contiguous_sdpa=True, native_fp32_rms=True,
                  validation_precision="original-bf16")


def check_resume_profile(config, saved):
    current = config.get("performance_profile", BASE)
    previous = saved.get("performance_profile", BASE)
    if current != previous:
        raise ValueError("Resume performance profile changed; start a separate run")
    if current == FAST:
        for key in ("deterministic", "frozen_linear_int8", "int8_recipe", "block_compile",
                    "max_autotune_gemm", "contiguous_sdpa", "native_fp32_rms",
                    "validation_precision"):
            if saved.get(key) != config.get(key):
                raise ValueError(f"Resume acceleration setting changed: {key}")


class Acceleration:
    def __init__(self, sam, profile, compiled=False):
        import torch
        from sam_audio.model.transformer import RMSNorm
        self.torch = torch
        self.rms_class = RMSNorm
        self.blocks = list(sam.transformer.layers)
        self.original_blocks = [b.forward for b in self.blocks]
        self.original_sdpa = torch.nn.functional.scaled_dot_product_attention
        self.original_rms = RMSNorm.forward
        self.original_determinism = torch.are_deterministic_algorithms_enabled()
        self.linears = []
        self.profile = profile
        self.report = dict(profile=profile, installed_frozen_linears=0,
                           approximate_frozen_base=profile == FAST,
                           validation_precision="original-bf16",
                           ddp_initial_sync="unchanged_default")
        try:
            if profile == FAST:
                def contiguous_sdpa(q, k, v, *args, **kwargs):
                    return self.original_sdpa(q.contiguous(), k.contiguous(), v.contiguous(),
                                              *args, **kwargs)

                def native_rms(module, x):
                    return torch.nn.functional.rms_norm(
                        x.float(), (x.shape[-1],), module.weight.float(), eps=module.eps).type_as(x)

                torch.nn.functional.scaled_dot_product_attention = contiguous_sdpa
                RMSNorm.forward = native_rms
                from int8_fused_rowquant_linear import install
                self.linears = install(sam.transformer.layers)
                self.report["installed_frozen_linears"] = len(self.linears)
                torch.use_deterministic_algorithms(False)
                torch._dynamo.config.recompile_limit = 8
            if compiled or profile == FAST:
                options = {"triton.cudagraphs": False}
                if profile == FAST:
                    options["max_autotune_gemm"] = True
                for block, original in zip(self.blocks, self.original_blocks):
                    block.forward = torch.compile(original, dynamic=True, options=options)
            self.active_blocks = [b.forward for b in self.blocks]
            self.active_linears = [(m, m.forward) for m, _ in self.linears]
            self.active_sdpa = torch.nn.functional.scaled_dot_product_attention
            self.active_rms = RMSNorm.forward
        except BaseException:
            self.close()
            raise

    @contextmanager
    def validation(self):
        # Score original BF16 weights with the established validation protocol.
        # Do not silently use approximate frozen INT8 for the heldout metrics.
        self._original_forwards()
        self.torch.use_deterministic_algorithms(True)
        try:
            yield
        finally:
            for block, forward in zip(self.blocks, self.active_blocks):
                block.forward = forward
            for module, forward in self.active_linears:
                module.forward = forward
            self.torch.nn.functional.scaled_dot_product_attention = self.active_sdpa
            self.rms_class.forward = self.active_rms
            self.torch.use_deterministic_algorithms(
                False if self.profile == FAST else self.original_determinism)

    def _original_forwards(self):
        for block, forward in zip(self.blocks, self.original_blocks):
            block.forward = forward
        for module, forward in self.linears:
            module.forward = forward
        self.torch.nn.functional.scaled_dot_product_attention = self.original_sdpa
        self.rms_class.forward = self.original_rms

    def close(self):
        self._original_forwards()
        self.torch.use_deterministic_algorithms(self.original_determinism)
