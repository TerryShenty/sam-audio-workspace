"""Exercise real exporter on tiny file fixtures, not model/tensor certification."""
import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from export_bundle import export
import test_bundle_contract
from data_manifest import verify

class ExportTests(unittest.TestCase):
    def setup_plan(self, root):
        source=root/'source';source.mkdir()
        bundle,names,cat,val=test_bundle_contract.BundleTests().fixture(source)
        audit=root/'audit.json';audit.write_text(json.dumps({'status':'PASS'}))
        plan={'audit':str(audit),'bundle':bundle,'files':[{'source':str(source/n),'destination':n} for n in names]}
        return plan,cat
    def test_actual_export_and_full_file_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);plan,_=self.setup_plan(root);out=root/'out'
            result=export(plan,out)
            self.assertEqual(verify(out,result),len(plan['files'])+1)
            self.assertEqual(json.loads((out/'bundle.json').read_text())['status'],'VERIFIED_EXPORT')
    def test_bad_link_never_certifies(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);plan,cat=self.setup_plan(root);out=root/'out'
            cat['splits']['train']['entries'][0]['variants']=[]
            (root/'source/cat.json').write_text(json.dumps(cat))
            with self.assertRaises(ValueError):export(plan,out)
            self.assertFalse((out/'bundle.json').exists())
            self.assertFalse((out/'manifest.json').exists())
    def test_normalized_collision_rejected_before_copy(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);plan,_=self.setup_plan(root);out=root/'out'
            plan['files'].append({'source':str(root/'source/gt.wav'),'destination':'./gt.wav'})
            with self.assertRaises(ValueError):export(plan,out)
            self.assertFalse((out/'bundle.json').exists())
            self.assertFalse((out/'gt.wav').exists())
