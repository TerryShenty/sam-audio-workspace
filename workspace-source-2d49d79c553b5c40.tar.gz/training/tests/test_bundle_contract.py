import hashlib,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from bundle_contract import validate_links

class BundleTests(unittest.TestCase):
    def fixture(self, root):
        sig={};ns=hashlib.sha256(b'{}').hexdigest();refs={k:'a'*64 for k in ('mixture','video','clean','text')};refs['prompt']='the speaker on the left'
        files=[]
        for kind in ('mixture','video','clean','text'):
            name=f'components/{ns}/{kind}/aa/'+ 'a'*64+'.pt';p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fixture');files.append(name)
        for name in ('gt.wav','mix.wav'):(root/name).write_bytes(b'fixture');files.append(name)
        cat={'signature':sig,'splits':{'train':{'entries':[{'sample_id':'clip::target','variants':[refs]}]}}}
        val={'stores':{'s':{'path':'components','signature':sig}},'items':[{'index':0,'dataset':'MSDWild','store':'s','refs':refs,'gt_audio':'gt.wav','mixture_audio':'mix.wav'}]}
        (root/'cat.json').write_text(json.dumps(cat));(root/'val.json').write_text(json.dumps(val));files+=['cat.json','val.json']
        return {'train_catalog':'cat.json','train_components':'components','validation_manifest':'val.json'},files,cat,val
    def test_valid_and_unlisted_gt(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);b,f,c,v=self.fixture(r)
            self.assertEqual(validate_links(r,b,f)['prompt_variants'],1)
            f.remove('gt.wav')
            with self.assertRaisesRegex(ValueError,'missing from manifest'):validate_links(r,b,f)
    def test_empty_target_variants(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);b,f,c,v=self.fixture(r);c['splits']['train']['entries'][0]['variants']=[];(r/'cat.json').write_text(json.dumps(c))
            with self.assertRaisesRegex(ValueError,'no prompt'):validate_links(r,b,f)
    def test_duplicate_validation(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);b,f,c,v=self.fixture(r);v['items']*=2;(r/'val.json').write_text(json.dumps(v))
            with self.assertRaisesRegex(ValueError,'duplicate validation'):validate_links(r,b,f)
    def test_unsafe_store(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);b,f,c,v=self.fixture(r);v['stores']['s']['path']='../escape';(r/'val.json').write_text(json.dumps(v))
            with self.assertRaisesRegex(ValueError,'Unsafe'):validate_links(r,b,f)
