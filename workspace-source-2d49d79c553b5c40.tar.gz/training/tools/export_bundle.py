"""CPU-only immutable delivery copy from an explicit mapping, after source audit PASS.
Plan: {audit: path, files: [{source:absolute, destination:relative}],
       bundle: {train_catalog, train_components, validation_manifest}}.
Source catalog/validation paths must already be normalized by the plan producer.
Never pass an active producer directory wholesale.
"""
import argparse,json,os,shutil,hashlib
from pathlib import Path
from data_manifest import path_in,sha,verify
from bundle_contract import validate_links

def export(plan,dest):
    audit=json.loads(Path(plan['audit']).read_text())
    if audit.get('status')!='PASS':raise ValueError('Source full read audit required')
    root=Path(dest);root.mkdir(parents=True,exist_ok=True)
    if any(root.iterdir()):raise ValueError('Use a new empty export directory')
    rows=[];names=[r['destination'] for r in plan['files']]
    if any(not isinstance(n,str) or Path(n).as_posix()!=n for n in names):raise ValueError('Destinations must use canonical relative paths')
    if len(names)!=len(set(names)) or set(names)&{'bundle.json','manifest.json'}:raise ValueError('Duplicate/reserved destination')
    sources=[]
    for row in plan['files']:
        src=Path(row['source']).resolve(strict=True);target=path_in(root,row['destination'])
        if not src.is_file() or src.is_relative_to(root.resolve()):raise ValueError('Invalid source')
        sources.append((src,target,row['destination']))
    total=sum(src.stat().st_size for src,_,_ in sources)
    if shutil.disk_usage(root).free<total:raise ValueError('Insufficient export disk')
    for src,target,name in sources:
        target.parent.mkdir(parents=True,exist_ok=True);before=src.stat();source_sha=sha(src);shutil.copyfile(src,target);after=src.stat()
        if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino) or sha(target)!=source_sha:raise ValueError('Source changed/copy corrupt: '+name)
        rows.append({'path':name,'size':after.st_size,'sha256':source_sha})
    b=dict(plan['bundle']);cat=json.loads(path_in(root,b['train_catalog']).read_text());val=json.loads(path_in(root,b['validation_manifest']).read_text())
    assert cat['splits']['train']['entries'] and val['items']
    for key in ('train_components','train_catalog','validation_manifest'):assert path_in(root,b[key]).exists()
    def check_refs(component_root,signature,refs):
        sig=hashlib.sha256(json.dumps(signature,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        for kind in ('mixture','video','clean','text'):
            key=refs[kind]
            if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):raise ValueError('Invalid component key')
            name=str(Path(component_root)/sig/kind/key[:2]/(key+'.pt'))
            if name not in names or not path_in(root,name).is_file():raise ValueError('Missing referenced component: '+name)
    for entry in cat['splits']['train']['entries']:
        for refs in entry['variants']:check_refs(b['train_components'],cat['signature'],refs)
    for entry in val['items']:
        store=val['stores'][entry['store']];check_refs(store['path'],store['signature'],entry['refs'])
    # Components are checked through the authoritative explicit file list. Every normalized
    # validation media reference must resolve inside the bundle before certification.
    for e in val['items']:
        for key in ('gt_audio','mixture_audio'):assert path_in(root,e[key]).is_file()
    validate_links(root,b,names)
    b.update(status='VERIFIED_EXPORT',source_audit_sha256=sha(plan['audit']))
    (root/'bundle.json').write_text(json.dumps(b,indent=2)+'\n');p=root/'bundle.json';rows.append({'path':'bundle.json','size':p.stat().st_size,'sha256':sha(p)})
    m={'schema':1,'files':rows,'total_bytes':sum(r['size'] for r in rows)};verify(root,m);(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');return m
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--plan',required=True);a.add_argument('--output',required=True);o=a.parse_args();m=export(json.loads(Path(o.plan).read_text()),o.output);print(json.dumps({'files':len(m['files']),'bytes':m['total_bytes']}))
