"""CPU-side linkage audit for a portable cached bundle, independent of PyTorch."""
import hashlib
import json
from pathlib import Path
from data_manifest import path_in


def validate_links(root, bundle, file_names):
    root = Path(root)
    names = set(file_names)
    def required(name):
        path = path_in(root, name)
        if name not in names or not path.is_file():
            raise ValueError('Referenced file missing from manifest: ' + name)
        return path
    catalog = json.loads(required(bundle['train_catalog']).read_text())
    validation = json.loads(required(bundle['validation_manifest']).read_text())
    train = catalog['splits']['train']['entries']
    if not train or not validation['items']:
        raise ValueError('Empty training or validation cohort')
    def refs(directory, signature, row):
        path_in(root, directory)
        namespace = hashlib.sha256(json.dumps(signature, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        for kind in ('mixture', 'video', 'clean', 'text'):
            key = row[kind]
            if not isinstance(key, str) or len(key) != 64 or any(c not in '0123456789abcdef' for c in key):
                raise ValueError('Invalid component key')
            required(str(Path(directory) / namespace / kind / key[:2] / (key + '.pt')))
    seen = set()
    variants = 0
    for entry in train:
        if not entry.get('sample_id') or entry['sample_id'] in seen:
            raise ValueError('Missing or duplicate training sample identity')
        seen.add(entry['sample_id'])
        if not entry.get('variants'):
            raise ValueError('Training target has no prompt variant')
        media = set()
        for row in entry['variants']:
            if not isinstance(row.get('prompt'), str) or not row['prompt'].strip():
                raise ValueError('Empty training prompt')
            refs(bundle['train_components'], catalog['signature'], row)
            media.add(tuple(row[k] for k in ('mixture', 'video', 'clean')))
            variants += 1
        if len(media) != 1:
            raise ValueError('Variants change target or media identity')
    indexes = set()
    datasets = {}
    for entry in validation['items']:
        index = entry['index']
        if type(index) is not int or index < 0 or index in indexes:
            raise ValueError('Invalid or duplicate validation index')
        indexes.add(index)
        if not isinstance(entry.get('dataset'), str) or not entry['dataset']:
            raise ValueError('Missing validation dataset')
        datasets[entry['dataset']] = datasets.get(entry['dataset'], 0) + 1
        store = validation['stores'][entry['store']]
        refs(store['path'], store['signature'], entry['refs'])
        required(entry['gt_audio'])
        required(entry['mixture_audio'])
    return {'training_targets': len(train), 'prompt_variants': variants,
            'validation_rows': len(indexes), 'validation_datasets': datasets}
