"""Exercise terminal-process handoff and refusal paths without GPU or cloud use."""
import json
import fcntl
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from finalize_run import finalize
from run_and_archive import run


class WorkflowTests(unittest.TestCase):
    def trainer(self, root, code=0):
        # A real child process writes an atomic terminal receipt before exiting.
        script = ("from pathlib import Path; import json,sys; "
                  "r=Path(sys.argv[1]); p=r/'RESULT.json.tmp'; "
                  "p.write_text(json.dumps({'status':'COMPLETE'})); "
                  "p.replace(r/'RESULT.json'); sys.exit(int(sys.argv[2]))")
        return [sys.executable, "-c", script, str(root), str(code)]

    def test_actual_child_exits_before_finalization(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); calls = []
            def archive(root, environment):
                self.assertEqual(json.loads((root / "RESULT.json").read_text())["status"], "COMPLETE")
                calls.append("after-exit")
                return dict(status="ARCHIVED_VERIFIED_CONTENT")
            self.assertEqual(run(self.trainer(root), root, finalizer=archive), 0)
            self.assertEqual(calls, ["after-exit"])
            self.assertEqual(json.loads((root / "WORKFLOW_RESULT.json").read_text())["status"],
                             "ARCHIVED_VERIFIED_CONTENT")

    def test_failed_child_does_not_archive_even_with_success_file(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            def forbidden(*args):
                self.fail("failed training must not archive")
            self.assertEqual(run(self.trainer(root, 7), root, finalizer=forbidden), 7)
            self.assertEqual(json.loads((root / "WORKFLOW_RESULT.json").read_text())["status"],
                             "TRAINING_FAILED")

    def test_success_exit_with_stale_receipt_refuses_archival(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); (root / "RESULT.json").write_text('{"status":"COMPLETE"}')
            with self.assertRaisesRegex(ValueError, "fresh"):
                run([sys.executable, "-c", "pass"], root)
            self.assertEqual(json.loads((root / "WORKFLOW_RESULT.json").read_text())["status"],
                             "WORKFLOW_FAILED")

    def test_archive_failure_preserves_training_evidence(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            def interrupted(*args):
                raise TimeoutError("unknown upload outcome")
            with self.assertRaises(TimeoutError):
                run(self.trainer(root), root, finalizer=interrupted)
            self.assertEqual(json.loads((root / "RESULT.json").read_text())["status"], "COMPLETE")
            receipt = json.loads((root / "WORKFLOW_RESULT.json").read_text())
            self.assertEqual(receipt["error_type"], "TimeoutError")
            self.assertFalse(receipt["server_cleanup"])

    def test_slurm_and_offline_defer_before_hashing(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); (root / "RESULT.json").write_text('{"status":"CHECKPOINTED"}')
            def forbidden(*args):
                self.fail("deferred finalization must not hash or upload")
            for environment, reason in [
                ({"SLURM_JOB_GPUS": "0,1"}, "SLURM_GPU_ALLOCATION"),
                ({"WANDB_MODE": "offline"}, "WANDB_NOT_ONLINE"),
            ]:
                result = finalize(root, environment, planner=forbidden, archiver=forbidden)
                self.assertEqual(result["reason"], reason)
                self.assertEqual(result["status"], "ARCHIVAL_DEFERRED")

    def test_saved_cohort_controls_archival_and_receipt_is_required(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); (root / "RESULT.json").write_text('{"status":"COMPLETE"}')
            config = dict(engineering_validation_subset=True, validation_cohort={
                "scope": "ENGINEERING_SUBSET", "counts": {"msdwild": 1, "easycom": 1}})
            (root / "effective-config.json").write_text(json.dumps(config))
            seen = []
            def planner(path, expected, engineering):
                seen.append((expected, engineering))
                return {"roles": {}}
            def archiver(path, planned, entity, project):
                return dict(status="PASS_VERIFIED_CONTENT_ROUNDTRIP", transaction="example",
                            roles={"best": {}, "last": {}}, scope="ENGINEERING_SUBSET")
            result = finalize(root, {}, planner, archiver)
            self.assertEqual(seen, [({"msdwild": 1, "easycom": 1}, True)])
            self.assertEqual(result["status"], "ARCHIVED_VERIFIED_CONTENT")
            with self.assertRaisesRegex(ValueError, "verified"):
                finalize(root, {}, planner, lambda *args: {"status": "UPLOAD_STARTED"})
            config["validation_cohort"]["scope"] = "FORMAL_285"
            (root / "effective-config.json").write_text(json.dumps(config))
            with self.assertRaisesRegex(ValueError, "scope"):
                finalize(root, {}, planner, archiver)

    def test_duplicate_workflow_refused_before_training(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with (root / "WORKFLOW.lock").open("a") as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                def forbidden(*args):
                    self.fail("duplicate training launched")
                with self.assertRaises(BlockingIOError):
                    run([], root, runner=forbidden)


if __name__ == "__main__":
    unittest.main()
