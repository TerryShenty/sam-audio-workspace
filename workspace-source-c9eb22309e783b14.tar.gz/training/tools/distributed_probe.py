"""Small real NCCL/DDP probe. Run only inside the intended GPU allocation."""
import json
import os
import time
from datetime import timedelta
from pathlib import Path


def main():
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel

    rank = int(os.environ["LOCAL_RANK"])
    world = int(os.environ["WORLD_SIZE"])
    output = Path(os.environ["SAM_PROBE_OUTPUT"])
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.cuda.set_device(rank)
    device = torch.device("cuda", rank)
    output.mkdir(parents=True, exist_ok=True)

    def event(stage, **fields):
        row = dict(rank=rank, stage=stage, seconds=time.monotonic() - started, **fields)
        print(json.dumps(row), flush=True)
        with (output / f"rank-{rank}.jsonl").open("a") as handle:
            handle.write(json.dumps(row) + "\n")

    event("device", name=torch.cuda.get_device_name(rank),
          uuid=str(torch.cuda.get_device_properties(rank).uuid))
    try:
        dist.init_process_group("nccl", timeout=timedelta(seconds=30), device_id=device)
        event("initialized")
        value = torch.tensor([rank + 1.0], device=device)
        dist.all_reduce(value)
        torch.cuda.synchronize()
        assert value.item() == world * (world + 1) / 2
        event("all_reduce_pass")
        torch.manual_seed(17)
        model = torch.nn.Sequential(torch.nn.Linear(64, 64), torch.nn.GELU(),
                                    torch.nn.Linear(64, 1)).to(device)
        ddp = DistributedDataParallel(model, device_ids=[rank], broadcast_buffers=False)
        optimizer = torch.optim.SGD(ddp.parameters(), lr=0.01)
        before = next(model.parameters()).detach().clone()
        for step in range(2):
            loss = ddp(torch.ones(8, 64, device=device) * (rank + 1)).square().mean()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            assert torch.isfinite(loss)
            event("optimizer_step", step=step + 1)
        torch.cuda.synchronize()
        weight = next(model.parameters()).detach().clone()
        assert not torch.equal(before, weight)
        reference = weight.clone()
        dist.broadcast(reference, src=0)
        assert torch.equal(reference, weight)
        receipt = dict(status="PASS", rank=rank, world=world, steps=2,
                       peak_bytes=torch.cuda.max_memory_allocated(rank),
                       seconds=time.monotonic() - started,
                       scope="tiny NCCL/DDP computation only; not model/data acceptance")
        (output / f"PASS-rank-{rank}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == "__main__":
    main()
