"""Archive completed best/last results without occupying a Slurm GPU allocation."""
import argparse
import json
import os
from pathlib import Path

from archive_best_last import archive, atomic_json, plan


def finalize(root, environment=None, planner=plan, archiver=archive):
    root = Path(root).resolve()
    environment = os.environ if environment is None else environment
    terminal = json.loads((root / "RESULT.json").read_text()).get("status")
    if terminal not in ("COMPLETE", "CHECKPOINTED"):
        raise ValueError("Training did not finish with a successful checkpoint")
    result = {
        "training_status": terminal, "server_cleanup": False,
        "model_resume": "NOT_TESTED_BY_ARCHIVAL",
    }
    # No checkpoint hashing or upload while the Slurm GPUs remain allocated.
    if environment.get("SLURM_JOB_GPUS") or environment.get("SLURM_STEP_GPUS"):
        result.update(status="ARCHIVAL_DEFERRED", reason="SLURM_GPU_ALLOCATION",
                      next_action="Run tools/finalize_run.py --run-dir on the transfer facility after the GPU job ends")
    elif environment.get("WANDB_MODE", "online") != "online":
        result.update(status="ARCHIVAL_DEFERRED", reason="WANDB_NOT_ONLINE",
                      next_action="Authenticate and run tools/finalize_run.py --run-dir with WANDB_MODE=online")
    else:
        config = json.loads((root / "effective-config.json").read_text())
        engineering = bool(config.get("engineering_validation_subset", False))
        cohort = config["validation_cohort"]
        expected = cohort["counts"]
        required_scope = "ENGINEERING_SUBSET" if engineering else "FORMAL_285"
        if cohort["scope"] != required_scope:
            raise ValueError("Saved validation scope disagrees with training configuration")
        planned = planner(root, expected, engineering)
        receipt = archiver(root, planned,
                           environment.get("WANDB_ENTITY") or "terryshen066-fudan-university",
                           environment.get("WANDB_PROJECT") or "sam-audio")
        if receipt.get("status") != "PASS_VERIFIED_CONTENT_ROUNDTRIP":
            raise ValueError("Archive did not return a verified best/last receipt")
        result.update(status="ARCHIVED_VERIFIED_CONTENT", transaction=receipt["transaction"],
                      roles=receipt["roles"], scope=receipt["scope"])
    atomic_json(root / "FINALIZATION.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = finalize(args.run_dir)
    except Exception as error:
        atomic_json(args.run_dir / "FINALIZATION.json",
                    dict(status="ARCHIVAL_FAILED", error_type=type(error).__name__,
                         server_cleanup=False, model_resume="NOT_TESTED_BY_ARCHIVAL"))
        raise
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
