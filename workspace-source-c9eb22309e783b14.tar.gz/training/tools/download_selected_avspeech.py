"""Download a fixed selected-release snapshot and verify its cross-repository objects."""
import argparse,gzip,hashlib,json,os,tarfile
from pathlib import Path
import requests
from huggingface_hub import HfApi,hf_hub_download,hf_hub_url
from release_receipts import complete,record
from data_manifest import path_in
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--metadata-prefix',default='',help='Empty for avspeech-93942; selected_93942 for the legacy source archive');p.add_argument('--revision',required=True);p.add_argument('--ids',nargs='+');p.add_argument('--all',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert bool(a.ids)!=a.all,'Choose --ids or --all'
revision=HfApi().repo_info(a.repo,repo_type='dataset',revision=a.revision).sha
prefix=a.metadata_prefix.strip('/')
assert not prefix or all(x not in ('.','..','') for x in prefix.split('/')), 'Unsafe metadata prefix'
local=lambda name:Path(hf_hub_download(a.repo,(prefix+'/' if prefix else '')+name,repo_type='dataset',revision=revision))
status=json.loads(local('STATUS.json').read_text())
def rows(name):
 path=local(name);assert hashlib.sha256(path.read_bytes()).hexdigest()==status['metadata_sha256'][name]
 with gzip.open(path,'rt',encoding='utf-8') as f:
  for l in f:yield json.loads(l)
videos={x['composite_id']:x for x in rows('videos.jsonl.gz')};ids=set(videos) if a.all else set(a.ids);assert ids<=videos.keys(),'Unknown ID'
archives=list(rows('archives.jsonl.gz'));available={k:set().union(*(set(x['composite_ids']) for x in archives if x['kind']==k)) for k in ['video_mixture','target_residual']}
assert all(ids<=v for v in available.values()),'Requested media/GT still uploading; see STATUS.json'
assert all(isinstance(cid,str) and cid not in ('.','..') and '/' not in cid and '\\' not in cid for cid in ids),'Unsafe composite ID'
a.output.mkdir(parents=True,exist_ok=True)
for arc in archives:
 chosen=ids.intersection(arc['composite_ids'])
 if not chosen:continue
 if complete(a.output,arc,chosen):
  print(arc['kind'],arc['batch'],'verified receipt reused',flush=True);continue
 manifest_url=hf_hub_url(arc['repo'],arc['repo_path']+'.manifest.json',repo_type='dataset',revision=arc['commit'])
 resp=requests.get(manifest_url,timeout=120);resp.raise_for_status();manifest=resp.json();assert manifest['archive_sha256']==arc['tar_sha256'];specs={x['relative']:x for x in manifest['files']}
 h=hashlib.sha256();n=0;pending=[];seen=set();outputs=[];destinations=set()
 url=hf_hub_url(arc['repo'],arc['repo_path'],repo_type='dataset',revision=arc['commit'])
 with requests.get(url,stream=True,timeout=(20,120)) as response:
  response.raise_for_status()
  class Stream:
   def read(self,size=-1):
    global n
    b=response.raw.read(size);h.update(b);n+=len(b);return b
  stream=Stream()
  with tarfile.open(fileobj=stream,mode='r|',bufsize=4<<20) as tf:
   for entry in tf:
    assert entry.isfile() and entry.name in specs and entry.name not in seen;seen.add(entry.name);spec=specs[entry.name];assert entry.size==spec['bytes']
    parts=Path(entry.name).parts;cid=next((v for v in parts if v in chosen),None)
    if cid is None:continue
    dest=path_in(a.output,str(Path('data')/cid/parts[-1]));assert dest not in destinations,'Duplicate flattened destination';destinations.add(dest);dest.parent.mkdir(parents=True,exist_ok=True);temp=dest.with_name(dest.name+'.partial');digest=hashlib.sha256()
    with tf.extractfile(entry) as src,temp.open('wb') as dst:
     for b in iter(lambda:src.read(4<<20),b''):digest.update(b);dst.write(b)
    assert digest.hexdigest()==spec['sha256'] and temp.stat().st_size==spec['bytes'];pending.append((temp,dest));outputs.append((dest,spec))
  for b in iter(lambda:stream.read(4<<20),b''):pass
 assert seen==specs.keys() and h.hexdigest()==arc['tar_sha256'] and n==arc['tar_bytes'],'Archive checksum mismatch'
 for src,dest in pending:src.replace(dest)
 record(a.output,arc,chosen,outputs)
 print(arc['kind'],arc['batch'],len(chosen),'video groups verified',flush=True)
with (a.output/'prompts.jsonl').open('w',encoding='utf-8') as f:
 for x in rows('prompts.jsonl.gz'):
  if x['composite_id'] in ids:f.write(json.dumps(x,ensure_ascii=False)+'\n')
with (a.output/'videos.jsonl').open('w') as f:
 for cid in sorted(ids):f.write(json.dumps(videos[cid])+'\n')
(a.output/'RELEASE.json').write_text(json.dumps({'repo':a.repo,'revision':revision,'videos':len(ids),'status':status},indent=2))
print('Complete:',len(ids),'video groups at',revision)
