#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source tools/media_env.sh
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 TORCHINDUCTOR_COMPILE_THREADS=2
export WANDB_ENTITY="${WANDB_ENTITY:-terryshen066-fudan-university}"
export WANDB_PROJECT="${WANDB_PROJECT:-sam-audio}"
export WANDB_MODE="${WANDB_MODE:-online}"
: "${GPUS:=1}"
if [[ ! -x .venv/bin/python ]]; then echo "Run setup.sh first" >&2; exit 1; fi
exec .venv/bin/python tools/run_and_archive.py --gpus "$GPUS" -- --config configs/train.json "$@"
