"""Portable original per-item BF16 midpoint validation; explicit pre-exported GT WAVs."""
import json,random,hashlib
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
import torch.distributed as dist
from torchdiffeq import odeint
from sam_audio.native_finetuning.feature_cache import ComponentStore
import gt_metric_protocol as metrics
from delivery_score_summary import summarize

def evaluate(sam,codec,manifest_path,data_root,out,rank,world,tracker,context=None):
    root=Path(data_root);manifest=json.loads(Path(manifest_path).read_text());items=manifest['items']
    if not items or len({e['index'] for e in items})!=len(items):raise ValueError('Empty/duplicate validation cohort')
    stores={k:ComponentStore(root/v['path'],v['signature'],lru_entries=16) for k,v in manifest.get('stores',{}).items()}
    device=torch.device('cuda',rank);rng=(random.getstate(),np.random.get_state(),torch.get_rng_state(),torch.cuda.get_rng_state(device))
    modes=[(m,m.training) for m in sam.modules()];rows=[]
    try:
        sam.eval();codec.to(device)
        with torch.inference_mode():
            for e in items[rank::world]:
                frames=e.get('latent_frames');seed=e.get('noise_seed')
                if type(frames) is not int or frames not in (250,500,750):raise ValueError('Explicit supported validation latent_frames required')
                if type(seed) is not int or not 0<=seed<2**63:raise ValueError('Explicit original validation noise_seed required')
                if 'features_file' in e:
                    path=(root/e['features_file']).resolve()
                    if not path.is_relative_to(root.resolve()):raise ValueError('Unsafe validation feature path')
                    if hashlib.sha256(path.read_bytes()).hexdigest()!=e['features_sha256']:raise ValueError('Validation feature hash mismatch')
                    packed=torch.load(path,map_location='cpu',weights_only=True)
                    if packed['latent_frames']!=frames:raise ValueError('Validation cache duration mismatch')
                    forward=packed['forward']
                else:
                    features=stores[e['store']].assemble(e['refs'])
                    if tuple(features['clean'].shape)!=(1,frames,256):raise ValueError('Validation cache duration mismatch')
                    forward=features['forward_args']
                if any(v.is_floating_point() and not torch.isfinite(v).all() for v in forward.values()):raise ValueError('Nonfinite validation feature')
                f={k:v.to(device) for k,v in forward.items()}
                if f['anchor_ids'].tolist()!=[[0,3]]:raise ValueError('Unexpected validation spans')
                noise=torch.randn((1,frames,256),generator=torch.Generator(device=device).manual_seed(seed),device=device,dtype=torch.bfloat16)
                def field(at,z):
                    with torch.autocast('cuda',dtype=torch.bfloat16):return sam(noisy_audio=z,time=at.float().expand(1),**f)
                z=odeint(field,noise,torch.tensor([0.,1.],device=device),method='midpoint',options={'step_size':1/16})[-1]
                with torch.autocast('cuda',dtype=torch.bfloat16):wave=codec.decode(z.transpose(1,2).reshape(2,128,frames)).view(1,2,-1)[:,0,:]
                pred=wave[0].float().cpu().numpy()
                if not np.isfinite(pred).all() or abs(len(pred)-frames*1920)>4800:raise ValueError('Invalid decoded audio')
                ref,sr=sf.read(root/e['gt_audio'],dtype='float64',always_2d=True);ref=metrics.resample_mono(ref,sr)
                mix,sr=sf.read(root/e['mixture_audio'],dtype='float64',always_2d=True);mix=metrics.resample_mono(mix,sr)
                pred=metrics.fit_length(pred.astype(np.float64),len(mix));ref=metrics.fit_length(ref,len(mix))
                aligned,_,_=metrics.align_small_lag(ref,pred);mix_aligned,_,_=metrics.align_small_lag(ref,mix)
                score=metrics.standard_si_sdr(ref,aligned)
                if not np.isfinite(score):raise ValueError('Nonfinite score')
                rows.append({'index':e['index'],'dataset':e['dataset'],'aligned_si_sdr_db':float(score),'si_sdr_db':float(metrics.standard_si_sdr(ref,pred)),'si_sdri_db':float(score-metrics.standard_si_sdr(ref,mix_aligned)),'noise_sha256':hashlib.sha256(noise.cpu().view(torch.uint8).numpy().tobytes()).hexdigest()})
        shards=[None]*world;dist.all_gather_object(shards,rows);allrows=sorted(sum(shards,[]),key=lambda x:x['index'])
        if [r['index'] for r in allrows]!=sorted(e['index'] for e in items):raise ValueError('Incomplete validation')
        if rank==0:
            out=Path(out);out.mkdir(parents=True,exist_ok=True);(out/'scores.json').write_text(json.dumps(allrows,indent=2))
            summary,logged=summarize(allrows,context)
            (out/'summary.json').write_text(json.dumps(summary,indent=2))
            if context:(out/'context.json').write_text(json.dumps(context,indent=2))
            tracker.log(logged)
    finally:
        codec.cpu()
        for m,mode in modes:m.training=mode
        random.setstate(rng[0]);np.random.set_state(rng[1]);torch.set_rng_state(rng[2]);torch.cuda.set_rng_state(rng[3],device)
