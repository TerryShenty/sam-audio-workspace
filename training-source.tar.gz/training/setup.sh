#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3.12 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements-reference.txt
# The reference lock is a snapshot, not yet a clean-install certification.
.venv/bin/python -m pip check
printf '%s\n' 'Activate with: source .venv/bin/activate; then run tools/preflight.py'
