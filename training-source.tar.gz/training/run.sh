#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 TORCHINDUCTOR_COMPILE_THREADS=2
export WANDB_ENTITY="${WANDB_ENTITY:-terryshen066-fudan-university}"
export WANDB_PROJECT="${WANDB_PROJECT:-sam-audio}"
export WANDB_MODE="${WANDB_MODE:-online}"
: "${GPUS:=1}"
exec python -m torch.distributed.run --standalone --nproc_per_node="$GPUS" src/train_delivery.py --config configs/train.json "$@"
