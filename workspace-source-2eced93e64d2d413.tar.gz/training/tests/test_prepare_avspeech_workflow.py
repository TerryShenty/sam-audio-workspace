import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from prepare_avspeech_workflow import workflow, selection, check_media

REV = "a" * 40


class PreparationWorkflowTests(unittest.TestCase):
    def fixture(self, root, revision=REV):
        media = root / "media"
        media.mkdir(exist_ok=True)
        release = dict(repo="TerryShenty/avspeech-93942", revision=revision,
                       videos=1, status=dict(expected_videos=2, expected_targets=2,
                                             prompts_available=2))
        video = dict(composite_id="clip", sample_rate=48000, samples=48000,
                     recipe_sha256="hash",
                     targets=[dict(slot=0, source_id="s", window_id="w", prompt_count=1)])
        prompt = dict(composite_id="clip", slot=0, source_id="s", window_id="w",
                      prompt_id="p", prompt="A speaker.", recipe_sha256="hash")
        for name, value in (("RELEASE.json", release), ("videos.jsonl", video),
                            ("prompts.jsonl", prompt)):
            (media / name).write_text(json.dumps(value) + "\n")

    def fake_stage(self, root, events, fail=None):
        def run(command, log):
            stage = Path(command[1]).name
            events.append(stage)
            log.write_text(stage)
            if stage == fail:
                raise RuntimeError("Injected stage failure")
            if stage == "download_selected_avspeech.py":
                self.fixture(root)
            else:
                from prepare_selected_media import digest
                prepared = root / "prepared"
                prepared.mkdir(exist_ok=True)
                receipt = dict(status="PASS", revision=REV, videos=1, prompts=1,
                               metadata={n: digest(root / "media" / n) for n in
                                         ("RELEASE.json", "videos.jsonl", "prompts.jsonl")})
                (prepared / "CPU_READY.json").write_text(json.dumps(receipt))
        return run

    def test_combined_and_split_phase_order(self):
        for phases in (["all"], ["download", "prepare"]):
            with self.subTest(phases=phases), tempfile.TemporaryDirectory() as d:
                root = Path(d)
                events = []
                for phase in phases:
                    result = workflow(root, REV, ["clip"], phase=phase,
                                      runner=self.fake_stage(root, events))
                self.assertEqual(events, ["download_selected_avspeech.py",
                                          "prepare_selected_media.py"])
                self.assertEqual(result["status"], "CPU_MEDIA_READY")
                self.assertFalse(result["training_ready"])

    def test_download_failure_never_decodes_or_reuses_ready(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            events = []
            workflow(root, REV, ["clip"], runner=self.fake_stage(root, events))
            events.clear()
            with self.assertRaises(RuntimeError):
                workflow(root, REV, ["clip"], runner=self.fake_stage(
                    root, events, "download_selected_avspeech.py"))
            self.assertEqual(events, ["download_selected_avspeech.py"])
            self.assertFalse((root / "WORKFLOW_READY.json").exists())
            self.assertEqual(len(list((root / "attempts").glob("*/PREVIOUS_WORKFLOW_READY.json"))), 1)

    def test_revision_and_selection_change_refused_before_subprocess(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            events = []
            workflow(root, REV, ["clip"], runner=self.fake_stage(root, events))
            events.clear()
            for revision, ids in [("b" * 40, ["clip"]), (REV, ["other"])]:
                with self.assertRaises(ValueError):
                    workflow(root, revision, ids, runner=self.fake_stage(root, events))
            self.assertEqual(events, [])

    def test_adopted_media_requires_correct_version_and_complete_all(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.fixture(root)
            events = []
            with self.assertRaises(ValueError):
                workflow(root, "b" * 40, ["clip"], runner=self.fake_stage(root, events))
            with self.assertRaises(ValueError):
                workflow(root, REV, all_rows=True, runner=self.fake_stage(root, events))
            self.assertEqual(events, [])

    def test_incomplete_or_stale_cpu_receipt_never_ready(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            events = []
            def stale(command, log):
                self.fake_stage(root, events)(command, log)
                if events[-1] == "prepare_selected_media.py":
                    p = root / "prepared/CPU_READY.json"
                    receipt = json.loads(p.read_text())
                    receipt["metadata"]["prompts.jsonl"] = "changed"
                    p.write_text(json.dumps(receipt))
            with self.assertRaises(ValueError):
                workflow(root, REV, ["clip"], runner=stale)
            self.assertFalse((root / "WORKFLOW_READY.json").exists())

    def test_mutable_revision_duplicates_and_gpu_rejected(self):
        for revision, ids in [("main", ["clip"]), (REV, ["clip", "clip"])]:
            with self.assertRaises(ValueError):
                selection(revision, ids, False)
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ, SLURM_JOB_GPUS="0,1"):
            with self.assertRaises(ValueError):
                workflow(Path(d) / "new", REV, ["clip"])
            self.assertFalse((Path(d) / "new").exists())

    def test_noop_cpu_stage_cannot_reuse_stale_success(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            workflow(root, REV, ["clip"], runner=self.fake_stage(root, []))
            with self.assertRaisesRegex(ValueError, "fresh CPU"):
                workflow(root, REV, ["clip"], phase="prepare", runner=lambda *args: None)
            self.assertFalse((root / "WORKFLOW_READY.json").exists())

    def test_changed_media_invalidates_previous_readiness(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            workflow(root, REV, ["clip"], runner=self.fake_stage(root, []))
            self.fixture(root, revision="b" * 40)
            with self.assertRaises(ValueError):
                workflow(root, REV, ["clip"], phase="prepare", runner=lambda *args: None)
            self.assertFalse((root / "WORKFLOW_READY.json").exists())
            self.assertEqual(json.loads((root / "WORKFLOW_LAST_ATTEMPT.json").read_text())["status"], "FAILED")


if __name__ == "__main__":
    unittest.main()
