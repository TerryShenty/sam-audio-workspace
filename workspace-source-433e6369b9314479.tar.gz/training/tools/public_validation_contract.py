"""Sealed public-input encoder contracts; importing this module needs no GPU."""
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
sys.path.insert(0, str(SOURCE / "tools"))
sys.path.insert(0, str(SOURCE / "src"))
from workflow_contract import read, write, sha, key, inputs_unchanged
from prepare_public_validation_input import select_rows, partition
from delivery_cohort import check

RECIPE = dict(dtype="bfloat16", video_frame_chunk=8, full_duration=True,
              validation_conditioning="nullGT", scoring_gt_only=True)
REPRESENTATIVE_INDEXES = [2, 7, 1, 3, 228, 232, 78, 81]
INDEXES = list(range(285))
STATUS = "ALL285_PUBLIC_FEATURES_WRITTEN_CPU_AUDIT_PENDING"


def validate(plan, ready, cfg):
    if (key(plan) != cfg["plan_identity"] or ready["plan_identity"] != key(plan)
            or ready["status"] != "CPU_PUBLIC_VALIDATION_INPUT_READY"
            or ready["input_sha256"] != cfg["input_sha256"]):
        raise ValueError("CPU input identity or receipt mismatch")
    if (plan["world"] != 2 or any(plan.get(k) != v for k, v in RECIPE.items())
            or plan["public_revision"] != cfg["public_revision"]
            or ready["public_revision"] != plan["public_revision"]
            or plan["representative_indexes"] != REPRESENTATIVE_INDEXES
            or cfg.get("selection") != "all285"
            or cfg.get("expected_counts") != {"msdwild": 78, "easycom": 207}):
        raise ValueError("Public encoding recipe changed")
    if check(plan["rows"]) != plan["cohort"] or ready["cohort"] != plan["cohort"]:
        raise ValueError("Full cohort identity changed")
    for row in plan["rows"]:
        if (row["latent_frames"] != (500 if row["dataset"] == "msdwild" else 250)
                or row["split"] != "validation"
                or any(k in row for k in ("training_support", "anchor_ids", "anchor_alignment"))):
            raise ValueError("Duration or validation conditioning changed")
        for field in ("video", "mixture_audio", "gt_audio"):
            path = Path(plan["media_root"]) / row[field]
            if str(path) not in ready["media_files"]:
                raise ValueError("Unbound public media")
    rows = select_rows(plan, INDEXES)
    for rank in range(2):
        assigned = partition(rows, rank, 2)
        counts = {name: sum(r["dataset"] == name for r in assigned) for name in ("msdwild", "easycom")}
        if len(assigned) != (143 if rank == 0 else 142) or counts != {"msdwild": 39, "easycom": 104 if rank == 0 else 103}:
            raise ValueError("Full cohort shard coverage changed")
    return rows


def load_inputs(config):
    cfg = read(config)
    for path, expected in ((cfg["input"], cfg["input_sha256"]),
                           (cfg["ready"], cfg["ready_sha256"]),
                           (str(SOURCE / "SOURCE_MANIFEST.json"), cfg["source_manifest_sha256"])):
        if sha(path) != expected:
            raise ValueError("Sealed metadata changed: " + path)
    plan, ready = read(cfg["input"]), read(cfg["ready"])
    return cfg, plan, ready, validate(plan, ready, cfg)


def check_signature(sig, plan):
    if (sig["verified_base"] != plan["expected_base"] or sig["dtype"] != "bfloat16"
            or sig["max_seconds"] is not None or sig["video_frame_chunk"] != 8
            or sig["allow_tf32"] is not True):
        raise ValueError("Loaded SAM/T5/tokenizer or encoder recipe differs")


def merge(reports, plan, ready, cfg, output):
    rows = validate(plan, ready, cfg)
    if len(reports) != 2 or {x.get("rank") for x in reports} != {0, 1}:
        raise ValueError("Exactly two unique rank receipts required")
    if len({x.get("gpu_uuid") for x in reports}) != 2 or not all(x.get("gpu_uuid") for x in reports):
        raise ValueError("Two actual GPU UUIDs required")
    merged = []
    signatures = []
    for report in reports:
        rank = report["rank"]
        if (report["status"] != STATUS or report["world"] != 2
                or report["plan_identity"] != cfg["plan_identity"]
                or report["input_sha256"] != cfg["input_sha256"]
                or report["recipe"] != RECIPE or report["gt_audio_read"] is not False):
            raise ValueError("Unsuccessful or incompatible rank receipt")
        check_signature(report["model_signature"], plan)
        signatures.append(report["model_signature"])
        assigned = partition(rows, rank, 2)
        if len(report["rows"]) != len(assigned):
            raise ValueError("Incomplete shard")
        for record, row in zip(report["rows"], assigned):
            expected = Path(output).resolve() / f"rank-{rank}" / f"row-{row['index']}.pt"
            if (record["row"] != row or Path(record["path"]).resolve() != expected
                    or record["finite"] is not True or record["anchor_ids"] != [[0, 3]]
                    or record["latent_frames"] != row["latent_frames"]):
                raise ValueError("Output identity, duration, path or null GT mismatch")
            for field in ("encoding_seconds", "row_seconds", "peak_gpu_bytes"):
                if not isinstance(record[field], (int, float)) or not math.isfinite(record[field]) or record[field] <= 0:
                    raise ValueError("Missing actual timing or memory")
            merged.append(record)
    if signatures[0] != signatures[1]:
        raise ValueError("Loaded preprocessing signatures differ")
    if sorted(r["row"]["index"] for r in merged) != INDEXES:
        raise ValueError("Duplicate coverage")
    return sorted(merged, key=lambda x: x["row"]["index"])


def finalize(output, config):
    cfg, plan, ready, _ = load_inputs(config)
    root = Path(output)
    records = merge([read(root / f"rank-{r}/RESULT.json") for r in range(2)],
                    plan, ready, cfg, root)
    result = dict(status=STATUS, scope="FULL285_PUBLIC_RAW_FEATURE_GENERATION",
                  training_ready=False, scoring_performed=False, world=2,
                  input_sha256=cfg["input_sha256"], plan_identity=cfg["plan_identity"],
                  public_revision=plan["public_revision"], recipe=RECIPE, rows=records)
    write(root / "RESULT.json", result)
    return result


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--finalize", required=True)
    p.add_argument("--config", required=True)
    args = p.parse_args()
    finalize(args.finalize, args.config)
