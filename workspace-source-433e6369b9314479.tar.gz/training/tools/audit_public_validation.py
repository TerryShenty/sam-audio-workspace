"""CPU-only tensor audit of all285 new public outputs; never reruns encoding."""
def main():
    import argparse
    import time
    from pathlib import Path
    from public_validation_contract import load_inputs, read, write, sha, merge
    from workflow_contract import cpu_only
    cpu_only()
    p = argparse.ArgumentParser()
    p.add_argument("--output", required=True)
    p.add_argument("--config", required=True)
    args = p.parse_args()
    root = Path(args.output).resolve()
    if (root / "CPU_AUDIT.json").exists():
        raise ValueError("Audit already exists; reconcile without overwriting")
    cfg, plan, ready, _ = load_inputs(args.config)
    reports = [read(root / f"rank-{r}/RESULT.json") for r in range(2)]
    rows = merge(reports, plan, ready, cfg, root)
    started = time.monotonic()
    import torch
    torch.set_num_threads(1)
    for record in rows:
        path = Path(record["path"])
        if path.is_symlink() or not path.is_file():
            raise ValueError("Missing or redirected tensor")
        value = torch.load(path, map_location="cpu", weights_only=True)
        frames = record["row"]["latent_frames"]
        f = value["forward"]
        expected = {"audio_features", "audio_pad_mask", "anchor_ids", "anchor_alignment",
                    "masked_video_features", "text_features", "text_mask"}
        if set(f) != expected or value["latent_frames"] != frames:
            raise ValueError("Tensor fields or length changed")
        if f["audio_features"].shape[0:2] != (1, frames) or f["masked_video_features"].shape[-1] != frames:
            raise ValueError("Audio/video full-duration shape mismatch")
        if f["anchor_ids"].tolist() != [[0, 3]] or f["anchor_alignment"].shape[-1] != frames:
            raise ValueError("Invalid null anchor shape")
        # Null spans align valid frames to null and padding to the pad token.
        if not torch.equal(f["anchor_alignment"], (~f["audio_pad_mask"]).long()):
            raise ValueError("Non-null validation anchor alignment")
        for name, tensor in f.items():
            if (list(tensor.shape) != record["tensors"][name]["shape"]
                    or str(tensor.dtype) != record["tensors"][name]["dtype"]
                    or tensor.is_floating_point() and not torch.isfinite(tensor).all().item()):
                raise ValueError("Tensor receipt or finite check failed")
        record["sha256"] = sha(path)
        record["bytes"] = path.stat().st_size
    timing = {}
    for dataset in ("msdwild", "easycom"):
        values = [r["encoding_seconds"] for r in rows if r["row"]["dataset"] == dataset]
        timing[dataset] = dict(n=len(values), seconds=values, mean=sum(values)/len(values), maximum=max(values))
    result = dict(status="PASS_ALL285_PUBLIC_ENCODING_AND_CPU_TENSORS",
                  scope="FULL285_PUBLIC_RAW_FEATURE_GENERATION", full285_features_ready=True,
                  public_revision=plan["public_revision"], plan_identity=cfg["plan_identity"],
                  input_sha256=cfg["input_sha256"], rows=rows, timing=timing,
                  rank_seconds=[r["seconds"] for r in reports],
                  model_ready_seconds=[r["imports_model_ready_seconds"] for r in reports],
                  gpu_uuids=[r["gpu_uuid"] for r in reports],
                  peak_gpu_bytes=max(r["peak_gpu_bytes"] for r in rows),
                  seconds=time.monotonic()-started)
    write(root / "CPU_AUDIT.json", result)
    print(result["status"], result["seconds"], timing, flush=True)


if __name__ == "__main__":
    main()
