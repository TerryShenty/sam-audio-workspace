"""Bind pinned public validation media to a complete, CPU-verified GPU input plan.

This stage does not encode features or train. Optional archive-byte reuse is
explicit; the ordinary pinned downloader still checks metadata and extracts into
this workspace. Existing publication receipts and archives are never modified.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from delivery_cohort import check
from workflow_contract import cpu_only, inputs_unchanged, key, read, sha, write

REPRESENTATIVE = [2, 7, 1, 3, 228, 232, 78, 81]


def validate_manifest(raw, pin):
    revision = pin.get("revision")
    if not isinstance(revision, str) or not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("Immutable public revision required")
    if (pin.get("repository") != "sam-audio-research/sam-audio-validation-285"
            or pin.get("visibility") != "public"):
        raise ValueError("Wrong public validation destination")
    if hashlib.sha256(raw).hexdigest() != pin["manifest_sha256"]:
        raise ValueError("Public manifest checksum changed")
    manifest = json.loads(raw)
    cohort = check(manifest["rows"], engineering_subset=False)
    if (cohort["counts"] != pin["counts"]
            or cohort["cohort_sha256"] != pin["cohort_sha256"]):
        raise ValueError("Full validation protocol changed")
    specs = {}
    for spec in manifest["files"]:
        name = spec["path"]
        path = PurePosixPath(name)
        if (path.is_absolute() or ".." in path.parts or str(path) != name
                or not name.startswith("media/") or name in specs
                or "\\" in name):
            raise ValueError("Unsafe or duplicate public media path")
        if type(spec["size"]) is not int or spec["size"] <= 0:
            raise ValueError("Invalid media size")
        if not re.fullmatch(r"[0-9a-f]{64}", spec["sha256"]):
            raise ValueError("Invalid media digest")
        specs[name] = spec
    if len(specs) != 414 or len(manifest["rows"]) != 285:
        raise ValueError("Incomplete public media or cohort")
    for row in manifest["rows"]:
        expected_frames = 500 if row["dataset"] == "msdwild" else 250
        if row["latent_frames"] != expected_frames or row.get("split") != "validation":
            raise ValueError("Public row duration/split mismatch")
        if any(k in row for k in ("training_support", "anchor_ids", "anchor_alignment")):
            raise ValueError("Validation conditioning GT is forbidden")
        for field in ("video", "mixture_audio", "gt_audio"):
            if row[field] not in specs:
                raise ValueError("Unbound validation media")
    return manifest, cohort


def select_rows(manifest, indexes=None):
    by_index = {r["index"]: r for r in manifest["rows"]}
    selected = list(by_index) if indexes is None else list(indexes)
    if not selected or len(selected) != len(set(selected)) or any(i not in by_index for i in selected):
        raise ValueError("Unknown, duplicate or empty selection")
    return [by_index[i] for i in selected]


def partition(rows, rank, world=2):
    if type(world) is not int or world != 2 or type(rank) is not int or not 0 <= rank < world:
        raise ValueError("This bounded encoder plan requires exactly two ranks")
    assigned = rows[rank::world]
    if not assigned or {r["dataset"] for r in assigned} != {"msdwild", "easycom"}:
        raise ValueError("Every rank must cover both validation datasets")
    return assigned


def media_snapshot(root, specs):
    result = {}
    for name, spec in specs.items():
        path = root / name
        resolved = path.resolve()
        if path.is_symlink() or not resolved.is_relative_to(root.resolve()) or not path.is_file():
            raise ValueError("Missing or redirected public media")
        st = path.stat()
        if st.st_size != spec["size"] or sha(path) != spec["sha256"]:
            raise ValueError("Public media bytes changed: " + name)
        result[str(resolved)] = dict(bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                                    inode=st.st_ino, sha256=spec["sha256"])
    return result


def prepare(config_path):
    cpu_only()
    cfg = read(config_path)
    identity = key(cfg)
    root = Path(cfg["output"]).resolve()
    root.mkdir(parents=True, exist_ok=True)
    with (root / "PREPARE.lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        ready = root / "CPU_READY.json"
        previous = None
        if ready.exists():
            # Retain every previous receipt before rechecking bytes. A failure
            # cannot leave an old READY available to a GPU worker.
            history = root / "history"
            history.mkdir(exist_ok=True)
            previous = read(ready)
            ready.rename(history / f"CPU_READY-{time.time_ns()}.json")
        started = time.monotonic()
        intent = root / "PREPARE_INTENT.json"
        if intent.exists() and read(intent)["config_identity"] != identity:
            raise ValueError("Preparation output belongs to different inputs")
        if not intent.exists():
            write(intent, dict(config_identity=identity, status="STARTED"))
        if previous is not None:
            if previous["config_identity"] != identity:
                raise ValueError("Previously accepted inputs used different configuration")
            inputs_unchanged(previous["media_files"])
            for path, spec in previous["media_files"].items():
                if sha(path) != spec["sha256"]:
                    raise ValueError("Previously accepted media bytes changed")
        pin_path = Path(cfg["release_config"])
        if sha(pin_path) != cfg["release_config_sha256"]:
            raise ValueError("Pinned release configuration changed")
        pin = read(pin_path)
        # Model bytes/cache were genuinely checked by an earlier accepted CPU
        # stage. Reuse is explicit and still requires unchanged file identity.
        model_receipt = Path(cfg["accepted_model_receipt"])
        if sha(model_receipt) != cfg["accepted_model_receipt_sha256"]:
            raise ValueError("Accepted model receipt changed")
        old = read(model_receipt)
        if old["status"] != "CPU_INPUT_READY" or old["explicit_hf_cache"] != cfg["hf_hub_cache"]:
            raise ValueError("Explicit offline model cache identity missing")
        inputs_unchanged(old["model_files"])
        media = root / "media-release"
        media.mkdir(exist_ok=True)
        reused = cfg.get("reuse_verified_archive")
        target = media / pin["archive"]["path"]
        if target.exists() and (target.stat().st_size != pin["archive"]["size"]
                                or sha(target) != pin["archive"]["sha256"]):
            raise ValueError("Existing copied archive changed")
        if reused and not target.exists():
            original = Path(reused)
            if original.stat().st_size != pin["archive"]["size"] or sha(original) != pin["archive"]["sha256"]:
                raise ValueError("Reusable archive bytes differ from public pin")
            temp = target.with_suffix(".copying")
            shutil.copyfile(original, temp)
            if sha(temp) != pin["archive"]["sha256"]:
                raise ValueError("Copied archive checksum changed")
            temp.replace(target)
        # This is the existing public pinned download/extraction entry point,
        # not the private LOCAL_ONLY_SOURCE_MAP or old feature bundle.
        if cfg.get("offline_prepared_media") is True:
            # The network/transfer phase has already fetched this pinned
            # release. CPU workers validate all bytes below without networking.
            download_receipt = read(media / "DOWNLOAD_RECEIPT.json")
            if download_receipt.get("repo") != pin["repository"]:
                raise ValueError("Offline media receipt belongs to another repository")
        elif "offline_prepared_media" in cfg:
            raise ValueError("offline_prepared_media must be explicit boolean true")
        else:
            from download_validation_data import prepare as download
            download_receipt = download(pin, media)
        raw = (media / "validation.json").read_bytes()
        manifest, cohort = validate_manifest(raw, pin)
        if (download_receipt["status"] != "VERIFIED_MEDIA"
                or download_receipt["revision"] != pin["revision"]):
            raise ValueError("Pinned downloader did not produce matching evidence")
        snapshots = media_snapshot(media, {s["path"]: s for s in manifest["files"]})
        rows = select_rows(manifest)
        representative = select_rows(manifest, REPRESENTATIVE)
        for selected in (rows, representative):
            for rank in range(2):
                partition(selected, rank)
        plan = dict(schema=1, public_repository=pin["repository"],
                    public_revision=pin["revision"], manifest_sha256=pin["manifest_sha256"],
                    cohort=cohort, rows=rows, representative_indexes=REPRESENTATIVE,
                    media_root=str(media), world=2, dtype="bfloat16",
                    video_frame_chunk=8, full_duration=True,
                    validation_conditioning="nullGT", scoring_gt_only=True,
                    expected_base=cfg["base_signature"], model=cfg["model"],
                    hf_hub_cache=cfg["hf_hub_cache"])
        write(root / "ENCODER_INPUT.json", plan)
        result = dict(status="CPU_PUBLIC_VALIDATION_INPUT_READY", config_identity=identity,
                      input_sha256=sha(root / "ENCODER_INPUT.json"), plan_identity=key(plan),
                      public_revision=pin["revision"], cohort=cohort,
                      media_files=snapshots, model_files=old["model_files"],
                      model_preflight_reused=True, reused_archive_bytes=bool(reused),
                      archive_network_download_expected=not bool(reused) and not cfg.get("offline_prepared_media", False),
                      offline_prepared_media=cfg.get("offline_prepared_media", False),
                      downloader=download_receipt,
                      counts=cohort["counts"], full_media_bytes=sum(s["bytes"] for s in snapshots.values()),
                      new_feature_generation="NOT_RUN", training_ready=False,
                      seconds=time.monotonic()-started)
        write(ready, result)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    result = prepare(args.config)
    print(json.dumps({k: result[k] for k in ("status", "counts", "seconds",
                     "reused_archive_bytes", "new_feature_generation")}), flush=True)


if __name__ == "__main__":
    main()
