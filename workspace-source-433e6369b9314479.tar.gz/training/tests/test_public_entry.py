import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SOURCE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SOURCE/'tools'));sys.path.insert(0,str(SOURCE/'src'))
import public_entry as entry
from workflow_contract import write,key

class PublicEntryTests(unittest.TestCase):
    def request(self):
        return dict(profile='engineering-public285',gpus=2,wandb_entity='owner',wandb_project='project',
            data_root='/srv/data',data_manifest_sha256='a'*64,model='/srv/model',directory='/srv/run',
            training_config='/srv/config.json',python='/srv/venv/bin/python',hf_hub_cache='/srv/cache',
            resume='/srv/step-8.pt',resume_sha256='b'*64,stop_after_step=None)

    def test_profile_requires_explicit_entity_world_and_resume_hash(self):
        r=self.request();entry.validate_request(r)
        for change in [dict(gpus=1),dict(wandb_entity=''),dict(profile='full'),dict(resume_sha256=None),dict(stop_after_step=10),dict(data_manifest_sha256='unknown')]:
            with self.assertRaises(ValueError): entry.validate_request(dict(r,**change))

    def test_command_is_argument_vector_and_carries_public_data(self):
        r=self.request();r['directory']='/srv/run with spaces; literal'
        cmd=entry.command(r)
        self.assertEqual(cmd[cmd.index('--data-root')+1],'/srv/data')
        self.assertEqual(cmd[cmd.index('--resume')+1],'/srv/step-8.pt')
        self.assertEqual(cmd[cmd.index('--output')+1],'/srv/run with spaces; literal/train')
        self.assertNotIn('--stop-after-step',cmd)

    def test_environment_preserves_operator_setting_and_own_account(self):
        r=self.request();env=entry.environment(r,{'NCCL_P2P_DISABLE':'0','WANDB_RUN_ID':'stale','HF_HUB_CACHE':'wrong'})
        self.assertEqual(env['NCCL_P2P_DISABLE'],'0');self.assertEqual(env['WANDB_ENTITY'],'owner')
        self.assertEqual(env['HF_HUB_CACHE'],'/srv/cache');self.assertNotIn('WANDB_RUN_ID',env)
        self.assertNotIn('NCCL_P2P_DISABLE',entry.environment(r,{}))
        self.assertEqual(env['HF_HUB_OFFLINE'],'1')

    def test_public_revision_and_features_required(self):
        pin=json.loads((SOURCE/'configs/validation_release.json').read_text())
        for bundle in [dict(status='VERIFIED_EXPORT'),dict(status='VERIFIED_EXPORT',public_validation_revision=pin['revision'],validation_features_provenance='OLD_PRIVATE_CACHE')]:
            with self.assertRaises(ValueError):entry.public_bundle(bundle,{},pin)

    def test_full_public_protocol_and_gt_pollution(self):
        raw=json.loads((SOURCE/'tests/fixtures/public-validation.json').read_text())
        pin=json.loads((SOURCE/'configs/validation_release.json').read_text())
        rows=[dict(row,original_public_row=copy.deepcopy(row)) for row in raw['rows']]
        v=dict(items=rows,provenance=dict(public_revision=pin['revision'],fresh_features=True,conditioning='nullGT'))
        b=dict(status='VERIFIED_EXPORT',public_validation_revision=pin['revision'],validation_features_provenance='FRESH_ALL285_PUBLIC_MEDIA')
        self.assertEqual(entry.public_bundle(b,v,pin)['counts'],dict(msdwild=78,easycom=207))
        for field,value in [('prompt','changed'),('noise_seed',999),('anchor_ids',[[1,3]])]:
            bad=copy.deepcopy(v);bad['items'][0][field]=value
            with self.assertRaises(ValueError):entry.public_bundle(b,bad,pin)

    def test_duplicate_intent_and_changed_inputs_reject_before_runner(self):
        with tempfile.TemporaryDirectory() as d:
            r=self.request();r['directory']=d
            m=SOURCE/'SOURCE_MANIFEST.json';p=Path(d)/'data';p.write_text('original')
            ready=dict(status='PUBLIC_ENTRY_INPUT_READY',request_identity=key(r),source_manifest_sha256=entry.sha(m),inputs={str(p):entry.snapshot(p)})
            write(Path(d)/'INPUT_READY.json',ready);write(Path(d)/'TRAIN_INTENT.json',dict(status='STARTED'))
            def forbidden(*a,**k): self.fail('training must not be launched')
            with self.assertRaises(ValueError):entry.train(r,runner=forbidden)
            p.write_text('changed longer bytes')
            with self.assertRaises(ValueError):entry.train(r,runner=forbidden)

    def test_stale_request_rejects_before_runner(self):
        with tempfile.TemporaryDirectory() as d:
            r=self.request();r['directory']=d
            write(Path(d)/'INPUT_READY.json',dict(status='PUBLIC_ENTRY_INPUT_READY',request_identity='stale'))
            with self.assertRaises(ValueError):entry.train(r,runner=lambda *a,**k:self.fail('unexpected runner'))

    def test_import_does_not_load_torch_or_start_work(self):
        p=subprocess.run([sys.executable,'-c',"import sys;sys.path.insert(0,sys.argv[1]);import public_entry;assert 'torch' not in sys.modules",str(SOURCE/'tools')],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)

if __name__=='__main__':unittest.main()
