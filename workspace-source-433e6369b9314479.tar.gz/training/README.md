# Extracted SAM Audio workflow

This is a published engineering preview. Complete standalone execution
has not yet passed acceptance. See DELIVERY_STATUS.json for exact scope.

For the planned Linux x86_64 / Python 3.12 / two-NVIDIA-GPU engineering check:

```bash
bash start.sh --directory "$PWD/my-run" --wandb-entity YOUR_WANDB_ENTITY
```

Use your own Hugging Face credentials with approved access to
`facebook/sam-audio-large-tv`, and your own W&B login. The training and validation
data are public and do not require their owners' credentials.

The default command installs the included environment if needed, downloads the
fixed three-video engineering selection and all 285 validation examples, verifies
the pinned SAM/T5 models, prepares target support intervals, generates both
training and validation caches, exports a verified bundle, runs nine engineering
updates with complete validation, and archives best/last checkpoints.

The training selection contains 3 videos, 8 targets and 13 prompts. It does not
launch full 93,942-video training. The full public training archive is approximately
1.313 TB before extraction and feature storage. This engineering profile uses
BF16, two GPUs and global batch two; it is not the SOLOs production INT8 profile.
Only 10/20-second examples have representative memory evidence.

On clusters, keep network and CPU work out of GPU allocations. The same workspace
can be advanced at explicit boundaries:

```bash
# Transfer facility
bash start.sh --directory "$PWD/my-run" --wandb-entity YOUR_WANDB_ENTITY --through download
# CPU allocation
bash start.sh --directory "$PWD/my-run" --only prepare
# Two-GPU allocation
bash start.sh --directory "$PWD/my-run" --only encode-training
bash start.sh --directory "$PWD/my-run" --only encode-validation
# CPU allocation
bash start.sh --directory "$PWD/my-run" --only export
# Two-GPU allocation
bash start.sh --directory "$PWD/my-run" --only train
# Transfer facility, after the training allocation and all steps terminate
bash start.sh --directory "$PWD/my-run" --only finalize
```

Completed stages are checked and reused. Download interruption can resume from
verified archive receipts. An unresolved GPU or upload intent stops for
reconciliation instead of launching a duplicate. Complete optimizer/scheduler/
EMA/RNG/data-position checkpoints remain available; files are never deleted by
this workflow.

Explicit `SAM_PYTHON` and `SAM_FFMPEG_PREFIX` can select an already verified
environment. Model reuse requires an explicit directory, trusted CPU receipt
and receipt SHA. These options are recorded as reuse and are not a fresh install
or fresh model download. The normal outsider command requires no prior receipt.

An explicit `--reuse-training-media` can import already verified selected raw
download bytes, and `--reuse-validation-archive` can reuse the exact pinned public
archive. Both are independently copied and checked; neither imports old training
or validation features. Omit these options for a new server's ordinary downloads.

Use the repository-root README for the clone/bootstrap command.
