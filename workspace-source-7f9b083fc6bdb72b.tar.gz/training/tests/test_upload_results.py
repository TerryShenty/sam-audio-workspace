"""SDK boundary tests use a fake service; these are not live W&B acceptance."""
import json
import shutil
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import upload_results


class UploadTests(unittest.TestCase):
    def exercise(self, failure=None):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'last.pt').write_bytes(b'full-checkpoint-fixture')
            events = []
            files = {}
            class Artifact:
                qualified_name = 'team/project/checkpoint:v0'
                def __init__(self, *args, **kwargs): pass
                def add_file(self, path, name): files[name] = Path(path)
                def wait(self):
                    if failure == 'upload': raise RuntimeError('upload failed')
                def download(self, root):
                    for name, source in files.items():
                        dest = Path(root) / name
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(source, dest)
                    if failure == 'corrupt':
                        (Path(root) / 'last.pt').write_bytes(b'corrupt')
                    return root
            class Run:
                id = 'test'
                url = 'https://example.invalid/run'
                def log_artifact(self, artifact): return artifact
                def finish(self, exit_code): events.append(exit_code)
            sdk = types.SimpleNamespace(Artifact=Artifact, init=lambda **kwargs: Run())
            with patch.dict(sys.modules, {'wandb': sdk}), patch.object(sys, 'argv', ['upload_results.py', '--run-dir', str(root), '--checkpoint', 'last.pt']):
                if failure:
                    with self.assertRaises((RuntimeError, ValueError)):
                        upload_results.main()
                    self.assertFalse((root / 'UPLOAD_RECEIPT.json').exists())
                    self.assertEqual(events, [1])
                else:
                    upload_results.main()
                    receipt = json.loads((root / 'UPLOAD_RECEIPT.json').read_text())
                    self.assertEqual(receipt['content_roundtrip'], 'PASS')
                    self.assertEqual(receipt['model_resume'], 'NOT_TESTED')
                    self.assertEqual(events, [0])
                    (root / 'best.pt').write_bytes(b'earlier-best-checkpoint')
                    with patch.object(sys, 'argv', ['upload_results.py', '--run-dir', str(root), '--checkpoint', 'best.pt']):
                        upload_results.main()
                    history = [json.loads(p.read_text()) for p in (root / 'upload_receipts').glob('*.json')]
                    self.assertEqual({r['checkpoint'] for r in history}, {'last.pt', 'best.pt'})
                    self.assertEqual(len(history), 2)

    def test_upload_and_verified_receipt(self): self.exercise()
    def test_upload_failure_is_failed_run(self): self.exercise('upload')
    def test_corrupt_download_never_gets_success_receipt(self): self.exercise('corrupt')
