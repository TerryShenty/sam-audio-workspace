"""Keep unused frozen encoders off GPU during cached-model initialization."""

def prepare_cached_model(sam, configure, tuning_config, release, device, dtype):
    # The caller loads weights on CPU. Retain the codec separately for validation;
    # release removes it from sam along with the unused text and vision encoders.
    sam.requires_grad_(False).eval()
    tuning = configure(sam, tuning_config)
    codec = sam.audio_codec
    release(sam)
    sam.to(device=device, dtype=dtype)
    return tuning, codec
