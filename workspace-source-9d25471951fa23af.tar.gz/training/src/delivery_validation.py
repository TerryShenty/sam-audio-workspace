"""Portable original per-item BF16 midpoint validation; explicit pre-exported GT WAVs."""
import json,random,hashlib
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
import torch.distributed as dist
from torchdiffeq import odeint
from sam_audio.native_finetuning.feature_cache import ComponentStore
import gt_metric_protocol as metrics

def evaluate(sam,codec,manifest_path,data_root,out,rank,world,tracker):
    root=Path(data_root);manifest=json.loads(Path(manifest_path).read_text());items=manifest['items']
    if not items or len({e['index'] for e in items})!=len(items):raise ValueError('Empty/duplicate validation cohort')
    stores={k:ComponentStore(root/v['path'],v['signature'],lru_entries=16) for k,v in manifest['stores'].items()}
    device=torch.device('cuda',rank);rng=(random.getstate(),np.random.get_state(),torch.get_rng_state(),torch.cuda.get_rng_state(device))
    modes=[(m,m.training) for m in sam.modules()];rows=[]
    try:
        sam.eval();codec.to(device)
        with torch.inference_mode():
            for e in items[rank::world]:
                features=stores[e['store']].assemble(e['refs'])
                f={k:v.to(device) for k,v in features['forward_args'].items()}
                if f['anchor_ids'].tolist()!=[[0,3]]:raise ValueError('Unexpected validation spans')
                noise=torch.randn((1,250,256),generator=torch.Generator(device=device).manual_seed(20260717+e['index']),device=device,dtype=torch.bfloat16)
                def field(at,z):
                    with torch.autocast('cuda',dtype=torch.bfloat16):return sam(noisy_audio=z,time=at.float().expand(1),**f)
                z=odeint(field,noise,torch.tensor([0.,1.],device=device),method='midpoint',options={'step_size':1/16})[-1]
                with torch.autocast('cuda',dtype=torch.bfloat16):wave=codec.decode(z.transpose(1,2).reshape(2,128,250)).view(1,2,-1)[:,0,:]
                pred=wave[0].float().cpu().numpy()
                if not np.isfinite(pred).all() or abs(len(pred)-480000)>4800:raise ValueError('Invalid decoded audio')
                ref,sr=sf.read(root/e['gt_audio'],dtype='float64',always_2d=True);ref=metrics.resample_mono(ref,sr)
                mix,sr=sf.read(root/e['mixture_audio'],dtype='float64',always_2d=True);mix=metrics.resample_mono(mix,sr)
                pred=metrics.fit_length(pred.astype(np.float64),len(mix));ref=metrics.fit_length(ref,len(mix))
                aligned,_,_=metrics.align_small_lag(ref,pred);mix_aligned,_,_=metrics.align_small_lag(ref,mix)
                score=metrics.standard_si_sdr(ref,aligned)
                if not np.isfinite(score):raise ValueError('Nonfinite score')
                rows.append({'index':e['index'],'dataset':e['dataset'],'aligned_si_sdr_db':float(score),'si_sdr_db':float(metrics.standard_si_sdr(ref,pred)),'si_sdri_db':float(score-metrics.standard_si_sdr(ref,mix_aligned)),'noise_sha256':hashlib.sha256(noise.cpu().view(torch.uint8).numpy().tobytes()).hexdigest()})
        shards=[None]*world;dist.all_gather_object(shards,rows);allrows=sorted(sum(shards,[]),key=lambda x:x['index'])
        if [r['index'] for r in allrows]!=sorted(e['index'] for e in items):raise ValueError('Incomplete validation')
        if rank==0:
            out=Path(out);out.mkdir(parents=True,exist_ok=True);(out/'scores.json').write_text(json.dumps(allrows,indent=2))
            summary={ds:{'n':sum(r['dataset']==ds for r in allrows),'aligned_si_sdr_db':float(np.mean([r['aligned_si_sdr_db'] for r in allrows if r['dataset']==ds]))} for ds in sorted({r['dataset'] for r in allrows})}
            (out/'summary.json').write_text(json.dumps(summary,indent=2))
            tracker.log({f'validation/{ds}/aligned_si_sdr_db':v['aligned_si_sdr_db'] for ds,v in summary.items()})
    finally:
        codec.cpu()
        for m,mode in modes:m.training=mode
        random.setstate(rng[0]);np.random.set_state(rng[1]);torch.set_rng_state(rng[2]);torch.cuda.set_rng_state(rng[3],device)
