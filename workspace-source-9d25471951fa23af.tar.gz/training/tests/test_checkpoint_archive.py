import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from checkpoint_archive import manifest, verify


class ArchiveTests(unittest.TestCase):
    def test_roundtrip_and_same_size_corruption(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'last.pt'
            path.write_bytes(b'checkpoint')
            expected = manifest(root, [path])
            self.assertEqual(verify(root, expected), 1)
            path.write_bytes(b'checkpoinx')
            with self.assertRaises(ValueError):
                verify(root, expected)

    def test_missing_and_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'best.pt'
            path.write_bytes(b'best')
            expected = manifest(root, [path])
            path.unlink()
            with self.assertRaises(ValueError):
                verify(root, expected)
            with self.assertRaises(ValueError):
                verify(root, {'version': 1, 'files': {'../outside': {'size': 0, 'sha256': ''}}})

    def test_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'last.pt'
            path.write_bytes(b'x')
            with self.assertRaises(ValueError):
                manifest(directory, [path, path])
