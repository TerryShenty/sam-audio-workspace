import sys,tempfile,unittest,hashlib,threading,json,functools
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from data_manifest import path_in,verify
from download_data import download
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
class Tests(unittest.TestCase):
    def test_escape(self):
        with tempfile.TemporaryDirectory() as d:
            for n in ('../x','/tmp/x'):
                with self.assertRaises(ValueError):path_in(d,n)
            (Path(d)/'link').symlink_to('/tmp')
            with self.assertRaises(ValueError):path_in(d,'link/escaped')
    def test_download_restart_verify_and_tamper(self):
        with tempfile.TemporaryDirectory() as src,tempfile.TemporaryDirectory() as dst:
            content=b'abcdef'*1000;(Path(src)/'sample.bin').write_bytes(content)
            m={'files':[{'path':'sample.bin','size':len(content),'sha256':hashlib.sha256(content).hexdigest()}]}
            (Path(dst)/'sample.bin.partial').write_bytes(content[:31])
            server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=src));t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
            try:
                self.assertEqual(download(dst,m,f'http://127.0.0.1:{server.server_port}'),1)
                self.assertEqual(download(dst,m,f'http://127.0.0.1:{server.server_port}'),1)
            finally:server.shutdown();server.server_close();t.join()
            (Path(dst)/'sample.bin').write_bytes(b'broken')
            with self.assertRaises(ValueError):verify(dst,m)
    def test_duplicates(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x';p.write_bytes(b'x');row={'path':'x','size':1,'sha256':hashlib.sha256(b'x').hexdigest()}
            with self.assertRaises(ValueError):verify(d,{'files':[row,row]})
if __name__=='__main__':unittest.main()
