import sys,tempfile,hashlib,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from release_receipts import complete,record
class Receipts(unittest.TestCase):
 def test_resume_rechecks_content_and_revision(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'data'/'c'/'v';p.parent.mkdir(parents=True);p.write_bytes(b'good')
   a={'repo':'r','commit':'immutable1','repo_path':'a.tar','tar_sha256':'abc'}
   spec={'bytes':4,'sha256':hashlib.sha256(b'good').hexdigest()}
   self.assertFalse(complete(d,a,{'c'}));record(d,a,{'c'},[(p,spec)])
   self.assertTrue(complete(d,a,{'c'}));self.assertFalse(complete(d,{**a,'commit':'immutable2'},{'c'}))
   self.assertFalse(complete(d,a,{'c','other'}));p.write_bytes(b'bad!');self.assertFalse(complete(d,a,{'c'}))
 def test_reject_bad_output(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'v';p.write_bytes(b'x');a={'repo':'r','commit':'c','repo_path':'a','tar_sha256':'h'}
   with self.assertRaises(ValueError):record(d,a,{'c'},[(p,{'bytes':1,'sha256':'wrong'})])
if __name__=='__main__':unittest.main()
