import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from delivery_model_setup import prepare_cached_model

class ModelSetupTests(unittest.TestCase):
    def test_unused_encoders_never_moved_to_gpu(self):
        events=[]
        class Model:
            audio_codec=object()
            text_encoder=object()
            vision_encoder=object()
            def requires_grad_(self,value):
                self.frozen=not value
                return self
            def eval(self):return self
            def to(self,**kwargs):
                self.assert_detached=(self.audio_codec,self.text_encoder,self.vision_encoder)==(None,None,None)
                events.append('move')
                return self
        model=Model();codec=model.audio_codec
        def configure(m,c):
            self.assertTrue(m.frozen)
            self.assertIs(m.audio_codec,codec)
            events.append('configure')
            return 'tuning'
        def release(m):
            events.append('release')
            m.audio_codec=m.text_encoder=m.vision_encoder=None
        tuning,retained=prepare_cached_model(model,configure,{},release,'cuda','bf16')
        self.assertIs(retained,codec)
        self.assertEqual(tuning,'tuning')
        self.assertTrue(model.assert_detached)
        self.assertEqual(events,['configure','release','move'])

    def test_release_failure_prevents_gpu_move(self):
        class Model:
            audio_codec=object()
            def requires_grad_(self,value):return self
            def eval(self):return self
            def to(self,**kwargs):raise AssertionError('Must not reach GPU')
        def release(m):raise ValueError('Trainable encoder cannot be released')
        with self.assertRaisesRegex(ValueError,'Trainable'):
            prepare_cached_model(Model(),lambda m,c:None,{},release,'cuda','bf16')
