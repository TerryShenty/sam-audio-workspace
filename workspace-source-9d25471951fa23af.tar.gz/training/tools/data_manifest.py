"""Explicit manifest builder/verifier. Run large source scans on CPU/transfer nodes."""
import argparse,hashlib,json,os
from pathlib import Path,PurePosixPath

def path_in(root,name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or not p.parts: raise ValueError('Unsafe manifest path')
    root=Path(root).resolve(); result=(root/name).resolve()
    if not result.is_relative_to(root): raise ValueError('Path escapes root')
    return result

def sha(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def verify(root,manifest):
    seen=set()
    for row in manifest['files']:
        if row['path'] in seen:raise ValueError('Duplicate path')
        seen.add(row['path']);p=path_in(root,row['path'])
        if not p.is_file() or p.stat().st_size!=row['size'] or sha(p)!=row['sha256']:
            raise ValueError('File verification failed: '+row['path'])
    return len(seen)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['build','verify']);a.add_argument('--root',required=True);a.add_argument('--manifest',required=True);a.add_argument('--allowlist');o=a.parse_args()
    if o.mode=='verify':print(json.dumps({'verified_files':verify(o.root,json.loads(Path(o.manifest).read_text()))}))
    else:
        if not o.allowlist:raise ValueError('Explicit relative-path allowlist required')
        names=json.loads(Path(o.allowlist).read_text());rows=[]
        if len(names)!=len(set(names)):raise ValueError('Duplicate path')
        for name in names:
            p=path_in(o.root,name);before=p.stat();checksum=sha(p);after=p.stat()
            if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise ValueError('Source changed')
            rows.append({'path':name,'size':after.st_size,'sha256':checksum})
        Path(o.manifest).write_text(json.dumps({'schema':1,'files':rows,'total_bytes':sum(x['size'] for x in rows)},indent=2)+'\n')
