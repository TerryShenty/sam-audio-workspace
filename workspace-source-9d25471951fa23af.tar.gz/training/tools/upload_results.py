"""Explicit checkpoint archival with downloaded content verification (not model resume)."""
import argparse
import json
import os
import tempfile
from pathlib import Path
from checkpoint_archive import manifest, verify


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', required=True)
    parser.add_argument('--checkpoint', required=True)
    args = parser.parse_args()
    root = Path(args.run_dir).resolve()
    checkpoint = (root / args.checkpoint).resolve()
    files = [checkpoint, *sorted(root.glob('validation/*/summary.json'))]
    expected = manifest(root, files)
    import wandb
    # Explicit shared destination; runner must have access using their own credentials.
    run = wandb.init(project=os.environ.get('WANDB_PROJECT', 'sam-audio'),
                     entity=os.environ.get('WANDB_ENTITY') or 'terryshen066-fudan-university',
                     job_type='upload-results')
    exit_code = 1
    try:
        artifact = wandb.Artifact('solos-checkpoint-' + run.id, type='model')
        for path in files:
            artifact.add_file(str(path), name=path.relative_to(root).as_posix())
        with tempfile.TemporaryDirectory(prefix='checkpoint-handoff-') as temp:
            record = Path(temp) / 'CHECKPOINT_MANIFEST.json'
            record.write_text(json.dumps(expected, indent=2))
            artifact.add_file(str(record), name=record.name)
            logged = run.log_artifact(artifact)
            logged.wait()
            restored = Path(logged.download(root=str(Path(temp) / 'download')))
            downloaded_manifest = json.loads((restored / record.name).read_text())
            if downloaded_manifest != expected:
                raise ValueError('Downloaded manifest differs from the uploaded manifest')
            count = verify(restored, expected)
        receipt = {'artifact': logged.qualified_name, 'run_url': run.url,
                   'checkpoint': checkpoint.relative_to(root).as_posix(),
                   'files': expected['files'], 'verified_download_files': count,
                   'content_roundtrip': 'PASS', 'model_resume': 'NOT_TESTED'}
        pending = root / 'UPLOAD_RECEIPT.json.tmp'
        pending.write_text(json.dumps(receipt, indent=2))
        pending.replace(root / 'UPLOAD_RECEIPT.json')
        exit_code = 0
    finally:
        run.finish(exit_code=exit_code)


if __name__ == '__main__':
    main()
