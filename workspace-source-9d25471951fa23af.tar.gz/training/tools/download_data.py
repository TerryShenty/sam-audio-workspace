"""Download explicit immutable HTTP(S) files; resume only with valid Content-Range."""
import argparse,json,shutil,urllib.request,urllib.parse
from pathlib import Path
from data_manifest import path_in,sha,verify

def download(root,manifest,base):
    if urllib.parse.urlparse(base).scheme not in ('http','https'):raise ValueError('HTTP(S) base URL required')
    rows=manifest['files'];seen=set();needed=0
    for row in rows:
        if row['path'] in seen:raise ValueError('Duplicate path')
        seen.add(row['path']);p=path_in(root,row['path'])
        if p.exists() and p.stat().st_size==row['size'] and sha(p)==row['sha256']:continue
        needed+=row['size']
    Path(root).mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(root).free<needed:raise ValueError('Insufficient disk space')
    for row in rows:
        p=path_in(root,row['path']);p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists() and p.stat().st_size==row['size'] and sha(p)==row['sha256']:continue
        part=path_in(root,row['path']+'.partial');offset=part.stat().st_size if part.exists() else 0
        if offset>=row['size']:
            if offset==row['size'] and sha(part)==row['sha256']:part.replace(p);continue
            part.unlink();offset=0
        url=base.rstrip('/')+'/'+urllib.parse.quote(row['path'],safe='/')
        req=urllib.request.Request(url,headers={'Range':f'bytes={offset}-'} if offset else {})
        with urllib.request.urlopen(req,timeout=60) as response:
            append=offset>0 and response.status==206
            if response.status==206 and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):raise ValueError('Invalid range response')
            with part.open('ab' if append else 'wb') as f:shutil.copyfileobj(response,f,1024*1024)
        if part.stat().st_size!=row['size'] or sha(part)!=row['sha256']:raise ValueError('Download checksum failed: '+row['path'])
        part.replace(p)
    return verify(root,manifest)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--manifest',required=True);a.add_argument('--root',required=True);a.add_argument('--base-url',required=True);o=a.parse_args()
    print(json.dumps({'verified_files':download(o.root,json.loads(Path(o.manifest).read_text()),o.base_url)}))
