"""Content verification for checkpoint handoff; never unpickles downloaded files."""
import hashlib
import json
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def manifest(root, paths):
    root = Path(root).resolve()
    entries = {}
    for path in paths:
        path = Path(path).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('Archive inputs must be files within the run directory')
        name = path.relative_to(root).as_posix()
        if name in entries:
            raise ValueError('Duplicate archive input')
        entries[name] = {'size': path.stat().st_size, 'sha256': digest(path)}
    if not entries:
        raise ValueError('Empty checkpoint archive')
    return {'version': 1, 'files': entries}


def verify(root, expected):
    root = Path(root).resolve()
    if expected.get('version') != 1 or not expected.get('files'):
        raise ValueError('Unsupported or empty archive manifest')
    for name, entry in expected['files'].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('Missing or unsafe archive path: ' + name)
        if path.stat().st_size != entry['size'] or digest(path) != entry['sha256']:
            raise ValueError('Archive content mismatch: ' + name)
    return len(expected['files'])
