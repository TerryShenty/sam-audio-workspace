"""Verified per-archive download receipts; never trust file existence alone."""
import hashlib,json
from pathlib import Path
from data_manifest import path_in,sha

def receipt_path(root,archive,ids):
 identity={'repo':archive['repo'],'commit':archive['commit'],'path':archive['repo_path'],'sha256':archive['tar_sha256'],'ids':sorted(ids)}
 key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
 return Path(root)/'receipts'/(key+'.json'),identity

def complete(root,archive,ids):
 p,identity=receipt_path(root,archive,ids)
 if not p.is_file():return False
 try:
  r=json.loads(p.read_text())
  if r['identity']!=identity or not r['files']:return False
  for row in r['files']:
   f=path_in(root,row['path'])
   if not f.is_file() or f.stat().st_size!=row['bytes'] or sha(f)!=row['sha256']:return False
  return True
 except (OSError,ValueError,KeyError,TypeError):return False

def record(root,archive,ids,files):
 if not files:raise ValueError('No files to certify')
 rows=[];seen=set()
 for dest,spec in files:
  rel=str(Path(dest).resolve().relative_to(Path(root).resolve()))
  if rel in seen:raise ValueError('Duplicate output destination')
  seen.add(rel);f=path_in(root,rel)
  if f.stat().st_size!=spec['bytes'] or sha(f)!=spec['sha256']:raise ValueError('Output checksum failed')
  rows.append({'path':rel,'bytes':spec['bytes'],'sha256':spec['sha256']})
 p,identity=receipt_path(root,archive,ids);p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps({'identity':identity,'files':rows},indent=2));tmp.replace(p)
